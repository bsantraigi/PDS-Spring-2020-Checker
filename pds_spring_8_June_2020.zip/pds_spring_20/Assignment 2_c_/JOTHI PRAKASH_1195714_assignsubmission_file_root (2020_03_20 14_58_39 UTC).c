/*
NAME- P JOTHI PRAKASH
ROLL NO-19EC30028
DEPARTMENT-ECE
MACHINE NUMBER - 57 
 */

#include<stdio.h>
#include<math.h>

int main()
{
  float a,b,c,dis,alpha,beta;
  printf("Enter the a,b,c\n");
  scanf("%f%f%f",&a,&b,&c);

   //Checking the condition on the roots
 
  dis=(b*b-4*a*c);
  if(dis<0)
    {
      printf("Roots are complex\n");
    }
  else
    {
      dis=sqrt(dis);
      alpha=(((-1)*b/2*a)+(dis/2*a));
       beta=(((-1)*b/2*a)-(dis/2*a));
       printf("Roots = %f  %f\n",alpha,beta);
    }
  return 0;
}
