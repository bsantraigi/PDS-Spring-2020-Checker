/*Name:Manusani Vaishnavi
Roll.no:19MA20026
Dept:Math and Computing
Sys no:22*/
#include <stdio.h>
#include <math.h>
int main()
{float a,b,c,d,r1,r2;
  printf("Enter a,b,c:");
  scanf("%f %f %f",&a,&b,&c);
  d=b*b-4*a*c;
  if(d>=0)
    {float e=sqrt(d);
      r1=(-b+e)/(2*a);
      r2=(-b-e)/(2*a);
      printf("Roots= %f %f",r1,r2);
    }
  else printf("Roots are complex");
}
