/* Name Akanksha Agrawal*/
/*sec 4 machine no. 19*/
/*roll no. 19GG20003*/
/*Dept Geology and Geophysics*/
#include<stdio.h>
#include<math.h>
int main(){
float   a,b,c,d;
  printf("enter three numbers");
  scanf("%f%f%f",&a,&b,&c);
  d=b*b-4*a*c;    //formula of discriminant
    if (d<0)
     printf("roots are complex");
 else if (d>=0)
{

float x,y;
 x=(-b-sqrt(d))/2*a ;
 y=(-b+sqrt(d))/2*a;
printf("%f\n", x);
printf("%f\n", y);
 };
  
}
