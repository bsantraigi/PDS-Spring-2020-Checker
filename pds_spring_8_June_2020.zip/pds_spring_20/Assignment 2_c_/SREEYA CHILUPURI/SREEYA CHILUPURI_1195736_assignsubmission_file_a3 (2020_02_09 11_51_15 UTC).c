#include <stdio.h>
#include <math.h>
int main()
{int a,b,c,y;
  float d,r1,r2;
  printf("ENTER THE VALUES OF a,b,c:\n");
  scanf("%d%d%d",&a,&b,&c);
  y=sqrt(d);
  d=(b*b)-(4*a*c);
  r1=((-2*b)+(y))/2*a;
  r2=((-2*b)-(y))/2*a;
  if (d>0){
    printf("VALUES OF r1 and r2:\n");
  printf("%f%f",r1,r2);
  }
  else
    printf("Roots are complex");
  return 0;
}
     
  
  
