/*Name: Kammela Mahima Grace
  Roll No: 19EE30010
  Dept: Electrical Engineering
  Machine No:16
*/ 

#include<stdio.h>
#include<math.h>
int main()
{
  float a,b,c,d,x1,x2,y;
    printf("Enter a,b,c\n");
    scanf("%f%f%f",&a,&b,&c);
    d=b*b-4*a*c;
    if(d<0)
      { printf("Roots are complex\n");
       }
    else
      { y=sqrt(d);
       x1=(y-b)/(2*a);
       x2=(-y-b)/(2*a);
      printf("Roots are %f,%f\n",x1,x2);
      }
}
