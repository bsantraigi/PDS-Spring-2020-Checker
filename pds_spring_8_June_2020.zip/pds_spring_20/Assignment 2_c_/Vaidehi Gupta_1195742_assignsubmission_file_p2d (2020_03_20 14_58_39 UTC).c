/*
Name Vaidehi Gupta
Dep Physics
Roll No 19PH20038
Machine No 34
*/

#include<stdio.h>
#include<math.h>
int main()
{
  double a,b,c,d,a1,a2;
  printf("Enter the numbers");
  scanf("%lf%lf%lf" ,&a,&b,&c);
  d=b*b-4*a*c;
  if(d<0)
    printf("Roots are complex");
  else
    {
      a1=(-b+sqrt(d))/2*a;
      a2=(-b-sqrt(d))/2*a;
      printf("a1=%lf, a2=%lf",a1,a2);
	 
    }
}
      
  

