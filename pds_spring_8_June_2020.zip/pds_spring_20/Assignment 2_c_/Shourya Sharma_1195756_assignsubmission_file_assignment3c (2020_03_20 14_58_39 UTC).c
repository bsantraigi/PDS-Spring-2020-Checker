/*NAME-SHOURYA SHARMA
  SEC-4
  MACHINE N0-67
  DEPT-INDUSTRIAL AND SYSTEM ENGINEERING*/
#include<stdio.h>
#include<math.h>
int main()
{ float a,b,c,d,root1,root2;
    printf("Enter the coefficients of quadratic equation a,b,c\n");
  scanf("%f %f %f",&a,&b,&c);
  d= pow(b,2)-4*a*c;
  if(d<0)
    printf(" The roots are imaginary\n");
  else
    { root1=(-b+sqrt(d))/(2*a);
      root2=(-b-sqrt(d))/(2*a);
      printf("The roots are real, root= %f %f",root1,root2);
    }}
