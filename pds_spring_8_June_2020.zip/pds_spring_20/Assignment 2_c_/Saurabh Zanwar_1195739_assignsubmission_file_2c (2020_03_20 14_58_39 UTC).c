/* Saurabh Zanwar
19AG30030
Agricultural and Food Engineering
machine No. - 42
*/						\

#include<stdio.h>
#include<math.h>
int main()
{ float a,b,c,d,e,r1,r2;
  printf("Your quadratic equation in the form ax*x+bx+c=0. Enter your a,b,c");
  scanf("%f%f%f",&a,&b,&c);
  d=b*b-4*a*c;
    if (d<0)
      printf("Roots are complex");
    else
      { e=sqrt(d);
      r1=((-b)+e)/(2*a);
      r2=((-b)-e)/(2*a);
      printf("The roots are %f and %f\n",r1,r2);
    }
}
  
  
