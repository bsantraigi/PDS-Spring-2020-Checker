/*
NAME: Kaushal Banthia
ROLL: 19CS10039
DEPT: Computer Science and Engineering
Machine Number: 51
*/
#include <stdio.h>
#include <math.h>
void main()
{
  printf("Enter a, b, c: ");
  float a,b,c,d,r1,r2;
  scanf("%f %f %f", &a, &b, &c);
  d = (b*b - 4.0*a*c);
  if(d<0)
  printf("Roots are complex.\n");
  else
  {
    r1= (-b+sqrt(d))/(2.0*a);
    r2= (-b-sqrt(d))/(2.0*a);
    printf("Roots = %f %f\n",r1, r2);
  }
}
