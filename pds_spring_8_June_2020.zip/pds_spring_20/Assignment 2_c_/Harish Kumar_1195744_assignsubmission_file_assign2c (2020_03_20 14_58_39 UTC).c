/*
Harish Kumar
19CE10031
Machine 46
*/

#include <stdio.h>
#include <math.h>
int main()
{
  double a,b,c,d;
  printf("Enter the values of a,b,c: ");
  scanf("%lf %lf %lf",&a,&b,&c);
  d=b*b-4*a*c;
  if(d<0)
    printf("Roots are complex.\n");
  else
    {
      printf("Roots = ");
      printf("%lf,%lf\n",(-b+sqrt(d))/(2*a),(-b-sqrt(d))/(2*a));
    }
}
