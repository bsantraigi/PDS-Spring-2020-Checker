/*Name; Muskan Bhura
Roll No.: 19PH20019
Dept: Physics
Machine No.: 33*/
#include<stdio.h>
#include<math.h>
void main()
{
  double a, b, c, d=0.0, x1=0.0, x2=0.0;
  printf("Enter a, b, c: ");  //The quadratic eqn: ax*x+bx+c=0
  scanf("%lf%lf%lf",&a,&b,&c);
  d=b*b-4*a*c;  //calculating discriminant
  if(d<0.0)
    printf("Roots are complex.\n");
  else
    {
      x1=(-1*b+sqrt(d))/(2*a);  //fining the first root
      x2=(-1*b-sqrt(d))/(2*a);  //finding the second root
      printf("Roots = %lf, %lf\n",x1,x2);
    }
}
  
