/*
name; shivam hurkat
roll no:19HS20018
machine no:63
dept:hss*/
#include<stdio.h>
int main()
{
  float a,b,c;
   printf("Enter three numbers:\n");
  scanf("%f%f%f",&a,&b,&c);

	  

  if(2*a==(b+c)||2*b==(a+c)||2*c==(a+b))
		{printf("AP\n");}
	      else
		{printf("not AP\n");}
}
