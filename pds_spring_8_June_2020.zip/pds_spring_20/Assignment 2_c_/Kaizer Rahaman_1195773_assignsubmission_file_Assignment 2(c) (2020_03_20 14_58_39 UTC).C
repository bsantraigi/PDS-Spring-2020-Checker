/* Name       : Kaizer Rahaman
   Roll No    : 19NA10010
   Department : Ocean Engineering and Naval Architecture
   Machine No : 81
*/

#include <stdio.h>
#include <math.h>

int main()
{
  float  a,b,c;
  printf("Enter a,b,c :  ");
  scanf("%f%f%f",&a,&b,&c);
  float d=pow(b,2)-4*a*c;
  if(d<0)
    printf("Roots are complex");
  else
    {
      printf("\n Roots = ");
      float ans1=(-b+sqrt(d))/(2*a);
      float ans2=(-b-sqrt(d))/(2*a);
      printf("%f,%f",ans1,ans2);
    }
}
