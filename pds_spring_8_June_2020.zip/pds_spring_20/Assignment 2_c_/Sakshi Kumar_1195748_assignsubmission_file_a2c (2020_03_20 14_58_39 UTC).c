/*
Sakshi Kumar
19IE10027
Electrical Engineering
Machine no. 65
*/

#include<stdio.h>
#include<math.h>
int main()
{
  float a,b,c,d,e,f,g,h,i,j;
  printf("Quadratic Equation: ax*x+bx+c=0\n");
  printf("Enter a, b and c in order:\n");
  scanf("%f%f%f",&a,&b,&c);
  d=b*b-4*a*c;
  e=2*a;
  if (d<0)
    {
      printf("Roots are complex.\n");
    }
  else
    {
      f=sqrt(d);
      g=-1*b-d;
      h=g/e;
      i=-1*b-d;
      j=i/e;
      printf("Roots=%f,%f\n",h,j);
    }
}
  
