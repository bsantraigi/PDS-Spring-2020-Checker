#include<stdio.h>
#include<math.h>

/*Name-Ronit Hindoddikar
  Roll no-19MT30016
  Section-4 
  Department- Metallurgical and Materials Engineering*/

int main()
{
	float a,b,c,d,R1,R2;
	printf("enter a,b,c");
	scanf("%f%f%f",&a,&b,&c);
	d=(b*b)-(4*a*c);
	R1=((-b)+sqrt(d))/2*a;
	R2=((-b)-sqrt(d))/2*a;
	if(d<0)
	{
		printf("Roots are complex\n");
	}
	else
	{
		printf("Roots:%f,%f \n",R1,R2);
	}
}

