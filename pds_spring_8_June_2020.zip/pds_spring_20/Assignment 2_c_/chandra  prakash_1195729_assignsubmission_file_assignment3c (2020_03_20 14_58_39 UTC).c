/*Name-Chandra Prakash
 Roll No.-19EE10018
 Dept-Electrical Engineering
 System No.-59*/
#include<stdio.h>
#include<math.h>
int  main()
{
  float a,b,c,x,d,r1,r2;
  printf("Enter three numbers");
  scanf("%f %f %f",&a,&b,&c);
  (a*x*x+b*x+c)==0;
  d==((b*b)-(4*a*c));
  if(d>0)
    {
      r1=(-b+sqrt(d))/(2*a);
      printf("%f,",r1);
      r2=(-b-sqrt(d))/(2*a);
      printf("%f",r2);
    }
  else
    printf("Roots are complex");
}
