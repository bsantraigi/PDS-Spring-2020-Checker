/*Name:Ayush Daksh
Roll No:19MA20007
Dept:MAthematics and Computing
System no:21
*/
// c program to analyse the roots of a quadratic equation

#include<stdio.h>
#include<math.h>

int main()
{
  float a,b,c;
  printf("Enter a,b,c:");
  scanf("%f%f%f",&a,&b,&c);			//taking data from user
  double discr=sqrt(b*b-4*a*c);			//finding discriminant
  if(b*b-4*a*c<0)				//checking condition
    printf("Roots are complex.\n");
  else
    printf("Roots= %f, %f\n",(-b+discr)/2*a,(-b-discr)/2*a);  //finding roots
}
