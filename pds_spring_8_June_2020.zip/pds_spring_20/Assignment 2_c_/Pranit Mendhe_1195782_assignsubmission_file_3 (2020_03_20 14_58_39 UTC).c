/*Pranit Mendhe
Mechanical Department
19ME30037
Machine no.:73*/

#include<stdio.h>
#include<math.h>
float main()
{
  float a,b,c,d,D,r1,r2,r;
  printf("Enter the values of a(non-zero number),b,c: ");
  scanf("%f%f%f",&a,&b,&c);
  d=b*b-4*a*c;
  D=sqrt(d);
  r1=(-1*b+D)/2*a;
  r2=(-1*b-D)/2*a;
  r=-1*b/2*a;
  if(d>0)
      printf("Roots are %f and %f\n",r1,r2);
  if(d==0)
      printf("Root is %f\n",r);
  if(d<0)
    printf("Roots are complex\n");
  
}
