/*NAME:SAGGURTHI DEENARAJU
  ROLL NO:19BT30021
  BIO TECHNOLOGY DEPARTMENT
  MACHINE NO:44
*/

#include <stido.h>
#include <math.h>

int main()
{
  double a,b,c,d,e,f,g;
  printf("Enter a,b,c in order:");
  scanf("%f %f %f" ,a,b,c);
  d=(b*b-4*a*c);
  e=sqrt(d);
  f=(-b+e)/(2*a);
  g=(-b-e)/(2*a);
  if(d>=0)
    printf("Roots are %lf and %lf\n",f,g);
  else
    printf("Roots are complex\n");
}
