/*
NAME::Akshat Sharma
ROLL NO.::19EC10002
DEPT::Electronics and Electrical COmmunication Engineering
MACHINE NO.::13			       
*/

/*You know that a quadratic equation is written as
   ax*x + bx + c = 0.
   Write a C program that takes a, b, c as input (all in float or in double).
   Then it checks the discriminant d = b*b - 4*a*c.
   If d is negative, then it should print "Roots are complex.";
   otherwise, it should compute and print the values of the real roots.
*/

#include<stdio.h>
#include<math.h>

int main()
{
  float a,b,c,d;
  float dd,r1,r2;
  printf("Enter a, b, c: ");
  scanf("%f %f %f",&a,&b,&c);
  d= b*b-4*a*c;
  if(d<0)
    {
      printf("Roots are complex.\n");
    }
  else
    {
      dd = sqrt(d);
      r1 = (b+dd)/2;
      r2 = (b-dd)/2;
      printf("Roots = %f,%f\n",r1,r2);
    }
  return 0;
}
