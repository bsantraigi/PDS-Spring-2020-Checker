/* name=a.shivani
roll no=19ME10006
depatment=mechanical
system n0=24*/
#include<stdio.h>
 int main()
 {int a,u,alpha;
 float time,distance;
 printf("enter the values of a,u,alpha in order:\n");
 scanf("%d%d%d",&a,&u,&alpha);
 printf("enter the time:\n");
 scanf("%f",&time);
 distance=a+u*time+0.5*alpha*time*time;
 printf("distance=%f\n",distance);
 }

