//NAME:Avvaru Badri Visaal
//Roll number:19CH10013
//Dept:Chemical Engineering
//Machine number 8
#include<stdio.h>
#include<math.h>
int main()
{
  float a,b,c,d,r1,r2;
  printf("enter the three values from equation:");
  scanf("%f%f%f",&a,&b,&c);
  d=(b*b)-(a*c*4);
  if(d>=0)
    {
      r1=((-1*b)+sqrt(d))/(2*a);
      r2=((-1*b)-sqrt(d))/(2*a);
      printf("the roots are %f %f\n",r1,r2);
    }
  else
    printf("the roots are complex");
}
