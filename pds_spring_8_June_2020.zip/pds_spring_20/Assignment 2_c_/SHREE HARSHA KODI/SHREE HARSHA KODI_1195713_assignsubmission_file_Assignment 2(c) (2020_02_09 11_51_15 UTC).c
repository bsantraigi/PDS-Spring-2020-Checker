/*Name:Kodi Shree Harsha
Roll No:19AE30009
Machine No:3
Department:Aerospace*/

#include<stdio.h>
#include<math.h>
int main()
{
  float a,b,c,d,x,y;
  printf("Enter the values:");
  scanf("%f %f %f ",&a,&b,&c);
  d=(b*b-4*a*c);
  if(d<0)
    {printf("roots are complex")}
  else(d>=0)
	{x=(-b+sqrt(d))/2*a;
	  y=(-b-sqrt(d))/2*a;
	  
 
	  printf("The roots are %f ,%f",x,y); }
    return(0);
}
