/*NAME: Mithil Rajput
Roll No:19EX20021
DEPT: GEOLOGY AND GEOPHYSICS
MACHINE NO.: 18
*/
#include<stdio.h>
#include<math.h>
int main()
{
  float a, b, c, d, e, f;
  printf("\n Enter a, b, c:");
  scanf("%f %f %f", &a, &b, &c);
  d =  b*b - 4*a*c;
  if ( d >= 0){
    e = (-b + sqrt(d))/(2*a);
    f = (-b - sqrt(d))/(2*a);
    printf("\n Roots = %f, %f", e, f);
  }
  else printf("\n Roots are complex.\n");
}
