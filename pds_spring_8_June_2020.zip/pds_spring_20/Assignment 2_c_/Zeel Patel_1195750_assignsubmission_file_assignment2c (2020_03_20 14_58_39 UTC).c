/*name:Patel Zeel yogeshkumar
roll no:19ME10044
dept:Mechanical Eng
machine no:69*/

//program to find the roots of the quadratic equation

#include <stdio.h>
#include <math.h>

int main()
{
  float a, b, c, d, e, r1, r2;
  printf("Enter the values of a, b, c\n");
  scanf("%f%f%f", &a, &b, &c);
  d=b*b-4*a*c;
  if (d<0)
    printf("Roots are complex\n");
  else
    { e=sqrt(d);
      r1=(-b+e)/(2*a);
      r2=(-b-e)/(2*a);
      printf("Roots=%f %f\n", r1, r2);
    }
  return 0;
}
      
  
