/* Name = Gaurav Samaria
   Roll Number = 19MF10014
   Department = Mechanical Engineering
   System Number = 75 */

#include<stdio.h>
#include<math.h>
void main()
{
   float a, b, c, disc, x1, x2, y, x;
   printf("Enter the values one by one.\n");
   printf("Enter the value of a: ");
   scanf("%f",&a);
   printf("Enter the value of b: ");
   scanf("%f",&b);
   printf("Enter the value of c: ");
   scanf("%f",&c);


   disc = b*b-4*a*c;

   if(disc<0)
   {   printf("The roots of the equation are complex.");
   }
   else
   {  x = -b+sqrt(disc);
      y = -b-sqrt(disc);
      x1 = x/(2*a);
      x2 = y/(2*a);
       printf("The roots of the equations are x1=%f and x2=%f.\n",x1,x2);
   }
}
