/*Himanshu Kumar
Mechanical Engineering
19ME30018
mach no=72*/
#include<stdio.h>
#include<math.h>
int main()
{float a,b,c,d,x1,x2;
  printf("Enter a");
  scanf("%f",&a);
  printf("Enter b");
  scanf("%f",&b);
  printf("Enter c");
  scanf("%f",&c);
  d=b*b-4*a*c;
  if(d<0)
    {printf("Roots are complex");}
  else
    { x1=(-b+sqrt(d))/2;
      x2=(-b-sqrt(d))/2;
      printf("%f,%f",x1,x2);
    }
}
