/*name: ragini laskar
roll no:19MI33016
DEP:mining
machine no.:76*/
#include<stdio.h>
int main(){
  float a,b,c,d,root1,root2;
  scanf("%f%f%f",&a,&b,&c);
    d=b*b-4*a*c;
  if(d<0)
    printf("roots are complex");
    else if(d>=0){
      root1=(-b+d)/(2*a);
  root2=(-b-d)/(2*a);
  printf("roots are %f,%f",root1,root2);}
  
}
