/*Name:A.N.V.S.Bhargavi
Rollno:19AE10004
Dept:Aerospace
Machine no:01*/
#include<stdio.h>
#include<math.h>
main()
{
  float a,b,c,d,x,y;
  printf("Enter a,b,c:");
  scanf("%f %f %f",&a,&b,&c);
  d=b*b-4*a*c;
  if(d<0)
    printf("roots are complex");
    else
      {
	x=(-b+sqrt(d))/(2*a);
	y=(-b-sqrt(d))/(2*a);
	printf("Roots=%f,%f",x,y);
      }
}
  
