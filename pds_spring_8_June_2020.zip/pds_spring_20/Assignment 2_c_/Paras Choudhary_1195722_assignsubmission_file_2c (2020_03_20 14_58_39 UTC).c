/*Paras Choudhary
19GG20022
sec4
system 20
*/

#include <stdio.h>
#include <math.h>

int main ()
{

  float a, b, c, d, e, f, g;
  d = ((b*b) - (4*a*c));
  e = sqrt(d);
  
  printf("write a b c of your quadratic equation\n");
  scanf("%f %f %f",&a, &b, &c);
  if(d>=0)
      {
		f = ((-b + e)/(2*a));
                g = ((-b - e)/(2*a)); 
                printf("%f, %f",f, g);
      } 

  else {
    printf("Roots are Complex");
  }

 



}
