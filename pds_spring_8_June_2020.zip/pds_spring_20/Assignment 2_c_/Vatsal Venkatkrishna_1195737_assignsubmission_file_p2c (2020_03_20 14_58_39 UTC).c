/*
NAME-VATSAL VENKATKRISHNA
ROLLNO-19NA30029
DEPARTMENT-OCEAN ENGINEERING AND NAVAL ARCHITECTURE
MACHINE NO-32
*/
#include <stdio.h>
#include <math.h>
void main()
{
  double a=0.0,b=0.0,c=0.0,d=0.0;
  printf("Enter a,b,c: ");
  scanf("%lf%lf%lf",&a,&b,&c);
  d=(b*b - 4*a*c);
  if(d<0.0)
    printf("Roots are complex\n");
  else
    printf("The roots are %lf and %lf\n",(b*-1 + sqrt(d))/(2*a),(b*-1 - sqrt(d))/(2*a));
}
  
