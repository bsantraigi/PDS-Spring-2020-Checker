/*Name:Rahul Nath
roll no.:19CH10033
Dept:chemical
assignment:assignment2(c)*/
#include<stdio.h>
#include<math.h>
int main()
{
  float a,b,c,D,x1,x2;
  printf("enter coeffs of quadratic eqn:\n");
  scanf("%f%f%f",&a,&b,&c);
  D=sqrt(b*b-4*a*c);
  if(D>=0)
    {
      x1=(-b+D)/(2*a);
      x2=(-b-D)/(2*a);
      printf("real roots are:%f and %f \n",x1,x2);
    }
  else
    printf("roots are complex");
  return (0);
}
  
