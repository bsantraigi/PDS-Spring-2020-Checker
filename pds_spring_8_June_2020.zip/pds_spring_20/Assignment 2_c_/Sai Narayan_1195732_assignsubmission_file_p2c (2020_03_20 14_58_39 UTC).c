/*
Name : S. Sai Narayan
Roll Number : 19QD30014
Department : Quality Engineering Design Manufacture
Machine Number : 35
*/ 

//header files
#include<stdio.h>
#include<math.h>


int main()
{
  //variable declarations
  double a,b,c,d,y;
  printf("Enter a,b,c: ");
  scanf("%lf%lf%lf",&a,&b,&c); //accepting variables
  d=b*b-4*a*c;
  if(d<0)
    {
      printf("\nRoots are complex.\n");  //case for complex roots
    }
  else
    {
      y=sqrt(d);
      printf("\nRoots = %lf,%lf\n",(-b+y)/(2*a),(-b-y)/(2*a));  // case for real roots
    }
}
      
  
