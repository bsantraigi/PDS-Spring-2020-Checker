/* name:l.Pradeep;
     sec:4;
     roll no:19EE10038;
     dept:Electrical ;
     mac no:60   */
#include<stdio.h>
#include<math.h>
int main()
{
  float a,b,c,d,x1,x2;
  printf("enter the three number");
  scanf("%f%f%f",&a,&b,&c);
  d=(b*b-4*a*c);
  if(d<0)
    printf("the roots are complex");
  else 
{
    x1=(-b+sqrt(b*b-4*a*c))/(2*a);
	x2=((-b-sqrt(b*b-4*a*c))/(2*a));
	printf("roots are %f %f\n",x1,x2);
}	
} 
