#include<stdio.h>
#include<math.h>
/* Name- Rahul Choudhary
   Roll No.: 19AE10024
   Department: Aerospace
   Machine No.: 02 */
int main()
{
  float a,b,c,d;
  scanf("%f %f %f",&a,&b,&c);/* User enters the coefficients of quadratic equation */
  d=(b*b)-(4*a*c);   /* This is the calculatuion of discriminant which will be used in calculation
                        of roots */
if(d<0)
{
printf("Root are Complex\n");
}
else
{
float root1,root2;
root1 =(-b+sqrt(d))/((2.0)*a);
root2 =(-b-sqrt(d))/((2.0)*a);
 printf("Roots = %f %f\n",root1,root2);
}
return 0;
}
