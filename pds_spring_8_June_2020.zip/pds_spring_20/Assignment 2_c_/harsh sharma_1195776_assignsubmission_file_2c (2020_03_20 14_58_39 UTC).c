/*Name - Harsh Sharma 
  Roll No. - 19AG30010
  Department - Agricultural And Food Engineering
  Machine No. - 41 */
#include<stdio.h>
#include<math.h>
int main()
{
  double a,b,c,d,x2,x1;
  printf("Enter the value of a , b and c in order :");
  scanf("%lf%lf%lf",&a,&b,&c);
  d = (b*b) - (4*a*c);
  if(d<0)
    printf("Roots are complex\n");
  else
    {
      x1 = (-b-sqrtl(d))/(2*a);
      x2 = (-b+sqrtl(d))/(2*a);
      printf("Roots of the equation are : %lf and %lf\n",x1,x2);
    }
  return 0;
}
