/*PRAUJJAWAL PRABHAKAR*/
/*19CE10051   section 4*/
/*Assignment 2c*/

#include<stdio.h>
#include<math.h>
int main()
{
  double a, b, c, Dis,r1, r2;
  printf("Enter the constants of the quadratic equation\n");
  scanf("%lf%lf%lf",&a,&b,&c);
  Dis = b*b-4*a*c;
  if (Dis<0)
    printf("Roots are imaginary\n");
  else
    { r1 =(-b+sqrt(Dis))/(2*a);
      r2 =(-b-sqrt(Dis))/(2*a);
      printf(" The roots are %lf and %lf\n", r1, r2);
    }
}
