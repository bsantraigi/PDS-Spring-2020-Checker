/*apoorva erra 
19IM10011
SEC 4*/
//finding the roots of the equation
#include<stdio.h>
#include<math.h>
int main()
{
  float a,b,c,d,root1,root2;//declaration
  printf("enter the values of a,b,c:");//for the expression a*x*x +b*x +c=0
  scanf("%f %f %f",&a,&b,&c);//taking inputs
  d=b*b-4*a*c;
  if (d<0)
    printf("the roots are imaginary");
  else
    { root1=(-b + sqrt(d))/(2*a);//finding the roots
  root2=(-b-sqrt(d))/(2*a);
  printf("roots = %f, %f",root1,root2);
    }
}
      
