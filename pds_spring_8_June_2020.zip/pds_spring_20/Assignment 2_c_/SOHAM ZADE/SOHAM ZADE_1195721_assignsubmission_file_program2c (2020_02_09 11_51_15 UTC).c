/* Name: Soham Zade
   Roll no: 19CH10053
   Machine no: 10
   Roots of quadratic equation*/

#include<stdio.h>
#include<math.h>

int main()
{float a, b, c, d, x1, x2;

  printf("Enter a, b, c\n");
  scanf("%f %f %f", &a, &b, &c);

  d= b*b-4*a*c; //formula for discriminant//

    if(d>=0)
      {x1= (-b + sqrt(b*b-4*a*c))/2*a; //Formula for roots//
       x2= (-b - sqrt(b*b-4*a*c))/2*a;

       printf("Roots are %f, %f\n", x1, x2);
      }
    else
      {printf("Roots are complex.\n");}

       



}
