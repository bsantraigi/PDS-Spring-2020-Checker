/*NAME- ASHISH PRATAP SINGH
 ROLL NO.-19CE10011
 CIVIL ENGINEERING DEPARTMENT
 MACHINE NO.-45
*/

#include <stdio.h>
#include <math.h>

int main()
{
  double a,b,c,d,e,f,g;
  printf("Enter a,b,c in order:");
  scanf("%lf %lf %lf",&a,&b,&c);
  d=(b*b-4*a*c);
  e=sqrt(d);
  f=(-b+e)/(2*a);
  g=(-b-e)/(2*a);
  if(d>=0)
    printf("Roots are %lf and %lf\n",f,g);
  else
    printf("Roots are complex\n");
}
  
