/* Name- Pradipta Debsarma
   Roll-19MT10030
   Depth-Metallurgical and Materials Science Engineering
   System N.o-78 
*/
#include<stdio.h>
#include<math.h>
int main()
{ 
  float a,b,c,d,x,y;
  printf("Enter the values of a,b,c of the quadratic equation\n");
  scanf("%f%f%f",&a,&b,&c);
  d=b*b-4*a*c;
  if(d>=0)
  {  
    x=(-b+sqrt(d))/2*a;
    y=(-b-sqrt(d))/2*a;
    printf("%f%f",x,y);
  }
  else printf("Roots are complex");
}
