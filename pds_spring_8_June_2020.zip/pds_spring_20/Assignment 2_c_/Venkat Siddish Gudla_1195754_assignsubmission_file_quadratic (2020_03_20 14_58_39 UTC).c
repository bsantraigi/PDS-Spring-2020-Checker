/* Name:- Venkat Siddish Gudla
   Roll No:- 19EC30048
   Dept:- ECE
   System No:- 58*/
#include<stdio.h>
#include<math.h>
int main()
{
  double  a,b,c,d,root1,root2;
  scanf("%lf %lf %lf",&a,&b,&c);
  d=((b*b)-(4*a*c));
  printf("%lf,%lf,%lf\n",a,b,c);
  printf("%lf/n",d);
  if(d<0)
    {
      printf("Roots are complex\n");
    }
  else
    {
      root1=(-b+(sqrt((b*b)-(4*a*c))))/(2*a);
      root2=(-b-(sqrt((b*b)-(4*a*c))))/(2*a);
      printf("the roots are %lf,%lf/n",root1,root2);
    }
}
	
