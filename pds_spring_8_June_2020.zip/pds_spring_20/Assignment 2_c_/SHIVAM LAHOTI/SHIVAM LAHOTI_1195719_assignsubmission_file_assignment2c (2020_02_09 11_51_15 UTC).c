#include<stdio.h>
#include<math.h>
int main()
{
  /*name- Shivam Lahoti
roll no.- 19AG10028
machine no.- 5
department- Agriculture and food engineering*/
  float a,b,c,d,d1,r1,r2;
  printf("enter the coefficients of the quadratic equation \n");
  scanf("%f%f%f",&a,&b,&c);
  d=b*b-4*a*c;
  if(d<0.00)
    {printf("the roots are complex \n");}
  else{
    r1= (-b+d)/(2*a);
    r2=(-b-d)/(2*a);
    printf("roots= %f ,%f \n",r1,r2);
  }}
