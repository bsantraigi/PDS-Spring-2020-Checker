/* Name-Vineet Anand
   Roll-19GG20041
   Dept-GG     
   Machine Number-62 */
#include<stdio.h>
#include<math.h>
int main()
{
  float a,b,c,x,y,z;
  printf("Enter coefficient in order a,b,c \n");
  scanf("%f%f%f",&a,&b,&c);
  if(b*b-4*a*c < 0)
     {
       printf("Roots are complex ");
     }
  else{z=sqrt(b*b-4*a*c);
    x=(-b+z)/(2*a);
    y=(-b-z)/(2*a);
    printf("Roots=%f,%f",x,y);}}
       
