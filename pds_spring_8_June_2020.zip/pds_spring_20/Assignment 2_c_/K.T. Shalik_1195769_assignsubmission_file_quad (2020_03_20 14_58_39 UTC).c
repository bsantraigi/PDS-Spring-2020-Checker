/*
  Name       :  K.T.Shalik
  Roll No    :  19CY20020
  Dept       :  Chemistry
  Machine No ;  12 

You know that a quadratic equation is written as
   ax*x + bx + c = 0.
   Write a C program that takes a, b, c as input (all in float or in double).
   Then it checks the discriminant d = b*b - 4*a*c.
   If d is negative, then it should print "Roots are complex.";
   otherwise, it should compute and print the values of the real roots.*/
#include<stdio.h>
#include<math.h>
int main()
{
  float a,b,c,d=0,r1,r2,f;
    printf("enter the co-efficents\n");
  scanf("%f",&a);
  scanf("%f",&b);
  scanf("%f",&c);
  d=(b*b)-(4*a*c);
  f= sqrt(d);
  if(d>=0)
    {
      r1=((-b)+f)/(2*a);
      r2=((-b)-f)/(2*a);
      printf("%f,%f",r1,r2);
    }
  else
    {
      printf("root are imaginary");
    }
}
  
