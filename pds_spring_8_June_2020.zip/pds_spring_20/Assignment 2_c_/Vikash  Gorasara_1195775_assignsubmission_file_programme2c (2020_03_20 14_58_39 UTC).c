/*Name-Vikash Gorasara
 Roll-19MT10049
 Dept-Metallurgical and Materials Science Engineering
 System N.o-79
*/
#include<stdio.h>
#include<math.h>
int main()
{
   float a,b,c,d,x1,x2;
   printf("Enter the value of a,b,c");
   scanf("%f%f%f",&a,&b,&c);
   d=(b*b)-4*a*c;
   x1=((-b)+sqrt(d))/2*a;
   x2=((-b)-sqrt(d))/2*a;

   if(d<0)
     {
       printf( "Roots are complex\n");
     }
     
    else 
     {
         printf("Roots:%f,%f\n",x1,x2);
       
      }



}
