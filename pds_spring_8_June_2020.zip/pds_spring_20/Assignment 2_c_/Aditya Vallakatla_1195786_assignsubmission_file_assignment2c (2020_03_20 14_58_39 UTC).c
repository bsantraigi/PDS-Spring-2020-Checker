/* Name : Aditya Vallakatla
 Roll No : 19CS30051
 Machine No : 11
 Department : Computer Science and Engineering */
/*You know that a quadratic equation is written as
   ax*x + bx + c = 0.
   Write a C program that takes a, b, c as input (all in float or in double).
   Then it checks the discriminant d = b*b - 4*a*c.
   If d is negative, then it should print "Roots are complex.";
   otherwise, it should compute and print the values of the real roots.*/
#include<stdio.h>
#include<math.h>
main()
{
  float a,b,c,d;
  printf("Enter a,b,c:\n");
  scanf("%f%f%f",&a,&b,&c);
  d=b*b-4*a*c;
  if(d<0)
    printf("Roots are Complex\n");
   else
    {
      float r1,r2;
      r1=(-b+sqrt(d))/(2*a);
      r2=(-b-sqrt(d))/(2*a);
      printf("The Roots are %f and %f\n",r1,r2);
    }
  return 0;
}
     
	
  
