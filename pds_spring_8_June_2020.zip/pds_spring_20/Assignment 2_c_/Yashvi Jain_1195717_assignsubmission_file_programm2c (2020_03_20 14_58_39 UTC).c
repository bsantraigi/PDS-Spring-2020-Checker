/*Yashvi Jain
19CH30028
Dept:Chemical
Machine no : 49*/

#include <stdio.h>
#include <math.h>

int main(){
  printf("enter the coefficients of a quadratic");
  float a,b,c,d,root1,root2,sqroot;
  scanf("%f%f%f",&a,&b,&c);
  d = b*b-4*a*c;
  if (d>=0){
    sqroot=sqrt(d);
    root1=(-b+sqroot)/(2*a);
    root2=(-b-sqroot)/(2*a);
    printf("the roots are %f%f\n",root1,root2);
  }
  else
    printf("the roots are not real\n");
}
    
      
