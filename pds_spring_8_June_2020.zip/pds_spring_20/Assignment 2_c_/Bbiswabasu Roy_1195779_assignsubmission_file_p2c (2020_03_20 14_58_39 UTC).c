/*Name - Bbiswabasu Roy
  Roll - 19EC30008
  Dept - ECE
  Machine # - 56
*/
#include <stdio.h>
#include <math.h>
int main()
{
  double a,b,c,d;
  printf("Enter a, b, c: ");
  scanf("%lf%lf%lf",&a,&b,&c);
  d=b*b-4*a*c;
  if(d<0)
    printf("Roots are complex.\n");
  else
    printf("Roots = %lf, %lf\n",(-b+sqrt(d))/(2*a),(-b-sqrt(d))/(2*a));
}
