#include<stdio.h>
#include<math.h>
int main()
{
  /*
   Subhadeep Paul
   19EE10057
   Electrical Engineering
   61
   */
  float a,b,c;
  printf("Input values of a,b and c:-");
  scanf("%f%f%f",&a,&b,&c);
  if((b*b-4*a*c)<0)
  {
	printf("Roots are complex.");
  }
  else
  {
	printf("Roots:-%f,%f",(-b+sqrt(b*b-4*a*c))/2,(-b-sqrt(b*b-4*a*c))/2);
  }
  return 0;
}
