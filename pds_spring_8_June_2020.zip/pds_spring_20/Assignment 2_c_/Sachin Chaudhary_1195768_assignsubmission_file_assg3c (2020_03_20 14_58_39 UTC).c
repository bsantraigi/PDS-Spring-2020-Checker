/*Name:Sachin Chaudhary
Roll no.=19MA20045
Dept=Mathematics
Machine No.=23

Program to find the roots of a quadratic equation*/
#include <stdio.h>
#include <math.h>
int main()
{
  float a,b,c,d,y,z;
  printf("Enter the 3 nos.:");
  scanf("%f %f %f",&a,&b,&c);
  d=b*b-4*a*c;
  y=(-b+sqrt(d))/2*a;
  z=(-b-sqrt(d))/2*a;
  if(d<0)
    printf("Roots are complex");
  else
  printf("The roots of equation are:%f %f",y,z);
}
      
  
  
    
