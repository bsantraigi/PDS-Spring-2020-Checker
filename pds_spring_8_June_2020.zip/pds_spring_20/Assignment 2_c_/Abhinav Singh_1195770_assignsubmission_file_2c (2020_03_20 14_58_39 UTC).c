/*Abhinav Singh
19BT30001
Biotechnology
Machine No 43
*/
#include<stdio.h>
#include<math.h>
int main()
{
  double a,b,c,d,r1,r2,y;
  printf("Enter a, b, c:");
  scanf("%lf%lf%lf",&a,&b,&c);
  d=b*b-4*a*c;
  if(d<0){
    printf("Roots are complex.\n");
    return 0;
  }
  y=sqrt(d);
  r1=(-b+y)/(2*a);
  r2=(-b-y)/(2*a);
  printf("Roots = %lf,%lf\n",r1,r2);
}


  
  
