/*
Name-Dibyendu Biswas
Roll no-19E10022
Problem no-3
machine no-14
sec-4
*/
#include<stdio.h>
#include<math.h>

int main()
{
  float a,b,c,d,r1,r2,y;
  printf("Enter a,b,c:");
  scanf("%f%f%f",&a,&b,&c);
  d=b*b-4*a*c;
  if(d<0)
    printf("Roots are complex");
  else{
    y=sqrt(d);
    r1=(-b+y)/(2*a);
  r2=(-b+y)/(2*a);
  printf("Roots:%f,%f",r1,r2);
  }
  return 0;
}
