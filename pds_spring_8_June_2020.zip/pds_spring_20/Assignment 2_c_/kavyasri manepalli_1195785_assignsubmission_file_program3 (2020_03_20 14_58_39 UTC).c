/*
name:m kvya sri
roll no:19ec10042
machine no:15
question no:2c
*/
#include<stdio.h>
#include<math.h>
int main()
{
  float a,b,c,disc,r1,r2;
  printf("enter any three values");
  scanf ("%f %f %f",&a,&b,&c);
   disc=sqrt(b*b-4*a*c);
   if (disc<0)
   printf("the roots are complex");
  else
   {
    r1=((-1)*b)/(2*a)+disc/(2*a);
    r2=((-1)*b)/(2*a)-disc/(2*a); 
    printf("the real roots are %f,%f",r1,r2);
   }
 return 0;
}


