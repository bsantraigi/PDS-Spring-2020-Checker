/*Duhita Wani
19ME10082
Mechanical Engineering
Machine no - 71*/

#include<stdio.h>
#include<math.h>
int main()
{
  float a,b,c,d;
  printf("Enter a,b,c:\n");
  scanf("%f%f%f",&a,&b,&c);
  
  d=(b*b)-4*a*c;

  if (d<0)
    printf("Complex Roots");
  else
    {float r1,r2;
      r1=-b+sqrt(d);
      r2=-b-sqrt(d);
      printf("Roots are %f %f\n",r1,r2);
    }
 }      
