/*Name-Aryan Raj lohani
Roll no - 19mt10011
system no-77*/

#include<stdio.h>
#include<math.h>
int main(){
	float a,b,c , D,p,s,y;
	printf("enter the constants a , b ,c");
	scanf("%f%f%f",&a,&b,&c);

	D= b*b -4*a*c;
	if(D>=0){
	 y= sqrt(D);
	 p = (-b-y)/(2*a);
	 s = (-b+y)/(2*a);
     printf("the roots are %f,%f",p,s);
	}else
	printf("the roots are complex");
	return 0;
}
