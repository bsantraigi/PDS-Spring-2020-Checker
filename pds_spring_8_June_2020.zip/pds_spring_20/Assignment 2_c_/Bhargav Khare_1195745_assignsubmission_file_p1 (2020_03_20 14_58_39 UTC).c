/*
NAME: BHARGAV KHARE
ROLL NO.:19NA30010
DEPT: OCEAN ENGINEERING AND NAVAL ARCHITECTURE
PC NO.:31*/
#include<stdio.h>
#include<math.h>
void main()
{
  float a, b, c;
  float d=0,result1=0,result2=0;
  printf("Enter the coefficients of the quadratic equation.\n");
  scanf("%f %f %f",&a,&b,&c);
  d=(b*b)-(4*a*c);//Discriminant
  if(d<0)
    {
      printf("Roots are complex.\n");//If discriminat less than zero
    }
  else
    {
      result1=(-b+sqrt(d))/(2*a);
      result2=(-b-sqrt(d))/(2*a);
      printf("The roots are %f %f",result1,result2);
    }
}
  
