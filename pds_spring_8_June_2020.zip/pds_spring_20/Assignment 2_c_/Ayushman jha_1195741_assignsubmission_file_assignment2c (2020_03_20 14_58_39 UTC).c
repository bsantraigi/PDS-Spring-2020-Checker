#include<stdio.h>
#include<math.h>

int main()
{
float a,b,c,d,e,A,B;

printf("Enter a \n");
scanf("%f" ,&a);

printf("Enter b \n");
scanf("%f" ,&b);

printf("Enter c \n");
scanf("%f" ,&c);

d = b*b - 4*a*c ;
e=sqrt(d);
A= (-1*b + e)/(2*a);
B= (-1*b - e)/(2*a);

if(d>=0)
{
printf("The roots are real and they are %f and %f \n" ,A,B);
}

else
{
printf("The roots are not real \n");
}






}

