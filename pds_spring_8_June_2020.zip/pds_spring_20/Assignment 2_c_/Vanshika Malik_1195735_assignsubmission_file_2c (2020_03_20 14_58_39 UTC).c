/*Vanshika
19ME30056
Mechanical
System number 74
*/

#include<stdio.h>
#include<math.h>
int main()
{

  float a,b,c,d,x1,x2,y;
  printf("enter a,b,c\n");

  scanf("%f %f %f",&a,&b,&c);

  d=(b*b)-(4*a*c);

  if(d<0)

    {

      printf("roots are complex");


    }


  if(d>=0)

    {

      y=sqrt(d);
      x1=(y-b)/(2*a);
      x2=-(b+y)/(2*a);

      printf("%f %f",x1,x2);


    }

  return 0;

}
