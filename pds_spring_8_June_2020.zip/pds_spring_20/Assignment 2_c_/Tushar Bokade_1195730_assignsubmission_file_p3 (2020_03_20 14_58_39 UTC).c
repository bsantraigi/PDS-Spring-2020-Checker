/*Assignment1*/
/*Name-Tushar Bokade
Roll-19CS30011
Dept-Computer Science And Engineering
Machine No.-53*/
#include <stdio.h>
#include<math.h>
int main()
{float a,b,c,d,x1,x2;
  printf("Enter a,b,c:");
  scanf("%f%f%f",&a,&b,&c);
  d=b*b-4*a*c;
  if (d>=0){
    x1=(-b+sqrt(d))/2*a;
    x2=(-b-sqrt(d))/2*a;
    printf("Roots:%f,%f\n",x1,x2);
  }
  else printf("Roots are complex\n");
}
      
    
    
