/* Information
  Shobhit Narayan Tripathi
  19MI31021
  Mining Department 5years Dual Degree Course
  Machine no. 30
*/
#include<stdio.h>
#include<math.h>
int main()
 { 
   float a,b,c,d,x1,x2;
   printf("General quadratic equation will be ax*x + b*x + c = 0 , therefore enter the values of a,b and c :"); 
   scanf("%f %f %f",&a,&b,&c);
   d=b*b-4*a*c;
     
    if(d>=0)
     {
       x1=(-b+sqrt(d))/(2*a);
       x2=(-b-sqrt(d))/(2*a);
         
       printf("The roots of the equation are x1=%f and x2=%f\n",x1,x2);
     }
    else
       printf("Roots are complex\n");
 }

