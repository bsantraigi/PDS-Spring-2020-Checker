/*
 Name: B.vamshi krishna
 Roll: 19CS10019
 Dept: computer science and engineering
 Machine number: 50
*/
# include<stdio.h>
#include<math.h>
int main()
 { 
   float a,b,c,D,x1,x2;
   printf("\nenter your a,b,c\n");
   scanf("%f%f%f",&a,&b,&c);
   D=b*b-4*a*c;
   if (D>=0)
     {
       printf("\nyour roots are real\n");
       x1=(-b+sqrt(D));
       x1=(x1*0.5)/a;
       x2=(-b-sqrt(D));
       x2=(x2*0.5)/a;
       printf("your solutions are %.1f and %.1f\n",x1,x2);
     }
   else printf("the quadratic equation has no real solutions\n");
}
