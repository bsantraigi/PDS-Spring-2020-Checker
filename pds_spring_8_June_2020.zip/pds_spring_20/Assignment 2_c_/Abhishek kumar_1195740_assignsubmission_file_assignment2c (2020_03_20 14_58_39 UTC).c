/*
abhishek kumar
19MI31002
mining engineering
29
*/
#include <stdio.h>
#include <math.h>
int main()
{
float a,b,c,x,y;
double d;
printf("enter a,b&c for ax^2+bx+c=0\n");
scanf("%f%f%f",&a,&b,&c);
d=(b*b-4*a*c);
if(d>0)
{
   x=((-b)+sqrt(d))/(2*a);
   y=((-b)-sqrt(d))/(2*a);
printf("roots= %f,%f",x,y);
}
else
printf("roots are complex");
}
