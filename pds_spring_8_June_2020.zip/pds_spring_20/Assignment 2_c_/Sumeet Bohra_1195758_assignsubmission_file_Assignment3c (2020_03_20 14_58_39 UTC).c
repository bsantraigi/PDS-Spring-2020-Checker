/*
Name - Sumeet Bohra
Roll - 19CS10059
Department - Computer Science and Engineering
Machine No. - 52
*/

#include <stdio.h>
#include <math.h>

void main()
{
    float a,b,c,disc,root1,root2;
    printf("Enter the coefficients of a quadratic equation: \n");
    scanf("%f %f %f",&a,&b,&c);
    disc=b*b-4*a*c;
    if(disc<0)
	printf("Roots are complex.\n");
    else 
    {
	root1=(-b-sqrt(disc))/(2*a);
	root2=(-b+sqrt(disc))/(2*a);
	printf("Roots = %f , %f\n",root1,root2);
    }
}
