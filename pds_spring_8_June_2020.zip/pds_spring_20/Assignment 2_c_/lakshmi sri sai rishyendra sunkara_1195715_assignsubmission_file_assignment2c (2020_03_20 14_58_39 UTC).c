/* Name:S.L.S.Sai Rishyendra;
   Rollno:19EC10062;
   Dept:E&ECE;
   Machine No:55 */
#include<stdio.h>
#include<math.h>
int main()
{
  float a,b,c,d,e,x1,x2;
  scanf("%f%f%f",&a,&b,&c);
     d=b*b-4*a*c;
     if(d>=0)
       {
	 e=sqrt(d);

	 x1=(e-b)*0.5/a;

	 x2=(-b-e)*0.5/a;
         printf("%f%f",x1,x2);}
     else
       printf("the roots are complex\n");
}
           
       
       
  
	
