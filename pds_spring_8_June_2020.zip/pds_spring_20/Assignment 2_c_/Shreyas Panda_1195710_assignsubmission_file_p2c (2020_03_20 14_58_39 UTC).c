/*NAME :SHREYAS RANJAN PANDA
ROLL NO :19ME10063
DEPARTMENT : MECHANICAL ENGINEERING
MACHINE NO :70 */
#include <stdio.h>
#include <math.h>
int main()
{
  double a,b,c,disc,D,x,y;
  scanf("%lf %lf %lf",&a,&b,&c);
  disc=b*b-4*a*c;
  if(disc<0){printf("the roots are complex");}
  D=sqrt(disc);
  x=-1*b/(2*a) + D/(2*a);
  y=-1*b/(2*a) - D/(2*a);
  printf("the roots are %lf and %lf",x,y);
  
  
  
  
}
