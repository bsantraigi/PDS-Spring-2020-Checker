/*Name: Humane Ashay Vijay
  Roll No: 19ME10025
  Dept: Mechanical Engineering
  Machine No: 25
*/
#include<stdio.h>
#include<math.h>
int main()
{
  float a,b,c,d,p,q,y;
  printf("Enter a, b, and c\n");
  scanf("%f%f%f",&a,&b,&c);
  d=b*b-4*a*c;
  y=sqrt(d);
  p=(-b+y)/(2*a);
  q=(-b-y)/(2*a);
  if(d<0){
    printf("Roots are complex");}
  else{
    printf("Roots=%f and %f",p,q);}
}
