#include<stdio.h>
#include<math.h>
/*program to find roots of quadratic equation*/
int main()
{
  float a,b,c,d;
  int x1,x2;
  printf("Enter a,b,c : ");
  scanf("%f %f %f",&a,&b,&c);
  d=b*b-4*a*c;
  if(d<0)
    printf("Roots are complex\n");
  else
    {
      x1=(-b+sqrt(d))/2*a;
      x2=(-b-sqrt(d))/2*a;
    
        printf("Roots = %d %d\n",x1,x2);
    }
}
  
