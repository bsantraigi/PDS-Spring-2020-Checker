/* Name = Gaurav Samaria
   Roll Number = 19MF10014
   Department = Mechanical Engineering
   System Number = 75 */

#include<stdio.h>
int main()
{  float a, b, result;
   int c;
   printf("To perform the following operation enter the corresponding number.\nAdd-1\nSub-2\nMult-3\nDiv-4\n");
   printf("Enter the corresponding number of the operation: ");
   scanf("%d",&c);
   printf("Enter the first number:");
   scanf("%f",&a);
   printf("Enter the second number:");
   scanf("%f",&b);

   switch(c)
   {
     case 1:
            result = a+b;
            break;
     case 2:
            result = a-b;
            break;
     case 3: 
            result = a*b;
            break;
     case 4:
        if(b!=0){  result = a/b;     }
        else    {   printf("The value of b connot be zero.\n");   }
            break;
     default: 
      printf("The entered operation is wrong.\n");
      break;
   }
printf("The result of the calculations is:%f\n",result);
}
