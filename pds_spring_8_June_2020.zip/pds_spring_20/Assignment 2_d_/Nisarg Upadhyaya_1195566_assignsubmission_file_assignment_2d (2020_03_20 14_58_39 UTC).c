/*
Name: Nisarg Upadhyaya
Roll Number: 19CS30031
Department: Computer Science and Engineering
Machine Number: 54
*/

/*Program to perform an operation on two numbers*/

#include <stdio.h>

int main()
{
	int choice;
	float n1,n2;

	printf("Enter the choice: ");
	scanf("%d",&choice);

	printf("Enter the two operands: ");
	scanf("%f %f",&n1,&n2);

	if(choice==4&&n2==0)
		printf("Division by 0 is not allowed.\n");
	else
	{	
		switch(choice)
		{
			case 1:
			printf("Result = %f\n",n1+n2);
			break;

			case 2:
			printf("Result = %f\n",n1-n2);
			break;

			case 3:
			printf("Result = %f\n",n1*n2);
			break;

			case 4:
			printf("Result = %f\n",n1/n2);
			break;
		}
	}

}
