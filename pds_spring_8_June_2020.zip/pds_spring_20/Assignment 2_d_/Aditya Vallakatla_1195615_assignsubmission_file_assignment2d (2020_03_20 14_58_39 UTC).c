/* Name : Aditya Vallakatla
 Roll No : 19CS30051
 Machine No : 11
 Department : Computer Science and Engineering */
/*Write a C program that asks user for an arithmetic operation (1-addition, 2-subtraction, 3-multiplication, 4-division) and two operands. Then it performs the corresponding calculations on the operands and prints the result.*/
#include<stdio.h>
int main()
{
  float a,b,d;
  int c;
  printf("Add-1\nSub-2\nMult-3\nDiv-4\n");
  printf("Enter the choice:");
  scanf("%d",&c);
  if(c==1 || c==2 || c==3 || c==4 )
 {
   printf("Enter the two operands:");
  scanf("%f%f",&a,&b);
    switch(c)
      {
      case 1:printf("Result:%f\n",a+b);
	break;
      case 2:printf("Result:%f\n",a-b);
	break;
      case 3:{d=a*b;
	  printf("Result:%f\n",d);}
	break;
      case 4:{d=a/b;
	  printf("Result:%f\n",d);}
	break;
      }
 }
    else
      printf("Only Addition,Substraction,Multiplication and Division will be done\n");
}
	
