/* NAME : SHREYAS RANJAN PANDA 
ROLL NO : 19ME10063
DEPT: MECHANICAL ENGINEERING 
MACHINE NO : 70 */
#include <stdio.h>
int main()
{
  int x;
  double a,b;
  printf("addition - 1, subtraction - 2, multiplication -3,division -4\n");
  scanf("%d",&x);
  printf("enter two numbers\n");
  scanf("%lf%lf",&a,&b);
  switch(x){
  case 1 : printf("a+b=%lf",a+b);
    break;
  case 2 : printf("a-b=%lf",a-b);
    break;
  case 3 : printf("a*b=%lf",a*b);
    break;
  case 4 : printf("a/b=%lf",a/b);
    break;
  default : printf("invalid input");};
}
