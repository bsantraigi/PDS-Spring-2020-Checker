/* Name: Patel Zeel Yogeshkumar
roll no:19ME10044
dept: Mechanical eng
Machine no:69 */

// program to perform operations on the operands & print the result

#include <stdio.h>
int main()
{
  float addition, subtraction, multiplication, division, result, oprd1, oprd2;
  int choice;
  printf("enter the choice:\n");
  scanf("%d", &choice);
  printf("enter the two operands:\n");
  scanf("%f%f", &oprd1, &oprd2);
  switch(choice)
  {
    case 1:
      // addition;
      result=oprd1+oprd2;
      printf("result=%f\n", result);      
            break;
    case 2://subtraction;
             result=oprd1-oprd2;
	     printf("result=%f\n", result);
	 
              break;
    case 3://multiplication;
	     result=oprd1*oprd2;
	     printf("result=%f\n", result);
               	break;
    case 4://division;
	        if (oprd2!=0)
		  { result=oprd1/oprd2;
		    printf("result=%f\n", result);}
	        else
	          printf("division not defined\n");
	      break;
    default:printf("no input\n");
       
  }
  
  return 0;
}
	  
	  
