#include<stdio.h>
int main()
{
  /*name- Shivam Lahoti
roll no.- 19AG10028
machine no.- 5
department- Agriculture and food engineering*/
  float a,b,d;
  int c;
  printf("add-1 \n sub-2 \n mult-3 \n div-4 \n enter your choice \n");
  scanf("%d",&c);
  printf("enter the two operands\n");
  scanf("%f%f",&a,&b);
  switch(c)
    {
    case 1:{
      d=a+b;
      break;}
    case 2:{
      d=a-b;
      break;}
    case 3:{
      d=a*b;
      break;}
    case 4:{
      d=a/b;
      break;}
    default : printf("invalid choice\n");
    }
  printf("result=%f \n",d);
}
