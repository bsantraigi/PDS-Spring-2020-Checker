/*NAME: ADARSH TRIPATHI
  ROLL NO.:19EX20002
  DEPT.:GEOLOGY AND GEOPHYSICS
  MACHINE NO.:17
*/
#include<stdio.h>
int main()
{
  float a,b,c;
  int choice;
  printf("enter the two operants \n");
  scanf("%f%f",&a,&b);
  printf("enter the operation you wish to perform\n for add:1 sub:2 multiply:3 divide:4 \n");
  scanf("%d",&choice);
  switch(choice)
  {
  case 1:
    c=a+b;
    printf("result:%f \n",c);
    break;
  case 2:
    c=a-b;
    printf("result:%f \n",c);
    break;
  case 3:
    c=a*b;
    printf("result:%f \n",c);
    break;
  case 4:
    if(b==0)
      printf("operation cannot be performed \n");
    else
      { c=a/b;
    printf("result:%f \n",c);
      }
    break;
  default:
    printf("no operation can be performed \n");
  }
}
    
	 
