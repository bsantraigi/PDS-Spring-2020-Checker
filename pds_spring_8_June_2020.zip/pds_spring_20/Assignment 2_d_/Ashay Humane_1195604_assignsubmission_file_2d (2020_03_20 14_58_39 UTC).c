/*Name: Humane Ashay Vijay
  Roll No: 19ME10025
  Dept: Mechanical Engineering
  Machine No: 25
*/
#include<stdio.h>
int main()
{
  float a,s,m,p,q,d;
  int x;
  printf("Add-1");
  printf("\nSub-2");
  printf("\nMult-3");
  printf("\nDiv-4");
  printf("\nEnter the choice:");
  scanf("%d",&x);
  switch(x){
  case 1:printf("Enter the two operands\n");
    scanf("%f%f",&p,&q);
    a=(p+q);
    printf("Result=%f",a);
    break;
  case 2:printf("Enter the two operands\n");
    scanf("%f%f",&p,&q);
    s=(p-q);
    printf("Result=%f",s);
    break;
  case 3:printf("Enter the two operands\n");
    scanf("%f%f",&p,&q);
    m=p*q;
    printf("Result=%f",m);
    break;
  case 4:printf("Enter the two operands\n");
    scanf("%f%f",&p,&q);
    d=p/q;
    printf("Result=%f",d);
    break;}
      
}  
