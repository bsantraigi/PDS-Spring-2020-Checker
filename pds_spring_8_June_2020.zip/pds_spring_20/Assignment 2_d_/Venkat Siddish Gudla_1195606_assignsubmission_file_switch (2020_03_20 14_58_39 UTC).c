/* Name:- Venkat Siddish Gudla
   Roll No:- 19EC30048
   Dept:- ECE
   System No:- 58*/
#include<stdio.h>
int main()
{
  int a,b,choice,add,sub,mult,div;
  scanf("%d%d%d",&a,&b,&choice);
  switch(choice)
    {
    case 1: add=(a+b);
      printf("result=%d\n",add);
      break;
    case 2: sub=(a-b);
      printf("result=%d\n",sub);
      break;
    case 3:mult=(a*b);
      printf("result=%d\n",mult);
      break;
    case 4:  div=(a/b);
      printf("result=%d\n",div);
      break;
    }
}

    
      
