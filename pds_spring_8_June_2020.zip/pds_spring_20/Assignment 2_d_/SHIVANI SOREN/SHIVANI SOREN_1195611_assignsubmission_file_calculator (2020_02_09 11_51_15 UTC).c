#include<stdio.h>
/*program which can add,sub,mult,div at the same time using switch*/
int main()
{
  int a,b,c,r;
  printf("Add-1\nSub-2\nMult-3\nDic-4\nEnter the choice :");
  scanf("%d",&c);
  printf("Enter the teo oprands : ");
  scanf("%d %d",&a,&b);
  switch(c)
  {
  case 1: r=a+b;break;
  case 2: r=a-b;break;
  case 3: r=a*b;break;
  case 4: r=a/b;break;
  }
  printf("Result = %d\n",r);
}
