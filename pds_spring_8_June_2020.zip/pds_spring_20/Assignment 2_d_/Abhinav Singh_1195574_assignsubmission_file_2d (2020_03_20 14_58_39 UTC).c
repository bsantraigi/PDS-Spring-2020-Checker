/*Abhinav Singh
19BT30001
Biotechnology
Machine No 43
*/
#include<stdio.h>
int main()
{
  int choice;
  double o1,o2,r;

  printf("Add-1\nSub-2\nMult-3\nDiv-4\nEnter the choice: ");
  scanf("%d",&choice);
  if(choice>4 || choice <1)
    {
      printf("Wrong Choice\n");
      return 0;
    }
  
  
    
  
  printf("Enter the two operands: ");
  scanf("%lf%lf",&o1,&o2);
  switch(choice)
    {
    case 1:
      {
	r=o1+o2;
	break;
      }
    case 2:
      {
	r=o1-o2;
	break;
      }
    case 3:
      {
	r=o1*o2;
	break;
      }
    case 4:
      {
	r=o1/o2;
	break;
      }
    default:
      {
	
      printf("Wrong Choice\n");
      return 0;
      }
      
    }
  printf("Result=%lf\n",r);
  
}

	
  
