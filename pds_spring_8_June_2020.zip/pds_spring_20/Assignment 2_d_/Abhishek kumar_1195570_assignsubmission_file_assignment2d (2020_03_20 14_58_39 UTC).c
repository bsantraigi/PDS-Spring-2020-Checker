/*
abhishek kumar
19MI31002
mining engineering
29
*/
#include <stdio.h>

int main()
{
int a;
  float b,c,d;
  printf("add-1\nsub-2\nmult-3\ndiv-4\n");
  printf("enter the choice: ");
  scanf("%d",&a);
printf("enter 2 operands");
scanf("%f%f",&b,&c);
  switch(a)
{
  case 1:d=b+c;printf("result= %f",d);break;
  case 2:d=b-c;printf("result= %f",d);break;
  case 3:d=b*c;printf("result= %f",d);break;
  case 4:d=b/c;printf("result= %f",d);break;
}

}
