/*Name Vaidehi Gupta
Dep Physics
Rol No 19PH20038
Machine No 34
*/

#include<stdio.h>
int main()
{
  int m;
  printf(" Add-1\n  Sub-2\n  Multi-3\n Div-4");
  printf("Enter the choice");
  scanf("%d",&m);
  printf("Enter the two operands");
  double r,s;
  scanf("%lf%lf",&r,&s);
  double x=0;
  switch(m)
    {
    case 1 : x=r+s;
      printf("result= %lf",x);
      break;
    case 2 : x=r-s;
      printf("result= %lf",x);
      break;
    case 3 : x=r*s;
      printf("result= %lf",x);
      break;
    case 4 : x=r/s;
      printf("result =%lf",x);
      break;
    }
}
       
       
