/*Name-Chandra Prakash
 Roll No.-19EE10018
 Dept-Electrical Engineering
 System No.-59*/
#include<stdio.h>
int main()
{
  int x,y,ch,z;
  scanf("%d%d%d",&x,&y,&ch);
  printf("ch=1: add\n");
  printf("ch=2: sub\n");
  printf("ch=3: multiply\n");
  printf("ch=4: divide\n");
  switch(ch)
    {
    case 1: z=x+y;
      printf("%d",z);
	break;
    case 2: z=x-y;
	printf("%d",z);
	break;
    case 3: z=x*y;
	  printf("%d",z);
	  break;
    case 4: z=x/y;
	  printf("%d",z);
	 
    }

  
}

