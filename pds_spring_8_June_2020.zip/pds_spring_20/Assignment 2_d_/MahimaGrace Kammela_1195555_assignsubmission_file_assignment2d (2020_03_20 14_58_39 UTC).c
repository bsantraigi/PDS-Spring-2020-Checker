/*Name: Kammela Mahima Grace
  Roll No: 19EE30010
  Dept: Electrical Engineering
  Machine No:16
*/ 

#include<stdio.h>
int main()
{
   int x;
   double y,z,a;
     printf("Enter the choice\nAdd-1\nSub-2\nMult-3\nDiv-4\n");
     scanf("%d",&x);
     switch(x)
      {
       case 1:
         printf("Enter the two operands\n");
         scanf("%lf%lf",&y,&z);
         a=y+z;
         printf("Result=%lf\n",a);
         break;
        case 2:
         printf("Enter the two operands\n");
         scanf("%lf%lf",&y,&z);
         a=y-z;
         printf("Result=%lf\n",a);
         break;
        case 3:
         printf("Enter the two operands\n");
         scanf("%lf%lf",&y,&z);
         a=y*z;
         printf("Result=%lf\n",a);
         break;
        case 4:
         printf("Enter the two operands\n");
         scanf("%lf%lf",&y,&z);
         a=y/z;
         printf("Result=%lf\n",a);
         break;     
      }
}   
             
