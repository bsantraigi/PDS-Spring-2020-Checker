//NAME:Avvaru Badri Visaal
//Roll number:19CH10013
//Dept:Chemical Engineering
//Machine number 8
#include<stdio.h>
int main()
{
  float a,b;
  int x;
  printf("Add-1\nSub-2\nMult-3\nDiv-4\n");
  printf("enter your choice:");
  scanf("%d",&x);
  printf("enter your two operands:");
  scanf("%f%f",&a,&b);
  switch(x)
    {
    case 1:printf("%f\n",a+b);
    break;
    case 2:printf("%f\n",a-b);
    break;
    case 3:printf("%f\n",a*b);
    break;
    case 4:printf("%f\n",a/b);
    break;
    default:
    printf("invalid choice\n");
    };
}
