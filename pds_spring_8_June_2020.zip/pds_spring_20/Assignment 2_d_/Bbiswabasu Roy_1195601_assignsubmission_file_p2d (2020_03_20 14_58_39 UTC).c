/*Name - Bbiswabasu Roy
  Roll - 19EC30008
  Dept - ECE
  Machine # - 56
*/
#include <stdio.h>
int main()
{
  printf("Add-1\nSub-2\nMult-3\nDiv-4\nEnter the choice: ");
  int c;
  scanf("%d",&c);
  printf("Enter the two operands: ");
  double a,b;
  scanf("%lf%lf",&a,&b);
  printf("Result=");
  switch(c){
  case 1:
    printf("%lf\n",a+b);
    break;
  case 2:
    printf("%lf\n",a-b);
    break;
  case 3:
    printf("%lf\n",a*b);
    break;
  case 4:
    if(b==0)
      printf("Not divisible\n");
    else
      printf("%lf\n",a/b);
    break;
  default:
    printf("Invalid option selected\n");
  };
}
