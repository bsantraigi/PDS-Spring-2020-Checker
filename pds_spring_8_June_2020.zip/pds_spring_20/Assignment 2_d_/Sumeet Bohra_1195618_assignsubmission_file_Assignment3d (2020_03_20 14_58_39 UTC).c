/*
Name - Sumeet Bohra
Roll - 19CS10059
Department - Computer Science and Engineering
Machine No. - 52
*/

#include <stdio.h>

void main()
{
    int choice;
    float a,b;
    printf("Press this key for \nAddition - 1 \nSubtraction - 2 \nMultiplication - 3 \nDivision - 4 \n");
    scanf("%d",&choice);
    printf("Enter two operands: \n");
    scanf("%f %f",&a,&b); 
    switch(choice)
    {
	case 1:
	    printf("Result = %f\n",a+b);
	    break;
	case 2:
	    printf("Result = %f\n",a-b);
	    break;
	case 3:
	    printf("Result = %f\n",a*b);
	    break;
	case 4:
	    printf("Result = %f\n",a/b);
	    break;
    }
}
