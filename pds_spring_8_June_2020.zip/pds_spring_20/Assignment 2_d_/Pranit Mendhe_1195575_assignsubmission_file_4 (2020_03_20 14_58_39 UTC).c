/*Pranit Mendhe
19ME30037
Mechanical Department
Machine no.:73*/

#include<stdio.h>
float main()
{
  int a;
  float b,c;
  printf("Enter your choice: ");
  scanf("%d",&a);
  printf("Enter the operands: ");
  scanf("%f%f",&b,&c);
  switch(a)
    {
  case 1: printf("Addition is %f\n",b+c);
    break;
  case 2:if(b>=c)
      printf("Subtraction is %f\n",b-c);
    break;
         if(b<c)
      printf("Subraction is %f\n",c-b);
	 break;
  case 3: printf("Multiplication is %f\n",b*c);
        break;
  case 4: if(c!=0)
      printf("Division is %f",b/c);
    if(c==0)
      printf("Division by zero is not accepted\n");
    break;
    }
}
