/*
name: m kavyasri
roll no:19ec10042
question:2d
*/
#include<stdio.h>
int main()
{
  int a,b,choice;
  float c;
  printf("enter your choice");
  scanf("%d",&choice);
  printf("enter any two values");
scanf("%d %d",&a,&b);
switch(choice)
{
case 1:c=a+b;
      break;
case 2:c=a-b;
      break;
case 3:c=a*b;
      break;
case 4:c=a/b;
      break;
}
  printf("%f",c); 
  return 0;
}

