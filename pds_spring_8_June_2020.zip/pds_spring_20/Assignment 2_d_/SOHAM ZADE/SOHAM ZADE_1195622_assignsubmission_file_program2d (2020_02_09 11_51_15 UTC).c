/* Name: Soham Zade
   Roll no: 19CH10053
   Machine no: 10
   Program with operators*/

#include<stdio.h>

int main()
{int i;
 float a,b;

  printf("Enter operation\n");
  scanf("%d", &i);

  printf("Enter operands\n");
  scanf("%f %f", &a, &b);

  switch(i)
    {
    case 1: printf("Result= %f\n", a+b);
    case 2: printf("Result= %f\n", a-b);
    case 3: printf("Result= %f\n", a*b);
    case 4: printf("Result= %f\n", a/b);
    }


}
