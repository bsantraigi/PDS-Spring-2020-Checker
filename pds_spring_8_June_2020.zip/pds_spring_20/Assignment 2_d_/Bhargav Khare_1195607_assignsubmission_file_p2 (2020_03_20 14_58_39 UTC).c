/*
NAME: BHARGAV KHARE
ROLL NO.:19NA30010
DEPT: OCEAN ENGINEERING AND NAVAL ARCHITECTURE
PC NO.:31*/
#include<stdio.h>
void main()
{
  float op1, op2,result=0;
  int num;
  //Asking for option
  printf("Add-1\n");
  printf("Sub-2\n");
  printf("Mult-3\n");
  printf("Div-4\n");
  printf("Enter ops\n");
  scanf("%f%f",&op1,&op2);
  
  printf("Enter the choice: \n");
  scanf("%d",&num);  
  //Calculating the operation
switch(num)
    {
      case 1:
	result=op1+op2;
	break;
      case 2:
	result=op1-op2;
	break;
      case 3:
	result=op1*op2;
	break;
      case 4:
	result=op1/op2;
	break;
    default://Invalid input
	printf("Invalid operaton.");
	break;
    }
  printf("Result= %f",result);
}
	  
	
	
      
  
