/*
 Name: B.vamshi krishna
 Roll: 19CS10019
 Dept: computer science and engineering
 Machine number: 50
*/
# include<stdio.h>
#include<math.h>
int main()
 { 
   int number,a,b;
   printf("\nenter the two operands(numbers)\n");
   scanf("%d%d",&a,&b);
   printf("\nTo add the numbers ,enter 1\nTo subtract the numbers ,enter 2\nTo multiply the numbers ,enter 3\nTo divide the  numbers ,enter 4\n");
   scanf("%d",&number);
   printf("you selected %d",number);
   switch(number)
   {
     case 1:
            a=a+b;
            printf("\nyour result is %d",a);
            break;
     case 2:
            a=a-b;
            printf("\nyour result is %d",a);
            break;
     case 3:
            a=a*b;
            printf("\nyour result is %d",a);
            break;
     case 4:
            a=a/b;
            printf("\nyour result is %d",a);
            break;
     default:
            printf("\nenter your choice");
   }
}

