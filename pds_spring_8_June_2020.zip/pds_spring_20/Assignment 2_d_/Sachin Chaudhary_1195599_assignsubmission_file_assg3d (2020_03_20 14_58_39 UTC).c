/*Name:Sachin Chaudhary
Roll no.=19MA20045
Dept=Mathematics
Machine No.=23

Program to perform calculation omn operands and calculate the result*/
#include <stdio.h>
int main()
{
  float b,c,r;
  int a;
  printf("Add-1\nSub-2\nMult-3\nDiv-4");
  scanf("%d",&a);
  printf("Enter the operands:");
  scanf("%f %f",&b,&c);
  switch(a)
   {case 1:r=c+b;
    break;
    case 2:r=b-c;
    break;
    case 3:r=b*c;
    break;
    case 4:r=b/c;
break;
   }
  printf("Result:%f",r);
}
      
  
  
    
