/* Name-Vineet Anand
   Roll-19GG20041
   Dept-GG     
   Machine Number-62 */
#include<stdio.h>
#include<math.h>
int main()
{ int a,b;
  int s;
  
  printf(" Add-1\n Sub-2 \n mul-3 \n Div-4 \n");
  printf("Enter your choice\n");
  scanf("%d",&s);
  printf("enter two operands");
  scanf("%d%d",&a,&b);
  switch(s)
    { case 1: printf("%d",a+b);
	break;
    case 2: printf("%d",a-b);break;
      
    case 3: printf("%d",a*b);break;
    case 4:
      if(b==0)
	{
	  printf("not defined");
	}else{
        printf("%d",a/b);}
	break;
    }
  
}
