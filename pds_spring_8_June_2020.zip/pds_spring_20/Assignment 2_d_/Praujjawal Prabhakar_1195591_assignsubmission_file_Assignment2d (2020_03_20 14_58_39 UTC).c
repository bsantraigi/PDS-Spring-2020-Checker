/*PRAUJJAWAL PRABHAKAR*/
/*19CE10051    Section4*/
/*Assignment 2d*/

#include<stdio.h>
int main()
{
  float a,b;
  int choice;
  printf("Enter the choice\n");
  scanf("%d", &choice);
  printf("Enter two operands\n");
  scanf("%f%f", &a, &b);
  switch(choice)
    {
    case 1: printf("Addition = %f\n", a+b);
      break;
    case 2: printf("Subtraction =%f\n", a-b);
      break;
    case 3: printf("Multiplication =%f\n", a*b);
      break;
    case 4: printf ("Division =%f\n", a/b);
      break;
    }
}

      
