/* 
name: Arun Nair
Roll: 19IE10008
Dep: EE
System: 64
Section 4
*/

#include <stdio.h>
int main()
{
  int x;
  float a,b,c;

  printf("Add-1\n");
  printf("Sub-2\n");
  printf("Mult-3\n");
  printf("Div-4\n");
    
  printf("Enter Choice:");
  scanf("%d",&x);
  printf("Enter the two operands:");
  scanf("%f %f",&a,&b);
  switch(x){
  case 1:c=a+b;
    printf("Result:%f\n", c);
    break;
  case 2:c=a-b;
    printf("Result:%f\n", c);
    break;
  case 3:c=a*b;
    printf("Result:%f\n", c);
    break;
  case 4:c=a/b;
    printf("Result:%f\n", c);
    break;
  }
}
  
