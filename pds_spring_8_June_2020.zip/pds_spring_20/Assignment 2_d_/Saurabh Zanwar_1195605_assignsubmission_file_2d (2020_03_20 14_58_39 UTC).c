#include<stdio.h>
int main()
{
  int c;
  float a,b;
  printf("Enter 1-addition, 2-subtraction, 3-multiplication, 4-division");
  scanf("%d",&c);
  printf("Enter operands");
  scanf("%f%f",&a,&b);
  switch (c)
    {
    case 1:
      printf("a+b= %f",a+b);
      break;
    case 2:
      printf("a-b= %f",a-b);
      break;
    case 3:
      printf("a*b= %f",a*b);
      break;
    case 4:
      printf("a/b= %f",a/b);
      break;
    }
}
	
