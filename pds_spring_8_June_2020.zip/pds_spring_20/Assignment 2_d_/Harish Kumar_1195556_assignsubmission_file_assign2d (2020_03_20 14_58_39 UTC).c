/*
Harish Kumar
19CE10031
Machine 46
*/

#include <stdio.h>

int main()
{
  int f;
  double a,b,r=0;
  printf("Add-1\nSub-2\nMult-3\nDiv-4\n");
  printf("Enter the choice: ");
  scanf("%d",&f);
  printf("Enter the two operands: ");
  scanf("%lf %lf",&a,&b);
  switch(f)
  {
  case 1: r=a+b;
    break;
  case 2: r=a-b;
    break;
  case 3: r=a*b;
    break;
  case 4:
    if(b==0)
      printf("Zero error");
    else
      r=a/b;
  }
  printf("Result=%lf\n",r);
}
