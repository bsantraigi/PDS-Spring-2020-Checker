/*
name; shivam hurkat
roll no:19HS20018
machine no:63
dept:hss*/
#include<stdio.h>
int main()
{
  int opt,x,y,z ;
  printf("Enter the choice: \n");
  scanf ("%d",&opt);
  printf("Enter the two operands:\n");
  scanf("%d%d",&x,&y);
  switch(opt){
  case 1:z=x+y;
      break;
  case 2:z=x-y;
      break;
  case 3:z=x*y;
      break;
  case 4:
    if(y!=0)z=x/y;
    else
      printf("cannot divide by zero\n");
  default:printf("Error");
  }
  printf("Result= %d\n",z);
}
