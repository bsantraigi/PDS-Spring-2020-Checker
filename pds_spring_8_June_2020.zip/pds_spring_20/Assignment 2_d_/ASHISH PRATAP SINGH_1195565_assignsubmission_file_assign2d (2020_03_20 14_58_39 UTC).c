/* ASHISH PRATAP SINGH 
   19CE10011
   CIVIL ENGINEERING DEPARTMENT
   MACHINE NO.-45
*/
 
#include <stdio.h>

int main()
{
  int c;
  double a,b,result1,result2,result3,result4;
  printf("Add-1\nSub-2\nMult-3\n Div-4\n");
  
  printf("Enter your choice:");
  scanf("%d",&c);
  printf("Enter two operands:");
  scanf("%lf %lf",&a,&b);
  switch(c)
    {case 1:
	result1 =a+b;
	printf("a+b=%lf\n",result1);
	break;
    case 2:
      result2 =a-b;
      printf("a-b=%lf\n",result2);
      break;
    case 3:
      result3 = a*b;
      printf("a*b=%lf\n",result3);
      break;
    case 4:
      result4 = a/b;
      printf("a/b=%lf\n",result4);
      break;
    }
}
    
  
      
  
