/*Name:Manusani Vaishnavi
Roll.no:19MA20026
Dept:Math and Computing
Sys no:22*/
#include <stdio.h>
int main()
{float a,b,res;
  int c;
  printf("Add-1\nSub-2\nMult-3\nDiv-4\nEnter the choice:");
  scanf("%d",&c);
  printf("Enter the two operands:");
  scanf("%f %f",&a,&b);
  switch(c)
    { case 1:
    res=a+b;
  break;
  case 2:
    res=a-b;
    break;
    case 3:
      res=a*b;
      break;
      case 4:
	res=a/b;
	break;}
  printf("Result=%f",res);
}
  
