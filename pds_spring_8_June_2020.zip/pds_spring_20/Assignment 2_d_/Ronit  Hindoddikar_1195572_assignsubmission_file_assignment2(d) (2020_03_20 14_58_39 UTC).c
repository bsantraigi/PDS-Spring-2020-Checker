#include<stdio.h>

/*Name-Ronit Hindoddikar
  Roll no-19MT30016
  Section-4 
  Department- Metallurgical and Materials Engineering*/

int main()
{
 	int b,a,d,r;
 	printf("Add-1 \n"); 
  	printf("Sub-2 \n"); 
        printf("Mult-3 \n"); 
 	printf("Div-4 \n");
	printf("Enter the choice \n"); 
 	scanf("%d",&d);
 	switch(d)
	{
		case 1:
 			{
				printf("enter the two operands \n");  
 				scanf("%d%d",&a,&b);
				r=a+b;
				printf("Result= %d",r);
				break;
			}
		case 2:
 			{
				printf("enter the two operands \n");  
 				scanf("%d%d",&a,&b);
				r=a-b;
				printf("Result= %d",r);
				break;
			}
		case 3:
 			{
				printf("enter the two operands \n");  
 				scanf("%d%d",&a,&b);
				r=a*b;
				printf("Result= %d",r);
				break;
			}
		case 4:
 			{
				printf("enter the two operands \n");  
 				scanf("%d%d",&a,&b);
				if(b==0)
				{
					printf("division cannot take place with 						denominator as 0");
					break;
				}
				else
				{
					r=a/b;
					printf("Result= %d",r);
					break;
				}
			}
	}
 
 
   
}
