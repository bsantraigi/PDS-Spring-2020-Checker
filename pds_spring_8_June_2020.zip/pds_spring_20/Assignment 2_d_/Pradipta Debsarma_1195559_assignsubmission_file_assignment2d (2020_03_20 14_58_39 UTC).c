/* Name- Pradipta Debsarma
   Roll-19MT10030
   Depth-Metallurgical and Materials Science Engineering
   System N.o-78 
*/
#include<stdio.h>
int main()
{ 
  int x;
  float a,b,result;
  printf("Enter arithmetic operation 1 for addition,2 for subtraction,3 for multiplication,4 for division\n");
  scanf("%d",&x);
	
  switch(x)
  { 
    case 1: 
	    printf("Enter operands for addition");
            scanf("%f%f",&a,&b);
            result=a+b;
            printf("%f",result);
            break;
    case 2: printf("Enter operands for subtraction");
            scanf("%f%f",&a,&b);
            result=a-b;
            printf("%f",result);
            break;
    case 3 :printf("Enter operands for multiplication");
            scanf("%f%f",&a,&b);
            result=a*b;
            printf("%f",result);
            break;
    case 4 :printf("Enter operands for division");
            scanf("%f%f",&a,&b);
            result=a/b;
            printf("%f",result);
            break;
    default :printf("Invalid Input");
  }
}

   
