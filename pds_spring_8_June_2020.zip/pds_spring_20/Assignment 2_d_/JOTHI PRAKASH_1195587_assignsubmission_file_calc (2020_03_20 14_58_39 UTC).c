/*
NAME- P JOTHI PRAKASH
ROLL NO-19EC30028
DEPARTMENT-ECE
MACHINE NUMBER - 57 
 */

#include<stdio.h>

int main()
{
   int input;
  float num1,num2,res;
  printf("Add-1\nSub-2\nMult-3\nDiv-4\nEnter the choice: ");
  scanf("%d",&input);
  printf("Enter the two operands\n");
  scanf("%f%f",&num1,&num2);
  
  //Checking the input and calculating result 
  
switch(input)
    {
    case 1:res=num1+num2;
      break;
       case 2:res=num1-num2;
      break;
       case 3:res=num1*num2;
      break;
       case 4:res=num1/num2;
      break;     
    }
  printf("Result=%f\n",res);
  
  return 0;
}
