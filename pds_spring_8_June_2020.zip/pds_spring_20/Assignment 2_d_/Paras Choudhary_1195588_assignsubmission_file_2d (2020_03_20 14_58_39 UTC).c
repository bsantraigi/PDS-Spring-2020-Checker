/*paras Choudhary
19GG20022
sec 4
System 20
*/
#include <stdio.h>
#include <math.h>

int main()
{
int x;
float a, b, c;

scanf("%d %f %f "&x &a &b);

switch(x)
{

case 1 : c = a+b;
         break;
case 2 : c = a-b;
         break;
case 3 : c = a*b;
         break:
case 4 : c = a/b;
         break;




}

printf("%f",c);








}
