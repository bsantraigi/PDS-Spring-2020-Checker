/*A program to perform arithmetic operations according to the input*/
#include<stdio.h>
int main()
{
  int x;
  float a,b;
  printf("\nAdd-1\nSub-2\nMult-3\nDiv-4\nEnter your choice and two operands:");
  scanf("%d%f%f",&x,&a,&b);
  switch(x){
  case 1:printf("Result=%lf",a+b);
    break;
  case 2:printf("Result=%lf",a-b);
    break;
  case 3:printf("Result=%lf",a*b);
    break;
  case 4:printf("Result=%lf",a/b);
    break;
  default:printf("\nInvalid choice");
  }
}
    

    
