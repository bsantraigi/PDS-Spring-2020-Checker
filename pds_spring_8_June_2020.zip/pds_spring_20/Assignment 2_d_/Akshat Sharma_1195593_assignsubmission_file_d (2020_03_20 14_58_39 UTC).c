/*
NAME::Akshat Sharma
ROLL NO.::19EC10002
DEPT::Electronics and Electrical COmmunication Engineering
MACHINE NO.::13			       
*/

/*
Write a C program that asks user for an arithmetic operation (1-addition, 2-subtraction, 3-multiplication, 4-division) and two operands. Then it performs the corresponding calculations on the operands and prints the result.
*/

#include<stdio.h>

int main()
{
  int choice;
  float o1,o2,r;
  printf("Add-1\nSub-2\nMult-3\nDiv-4\nEnter the choice: ");
  scanf("%d",&choice);
  printf("Enter the two operands: ");
  scanf("%f %f",&o1,&o2);
  switch(choice)
    {
    case 1: r=(o1+o2);
      printf("Result = %f\n",r);
      break;
    case 2: r=(o1-o2);
      printf("Result = %f\n",r);
      break;
    case 3: r=(o1*o2);
      printf("Result = %f\n",r);
      break;
    case 4: r=(o1/o2);
      printf("Result = %f\n",r);
      break;
    default : printf("Invalid selection\n");
    }
  return 0;
}

  
      
