/*Name:Shobhyam Chakravarty
Roll No.:19NA10029
Department:Ocean Engineering And Naval Architecture
Machine No.:82*/
#include<stdio.h>

int main()
{
  float a,b,r;
  int x;
  printf("Add-1\nSub-2\nMult-3\nDiv-4\nEnter The Choice:");
  scanf("%d",&x);
  printf("Enter the two operands:");
  scanf("%f%f",&a,&b);
  switch(x){
  case 1:
    r=a+b;
    break;
  case 2:
    r=a-b;
    break;
  case 3:
    r=a*b;
    break;
  case 4:
    r=a/b;
    break;
  default :
    printf("Incorrect Input");
  }
  printf("Result=%f",r);
}
  
    
      
  
