/*name: ragini laskar
roll no:19MI33016
DEP:mining
machine no.:76*/
#include<stdio.h>
int main(){
  int x;
  float a,b;
 
  scanf("%d%f%f",&x,&a,&b);
  switch(x){
  case 1:printf("%f",a+b);break;
  case 2:printf("%f",a-b);break;
  case 3:printf("%f",a*b);break;
  case 4:printf("%f",a/b);break;
  default:printf("enter a valid number");}
  }
