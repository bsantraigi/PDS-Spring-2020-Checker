/*Name:A.N.V.S.Bhargavi
Rollno:19AE10004
Dept:Aerospace
Machine no:01*/
#include<stdio.h>
int main()
{
  int c;
  float op,x,y;
  printf("Add-1\nSub-2\nMult-3\nDiv-4\n");
  printf("Enter the choice:");
  scanf("%d",&c);
  printf("Enter the operands:");
  scanf("%f%f",&x,&y);
  switch(c)
    {
    case 1:op=x+y;
      printf("Result:%f",op);
      break;
    case 2:op=x-y;
      printf("Result:%f",op);
      break;
    case 3:op=x*y;
      printf("Result:%f",op);
      break;
    case 4:op=x/y;
      printf("Result:%f",op);
    }
}
  
