/*
Name : S. Sai Narayan
Roll Number : 19QD30014
Department : Quality Engineering Design Manufacture
Machine Number : 35
*/ 

//header files
#include<stdio.h>

//main function
int main()
{
  //variable declarations
  int op;
  float a,b;
  printf("\nAdd-1\n\nSub-2\n\nMult=3\n\nDiv-4\n\nEnter the choice: ");
  scanf("%d",&op);  //accepting choice
  printf("\nEnter the two operands: ");
  scanf("%f%f",&a,&b);
  printf("\nResult=");
  switch(op)
    {
    case 1:
      printf("%f\n",a+b); //addition
      break;
    case 2:
      printf("%f\n",a-b);  //subtraction
      break;
    case 3:
      printf("%f\n",a*b);  // multiplication
      break;
    case 4:
      if(b!=0)
        printf("%f\n",a/b);  // division
      else
	printf("divide by zero error\n");  //division by zero error
      break;
    }
}  
      
  
