/*Assignment1*/
/*Name-Tushar Bokade
Roll-19CS30011
Dept-Computer Science And Engineering
Machine No.-53*/
#include <stdio.h>
int main()
{int a,b,choice,add,sub,mult;
 float div;
  printf("Enter  the choice:");
  scanf("%d",&choice);
  printf("Enter  the two operands:");
  scanf("%d%d",&a,&b);
  switch (choice){
  case 1 :printf("Result=%d\n",add=a+b);
    break;
  case 2 :printf("Result=%d\n",sub=a-b);
    break;
  case 3 :printf("Result=%d\n",mult=a*b);
    break;
  case 4 :printf("Result=%f\n",div=(float)a/b);
    break;
  }
}  
