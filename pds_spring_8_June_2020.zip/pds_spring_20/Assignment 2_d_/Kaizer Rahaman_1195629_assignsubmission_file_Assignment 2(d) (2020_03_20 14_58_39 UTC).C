/* Name       : Kaizer Rahaman
   Roll No    : 19NA10010
   Department : Ocean Engineering and Naval Architecture
   Machine No : 81
*/

#include <stdio.h>
#include <math.h>

int main()
{
  int choice;
  float n1,n2;
  printf("Add-1\nSub-2\nMult-3\nDiv-4\n");
  printf("Enter the choice : ");
  scanf("%d",&choice);
  printf("\nEnter the two Operands : ");
  scanf("%f%f",&n1,&n2);
  printf("\nResult : ");
  switch(choice)
    {
    case 1:
      printf("%f",(n1+n2));
      break;
    case 2:
      printf("%f",(n1-n2));
      break;
    case 3:
      printf("%f",(n1*n2));
      break;
    case 4:
      printf("%f",(n1/n2));
      break;
    };
}
      
