/* Name Akanksha Agrawal*/
/*sec 4 machine no. 19*/
/*roll no. 19GG20003*/
/*Dept Geology and Geophysics*/
#include<stdio.h>

int main()
{ int op,a,b,c;
  printf("Add-1\n");
  printf("subtract-2\n");
  printf("multiply-3\n");
  printf("divide-4\n");
  printf("enter your choice\n");
  scanf("%d",&op);
  printf("enter two operands\n");
  scanf("%d%d",&a,&b);
  
  switch(op)
    {
    case 1 : //add
      c=a+b;
     
      break;
    case 2 :  //subtract
      c=a-b;
     
      break;
    case 3:  //multiply
      c=a*b;

	break;
    case 4:  //divide
      c=a/b;

      break; }
  printf("result=%d",c);
}
