/*Himanshu Kumar
Mechanical Engineering
19ME30018
mach no=72*/
#include<stdio.h>
#include<math.h>
int main()
{int ch;
  float r,a,b;
  printf("Enter the choice:");
  scanf("%d",&ch);
  printf("Enter two operands:");
  scanf("%f",&a);
  scanf("%f",&b);
  switch(ch)
    {case 1: r=a+b;break;
    case 2: r=a-b;break;
    case 3: r=a*b;break;
    case 4: r=(float)(a/b);break;
    default : printf("Wrong Choice");
    }
  printf("Result=%f",r);
}
