/*Name:Kodi Shree Harsha
Roll No:19AE30009
Machine No:3
Department:Aerospace*/

#include<stdio.h>
int main()
{
  float A,B,C;
  char x;
  printf("Enter the values:");
  scanf("%f %f %c",&A,&B,&x);
  
  switch(x){
  case '+': C=A+B;
  break;
  case '-':C=A-B;
    break;
  case '*': C=A*B;
    break;
  default:C=A/B;}
    
  
  printf("%f",C);
  return(0);
    }
