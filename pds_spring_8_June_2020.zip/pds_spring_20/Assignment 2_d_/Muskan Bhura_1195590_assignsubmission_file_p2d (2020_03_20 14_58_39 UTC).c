/*Name; Muskan Bhura
Roll No.: 19PH20019
Dept: Physics
Machine No.: 33*/
#include<stdio.h>
void main()
{
  int x;
  double a, b;
  printf("Add-1\nSub-2\nMult-3\nDiv-4\n");  //performing arithmetic operations 
  printf("Enter the choice:");
  scanf("%d",&x);
  printf("Enter two operands:");
  scanf("%lf%lf",&a,&b);
  switch(x)
    {
    case 1:
      printf("Result:%lf\n",(a+b));
      break;
    case 2:
      printf("Result:%lf\n",(a-b));
      break;
    case 3:
      printf("Result:%lf\n",(a*b));
      break;
    case 4:
      if(b==0)
	printf("Division not possible\n");
      else
	printf("Result:%lf\n",(a/b));
      break;
    default:
      printf("Enter a valid choice");
    }
}
	
      
    
      

  
