/*
NAME-VATSAL VENKATKRISHNA
ROLLNO-19NA30029
DEPARTMENT-OCEAN ENGINEERING AND NAVAL ARCHITECTURE
MACHINE NO-32
*/
#include<stdio.h>
void main()
{
  int ch=0;
  double a=0.0,b=0.0;
  printf("Add-1\nSubtract-2\nMultiply-3\nDivide-4\nEnter the choice: ");
  scanf("%d",&ch);
  printf("Enter the 2 operands\n");
  scanf("%lf%lf",&a,&b);
  switch(ch)
    {
    case 1: printf("Result=%lf\n",(a+b));
      break;
    case 2: printf("Result=%lf\n",(a-b));
      break;
    case 3: printf("Result=%lf\n",(a*b));
      break;
    case 4: if(b==0)
	{
	  printf("Division not possible");
	  break; 
	}
            printf("Result=%lf\n",(a/b));
      break;
    default: printf("Enter a valid choice\n");
    }
  
}
