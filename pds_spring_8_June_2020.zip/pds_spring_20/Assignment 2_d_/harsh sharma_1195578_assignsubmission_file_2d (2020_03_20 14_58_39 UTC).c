/*Name - Harsh Sharma 
  Roll No. - 19AG30010
  Department - Agricultural And Food Engineering
  Machine No. - 41 */
#include<stdio.h>
int main()
{
  float a,b;
  int c;
  printf("Add - 1 \nSub - 2 \nMultiply - 3\nDivide - 4\nEnter the choice : ");
  scanf("%d",&c);
  printf("Enter the operands :");
  scanf("%f%f",&a,&b);
  switch(c)
    {
    case 1 : printf("Result = %f\n",a+b);
             break;
    case 2 : printf("Result = %f\n",a-b);
             break;
    case 3 : printf("Result = %f\n",a*b);
             break;
    case 4 : printf("Result = %f\n",a/b);
             break;
    default : printf("Enter the correct choice\n");
    }
  return 0;
}
