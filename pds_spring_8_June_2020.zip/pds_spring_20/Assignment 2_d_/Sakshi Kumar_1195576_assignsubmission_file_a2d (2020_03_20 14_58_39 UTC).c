/*
Sakshi Kumar
19IE10027
Electrical Engineering
Machine no. 65
*/

#include<stdio.h>
int main()
{
  
  int a, b,c,d,e,f,g;
  printf("Add-1\n");
  printf("Sub-2\n");
  printf("Mult-3\n");
  printf("Div-4\n");
  printf("Enter the choice:\n");
  scanf("%d",&a);
  printf("Enter the two operands:\n");
  scanf("%d%d",&b,&c);
  switch(a)
    {
    case 1: d=b+c;
            printf("Result=%d\n",d);
            break;
    case 2: e=b-c;
            printf("Result=%d\n",e);
            break;
    case 3: f=b*c;
            printf("Result=%d\n",f);
            break;
    case 4: g=b/c;
            printf("Result=%d\n",g);
            break;
    default:printf("Enter a valid operation\n",d);
    }
}
  
	    
	    
    
