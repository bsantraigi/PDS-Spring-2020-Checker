/* Name:S.L.S.Sai Rishyendra;
   Rollno:19EC10062;
   Dept:E&ECE;
   Machine No:55 */
#include<stdio.h>
int main()
{
  float a,b,c;
  int choice;
  printf("enter the choice:");
  scanf("%d",&choice);
  printf("two operands are:");
  scanf("%f%f",&a,&b);
  switch(choice)
    {
    case 1:     c=a+b;
            printf("result=%f\n",c);
	    break;
    case 2:     c=a-b;
            printf("result=%f\n",c);
            break;
    case 3:     c=a*b;
            printf("result=%f\n",c);
	    break;
    case 4: if(b!=0){    c=a/b;
	              printf("result=%f\n",c);}
            else printf("error in divison");
	    break;
    default: printf("incorrect choice\n");

    }
}
