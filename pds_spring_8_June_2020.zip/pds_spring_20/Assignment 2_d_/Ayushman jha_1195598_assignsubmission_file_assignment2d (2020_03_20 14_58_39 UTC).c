#include<stdio.h>

int main()
{

int x;
float a,b;

printf("ENTER TWO NUMBERS \n ");
scanf("%f%f" ,&a,&b);

printf("PRESS 1 FOR ADDITION  \n");
printf("PRESS 2 FOR SUBTRACTION  \n");
printf("PRESS 3 FOR MULTIPLICATION  \n");
printf("PRESS 4 FOR DIVISION  \n");

scanf("%d" ,&x);

switch(x){

case 1 : printf("  RESULT = %0.f \n",a+b);
break;

case 2 : printf(" RESULT= %0.f \n",a-b);
break;

case 3 : printf("  RESULT = %0.f \n",a*b);
break;

case 4 : printf("  RESULT = %0.2f \n",a/b);
break;

}


}
