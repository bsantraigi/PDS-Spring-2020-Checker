/*Name-Aryan Raj lohani
Roll no - 19mt10011
system no-77*/s

#include<stdio.h>
int main(){
	int x;
	float a,b;
	printf("Add-1\nSub-2\nMult-3\nDiv-4 enter your choice ");
	scanf("%d%f%f",&x,&a,&b);
	
	switch(x){
	case 1:printf("the sum is %f",a+b);break;
		
	case 2:printf("the subtraction is %f",a-b);break;
	
	case 3:printf("the product is %f",a*b);break;

	case 4:printf("the division is %f" ,a/b);break;

	default:printf("enter a valid operand");
}


	return 0;
}
