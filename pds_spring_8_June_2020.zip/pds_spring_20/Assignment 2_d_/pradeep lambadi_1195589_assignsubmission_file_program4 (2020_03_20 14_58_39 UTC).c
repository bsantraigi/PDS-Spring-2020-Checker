/* name:l.Pradeep;
     sec:4;
     roll no:19EE10038;
     dept:Electrical ;
     mac no:60   */
#include<stdio.h>
int main()
{
  int value;
  float x,y;
  printf("enter this key for addition-1, subtraction-2, multiplication-3, division4");
  scanf("%d",&value);
  printf("enter the two operends");
  scanf("%f%f",&x,&y);
  switch(value)
  {
  case 1:
    printf(" answer=%f",x+y);
    break;
  case 2:
    printf("answer=%f",x-y);
    break;
  case 3:
    printf("answer=%f",x*y);
    break;
  case 4:
    printf("answer=%f",x/y);
    break;
  }
}
