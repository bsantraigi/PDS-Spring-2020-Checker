/*
NAME: Kaushal Banthia
ROLL: 19CS10039
DEPT: Computer Science and Engineering
Machine Number: 51
*/
#include <stdio.h>
#include <math.h>
void main()
{
  printf("Add-1\nSub-2\nMult-3\nDiv-4\nEnter the choice: ");
  int a;
  scanf("%d", &a);
  printf("Enter the two operands ");
  float o1, o2,r;
  scanf("%f %f", &o1, &o2);
  switch(a)
    {
    case 1:
      r = o1+o2;
      printf("Result=%f\n", r);
      break;
    case 2:
      r = o1-o2;
      printf("Result=%f\n", r);
      break;
    case 3:
      r = o1*o2;
      printf("Result=%f\n", r);
      break;
    case 4:
      if(o2!=0)
      {
        r = o1/o2;
        printf("Result=%f\n", r);
      }
      else
      printf("ERROR\n");
      break;
    default:
      printf("You did not enter a correct operation\n");
    }
}
