/*Name:Ayush Daksh
Roll No:19MA20007
Dept:MAthematics and Computing
System no:21
*/
// c program to do arithmetic operation on operands
#include<stdio.h>

int main()
{
  float a,b;
  int i;
  printf("Add-1\nSub-2\nMult-3\nDiv-4\n"); 
  printf("Enter the choice:");
  scanf("%d",&i);				//enter the choice
  printf("Enter the two operands:");
  scanf("%f%f",&a,&b);				//entering the operands
  switch(i)					//using switch to test inside conditions
    {						
    case 1:
	printf("Result= %f",a+b);
	break;
    case 2:
	printf("Result= %f",a-b);
	break;
    case 3:
	printf("Result= %f",a*b);
	break;
    case 4:
	printf("Result= %f",a/b);
	break;
   }
}
  
