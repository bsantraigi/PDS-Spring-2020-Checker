/*Name-Jay Dutonde
section-4
roll no.-19CH30008
machine no.-48*/
#include<stdio.h>
int main()
{
  int choice;
  float a,b;
  printf("enter the operands");
  scanf("%f%f",&a,&b);
  printf("add-1 subs-2 multi-3 div-4");
  printf("\nenter the choice");
  scanf("%d",&choice);
  switch(choice)
    {
    case 1:printf("%f\n",a+b);
      break;
    case 2:printf("%f\n",a-b);
      break;
    case 3:printf("%f\n",a*b);
      break;
      
    case 4:if(b!=0)
	{
	  printf("%f\n",a/b);
	}
      else
	{
	  printf("invalid operation\n");
	}
      break;
    default: printf("invalid operation\n");
    }
  return 0;
}
