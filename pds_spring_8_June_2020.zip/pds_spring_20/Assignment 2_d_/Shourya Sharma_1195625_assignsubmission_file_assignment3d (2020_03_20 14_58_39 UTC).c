/*NAME-SHOURYA SHARMA
  SEC-4
  MACHINE N0-67
  DEPT-INDUSTRIAL AND SYSTEM ENGINEERING*/
#include<stdio.h>
int main()
{ 
  float a,b,c;
   int  n;
  printf("Enter the case \n 1.ADD \n 2.SUBTRACT \n 3.MULTIPLE \n 4.DIVIDE \n enter the choice");
  scanf("%d",&n);
    switch(n)
      { case 1:  printf("Enter the two operants\n");
	  scanf(" %f %f",&a,&b);
	  printf("%f\n",c=(a+b));
	  break;
      case 2 :  printf("Enter the two operants\n");
	scanf(" %f %f",&a,&b);
	printf("%f\n",c=(a-b));
	break;
      case 3:  printf("Enter the two operants\n");
	scanf(" %f %f",&a,&b);
	printf("%f\n",c=a*b);
	break;
      case 4:  printf("Enter the two operants\n");
	scanf(" %f %f",&a,&b);
	printf("%f\n",c=a/b);
	break;
      default :printf("wrong choice");};
}
