/*Duhita Wani
19ME10082
Mechanical Engineering
Machine no - 71*/

#include<stdio.h>
int main()
{ float a,b,c;
  int x;
  printf("Add-1\n Sub-2\n Mult-3\n Div-4\n");
  printf("Enter the choice-\n");
  scanf("%d",&x);
  printf("Enter the two operands-\n");
  scanf("%f%f",&a,&b);
  
  switch(x){
   case 1: c=a+b;
            printf("%f\n",c); break;
   case 2: c=a-b;
            printf("%f\n",c); break;
   case 3: c=a*b;
            printf("%f\n",c); break;
   case 4: c=a/b;
            printf("%f\n",c); break;
  }
  return 0;
  }

    
