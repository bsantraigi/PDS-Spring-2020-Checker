/* name=a.shivani
roll no=19ME10006
depatment=mechanical
system n0=24*/
#include<stdio.h>
int main()
{ int number,reverse=0,remainder;
  printf("enter the 3-digit number\n");
  scanf("%d",&number);
  while(number>0)
  {remainder=number%10;
  reverse=reverse*10+remainder;
  number=number/10;
  }
 printf("the reverse number is %d\n",reverse);
} 
