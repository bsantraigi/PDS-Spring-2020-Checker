#include<stdio.h>
int main()
{
  /*
   Subhadeep Paul
   19EE10057
   Electrical Engineering
   61
   */
  float a,b;
  int ch;
  printf("Enter choice:-");
  scanf("%d",&ch);
  printf("Enter two operands:-");
  scanf("%f%f",&a,&b);
  switch(ch)
 {
	case 1:printf("Result=%f",a+b);
	       break;
	case 2:printf("Result=%f",a-b);
	       break;
	case 3:printf("Result=%f",a*b);
	       break;
	case 4:printf("Result=%f",a/b);
	       break;
  }
  return 0;
}
