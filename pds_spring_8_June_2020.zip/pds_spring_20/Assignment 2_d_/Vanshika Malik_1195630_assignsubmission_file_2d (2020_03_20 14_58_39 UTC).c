/*Vanshika
Mechanical Department
 19ME30056
System Number 74
*/

#include<stdio.h>
int main()

{

  float x,y;
  int ch;
  scanf("%d%f%f",&ch,&x,&y);

  switch(ch)
    {

      
    case 1:printf("%f",(x+y));
      break;
     
    case 2:printf("%f",(x-y));
      break;
      
    case 3:printf("%f",(x*y));
      break;
      
    case 4:printf("%f",(x/y));
      break;
      

    }
 

}
