/* Information
  Shobhit Narayan Tripathi
  19MI31021
  Mining Department 5years Dual Degree Course
  Machine no. 30
*/
#include<stdio.h>
int main()
 { 
   int x;
   float a,b;
    printf("For Addition,press 1 \n");
    printf("For Subtraction,press 2 \n");
    printf("For Multiplication,press 3 \n");
    printf("For Division,press 4 \n");
    printf("Enter the choice :");
     scanf("%d",&x);
    printf("Enter the two operands :");
     scanf("%f %f",&a,&b);
    
  switch(x)
    { 
     case 1:  printf("Result :%f \n",a+b);
              break;
     case 2:  printf("Result :%f \n",a-b);
              break;
     case 3:  printf("Result :%f \n",a*b);
              break;
     case 4:  printf("Result :%f \n",a/b);
              break;
     default :printf("Not an option, try again\n");
    }
 }




    
    
   
