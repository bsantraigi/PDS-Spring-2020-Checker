/*NAME:SAGGURTHI DEENARAJU
 ROLL NO:19BT30021
 BIO TECHNOLOGY DEPARTMENT
 MACHINE NO:44
*/

#include <stdio.h>
int main()
{
  double a,b,c,result1,result2,result3,result4;
   
  printf("Enter your choice:");
  scanf{"%d",&a);
  printf("enter two operands:");
  scanf("%lf %lf",&b,&c)
  printf("Add-1\nsub-2\nmult-3\ndiv-4");
  switch(1,2,3,4)
    {case1:
      result=a+b;
	printf("a+b=%lf\n",result);
    case2:
      result=a-b;
	printf("a-b=%lf\n",result);
    case3:
      result=a*b;
      printf("a*b=%lf\n",result);
    case4:
      printf("a/b=%lf\n",result);
    
  printf("Enter your choice:");
  scanf{"%d",&a);
  printf("enter two operands:");
  scanf("%lf %lf",&b,&c)

    }    
