/*apoorva erra
19IM10011
SEC 4*/
//using switch statement and solving the problems
#include<stdio.h>
int main()
{
  int a;
  float b,c,result;//declaration of variables
  printf("add-1\n");
  printf("sub-2\n");
  printf("mult-3\n");
  printf("div-4\n");
  printf("enter the choice:");
  scanf("%d",&a);
  printf("enter the two operands:\n");
  scanf("%f %f",&b,&c);
  switch(a)
    {case 1:
      result=b+c;
      printf("result=%f",result);
      break;
    case 2:
      result=b-c;
      printf("result=%f",result);
	   
      break;
    case 3:
      result=b*c;
	printf("result=%f",result);
      break;
    case 4:
      result=b/c;
      printf("result=%f",result);
      break;
    };
      
}


  
  
