#include<stdio.h>
/* Name- Rahul Choudhary
   Roll No.: 19AE10024
   Department: Aerospace
   Machine No.: 02 */
int main()
{
int c;
float a,b,d;
printf("Add-1\n Sub-2\n Mult-3\n Div-4\n");
printf("Enter the choice"); /*user enters the choice of operation he/she wishes to perform */
scanf("%d",&c);
printf("Enter the two operands");
scanf("%f %f",&a,&b); /*user enters operands on he/she wishes to perform the operation*/
switch(c){

   case 1: d=a+b;
	   printf("%f\n",d);
	   break;
   case 2: d=a-b;
	   printf("%f\n",d);
	   break;
   case 3: d=a*b;
	   printf("%f\n",d);
	   break;
   case 4: d=a/b;
	   printf("%f\n",d);
	   break;
}
return 0;
}
