/*Yashvi Jain
19CH30028
Dept:Chemical
Machine no : 49*/

#include <stdio.h>
#include <math.h>

int main(){
  printf("enter the choice\n");
  int a ;
  scanf("%d",&a);
  printf("enter the two operands\n");
  int b,c;
  scanf("%d%d",&b,&c);
  float d;
  switch(a){
  case 1 : d=c+b;break;
  case 2 : d=b-c;break;
  case 3 : d=b*c;break;
  case 4 : d=b/c;break;
  default: printf("enter a valid choice");
  }
  printf("the final result is %f",d);
}
  
