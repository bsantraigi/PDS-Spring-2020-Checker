/*
  Name       :  K.T.Shalik
  Roll No    :  19CY20020
  Dept       :  Chemistry
  Machine No ;  12 
  Write a C program that asks user for an arithmetic operation (1-addition, 2-subtraction, 3-multiplication, 4-division) and two operands. Then it performs the corresponding calculations on the operands and prints the result.*/

#include<stdio.h>
int main()
{
  int n,a,b,sum,diff,pro,div;
    printf("Add-1\nSub-2\nMult-3\nDiv-4\n");
    printf("choose your desired operation\n");
     scanf("%d",&n);
     printf("enter 2 no\n");
     scanf("%d",&a);
     scanf("%d",&b);
     switch(n)
       {
       case 1:
	 
	   sum=a+b;
           printf("%d",sum);
	   break;
	
       case 2:
	 
	   diff=a-b;
           printf("%d",diff);
	   break;
       case 3:
	 
	   pro=a*b;
           printf("%d",pro);
	   break;
       case 4:
	 
	   div=a/b;
           printf("%d",div);
	   
       }
}
