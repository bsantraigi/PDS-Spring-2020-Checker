/*NAME: Mithil Rajput
Roll No:19EX20021
DEPT: GEOLOGY AND GEOPHYSICS
MACHINE NO.: 18
*/
#include<stdio.h>
int main()
{
  float a, b;
  float r=0;
  char o;
  printf("\n Add-1 \n Sub-2 \n Mult-3 \n Div-4");
  printf("\n Enter the choice: ");
  scanf("%c", &o);
  printf("\n Enter the 2 operands: ");
  scanf("%f%f", &a, &b);
  switch (o) {
  case '1':
    r = a + b;
    break;
  case '2':
    r = a - b;
    break;
  case '3':
    r = a * b;
    break;
  case '4':
    if (b!=0)
      r = a / b;
    else printf ("\nError! Division by 0");
	return 0;
    break;
  default:
    printf("\n Error! Define the operation within input domain.");
    break;
  }
  printf("\n Result = %f \n", r);
}
