/*Name:Rahul Nath
roll no.:19CH10033
Dept:chemical
assignment:assignment2(d)*/
#include<stdio.h>
#include<math.h>
int main()
{
  int x;
  float a,b,result;
  printf("enter two operands:\n");
  scanf("%f%f",&a,&b);
  printf("add-1\nsubtract-2\nmultiply-3\ndivide-4\n");
  printf("enter the operation no.:\n");
  scanf("%d",&x);
  switch(x)
    {
  case 1:result=a+b;
  printf("result:\n%f",result);
  break;
  case 2:result=a-b;
  printf("result:\n%f",result);
  break;
  case 3:result=a*b;
  printf("result:\n%f",result);
  break;
  case 4:result=a/b;
  printf("result:\n%f",result);
  break;
  default:
    printf("enter valid operation no.\n");
    break;
    }
  return (0);
}
