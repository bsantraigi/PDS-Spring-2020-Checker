#include <stdio.h>
int main()
{float Result,operand_1,operand_2;
  printf("Enter the value for ch:\n");
  
  char ch;
  scanf("%c",&ch);
  printf("Enter the value of operand_1 and operand_2:\n");
  scanf("%f%f",&operand_1,&operand_2);
  switch(ch)
    { case '+':
	Result=operand_1+operand_2;
	printf("Result=%f",Result);
	break;

    case '-':
      Result=(operand_1)-(operand_2);
      printf("Result=%f",Result);
      break;
    case '*':
      Result=operand_1*operand_2;
      printf("Result=%f",Result);
      break;
      

    case '/':
      Result=operand_1/operand_2;
      printf("Result=%f",Result);
      break;
    default:
     printf("None of the above choices");
    }
  return 0;
} 
