/*
Name-Dibyendu Biswas
Roll no-19E10022
Problem no-4
machine no-14
sec-4
*/
#include<stdio.h>

int main()
{
  int a;
  float  b,c,d,e,no1,no2;
  printf("Add-1\nSub-2\nMult-3\nDiv-4\n");
  scanf("%d",&a);
  printf("Enter 2 operands:");
  scanf("%f%f",&no1,&no2);
  switch(a){
  case 1:
    b=no1+no2;
  printf("%f\n",b);
  break;
   case 2:
    c=no1-no2;
  printf("%f\n",c);
  break;
   case 3:
    d=no1*no2;
  printf("%f\n",d);
  break;
   case 4:
     if(no2!=0){
     e=no1/no2;
     printf("%f\n",e);}
     else
       printf("Error\n");
  break;
  }
  return 0;

 }
