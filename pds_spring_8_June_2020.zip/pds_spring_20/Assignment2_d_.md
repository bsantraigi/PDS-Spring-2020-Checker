## INPUT 
`4 4 6
`
## ROLL: BADRI VISAAL AVVARU

> **Compilation Status**: SUCCESS

OUTPUT
---
```
Add-1
Sub-2
Mult-3
Div-4
enter your choice:enter your two operands:0.666667

```
> **SRC:** Assignment 2_d_/BADRI VISAAL AVVARU/BADRI VISAAL AVVARU_1195571_assignsubmission_file_p2d.c
```C++
//NAME:Avvaru Badri Visaal
//Roll number:19CH10013
//Dept:Chemical Engineering
//Machine number 8
#include<stdio.h>
int main()
{
  float a,b;
  int x;
  printf("Add-1\nSub-2\nMult-3\nDiv-4\n");
  printf("enter your choice:");
  scanf("%d",&x);
  printf("enter your two operands:");
  scanf("%f%f",&a,&b);
  switch(x)
    {
    case 1:printf("%f\n",a+b);
    break;
    case 2:printf("%f\n",a-b);
    break;
    case 3:printf("%f\n",a*b);
    break;
    case 4:printf("%f\n",a/b);
    break;
    default:
    printf("invalid choice\n");
    };
}

```
## ROLL: BHARGAVI ADUSUMILLI

> **Compilation Status**: SUCCESS

OUTPUT
---
```
Add-1
Sub-2
Mult-3
Div-4
Enter the choice:Enter the operands:Result:0.666667
```
> **SRC:** Assignment 2_d_/BHARGAVI ADUSUMILLI/BHARGAVI ADUSUMILLI_1195560_assignsubmission_file_assign2d.c
```C++
/*Name:A.N.V.S.Bhargavi
Rollno:19AE10004
Dept:Aerospace
Machine no:01*/
#include<stdio.h>
int main()
{
  int c;
  float op,x,y;
  printf("Add-1\nSub-2\nMult-3\nDiv-4\n");
  printf("Enter the choice:");
  scanf("%d",&c);
  printf("Enter the operands:");
  scanf("%f%f",&x,&y);
  switch(c)
    {
    case 1:op=x+y;
      printf("Result:%f",op);
      break;
    case 2:op=x-y;
      printf("Result:%f",op);
      break;
    case 3:op=x*y;
      printf("Result:%f",op);
      break;
    case 4:op=x/y;
      printf("Result:%f",op);
    }
}
  

```
## ROLL: DEDIPYA YALAM

> **Compilation Status**: SUCCESS

OUTPUT
---
```

Add-1
Sub-2
Mult-3
Div-4
Enter your choice and two operands:Result=0.666667
```
> **SRC:** Assignment 2_d_/DEDIPYA YALAM/DEDIPYA YALAM_1195597_assignsubmission_file_switch.c
```C++
/*A program to perform arithmetic operations according to the input*/
#include<stdio.h>
int main()
{
  int x;
  float a,b;
  printf("\nAdd-1\nSub-2\nMult-3\nDiv-4\nEnter your choice and two operands:");
  scanf("%d%f%f",&x,&a,&b);
  switch(x){
  case 1:printf("Result=%lf",a+b);
    break;
  case 2:printf("Result=%lf",a-b);
    break;
  case 3:printf("Result=%lf",a*b);
    break;
  case 4:printf("Result=%lf",a/b);
    break;
  default:printf("\nInvalid choice");
  }
}
    

    

```
## ROLL: RAHUL CHOUDHARY

> **Compilation Status**: SUCCESS

OUTPUT
---
```
Add-1
 Sub-2
 Mult-3
 Div-4
Enter the choiceEnter the two operands0.666667

```
> **SRC:** Assignment 2_d_/RAHUL CHOUDHARY/RAHUL CHOUDHARY_1195577_assignsubmission_file_Assignment2(d).c
```C++
#include<stdio.h>
/* Name- Rahul Choudhary
   Roll No.: 19AE10024
   Department: Aerospace
   Machine No.: 02 */
int main()
{
int c;
float a,b,d;
printf("Add-1\n Sub-2\n Mult-3\n Div-4\n");
printf("Enter the choice"); /*user enters the choice of operation he/she wishes to perform */
scanf("%d",&c);
printf("Enter the two operands");
scanf("%f %f",&a,&b); /*user enters operands on he/she wishes to perform the operation*/
switch(c){

   case 1: d=a+b;
	   printf("%f\n",d);
	   break;
   case 2: d=a-b;
	   printf("%f\n",d);
	   break;
   case 3: d=a*b;
	   printf("%f\n",d);
	   break;
   case 4: d=a/b;
	   printf("%f\n",d);
	   break;
}
return 0;
}

```
## ROLL: RAHUL NATH

> **Compilation Status**: SUCCESS

OUTPUT
---
```
enter two operands:
add-1
subtract-2
multiply-3
divide-4
enter the operation no.:
enter valid operation no.

```
> **SRC:** Assignment 2_d_/RAHUL NATH/RAHUL NATH_1195592_assignsubmission_file_assignment2d.c
```C++
/*Name:Rahul Nath
roll no.:19CH10033
Dept:chemical
assignment:assignment2(d)*/
#include<stdio.h>
#include<math.h>
int main()
{
  int x;
  float a,b,result;
  printf("enter two operands:\n");
  scanf("%f%f",&a,&b);
  printf("add-1\nsubtract-2\nmultiply-3\ndivide-4\n");
  printf("enter the operation no.:\n");
  scanf("%d",&x);
  switch(x)
    {
  case 1:result=a+b;
  printf("result:\n%f",result);
  break;
  case 2:result=a-b;
  printf("result:\n%f",result);
  break;
  case 3:result=a*b;
  printf("result:\n%f",result);
  break;
  case 4:result=a/b;
  printf("result:\n%f",result);
  break;
  default:
    printf("enter valid operation no.\n");
    break;
    }
  return (0);
}

```
## ROLL: SHIVAM LAHOTI

> **Compilation Status**: SUCCESS

OUTPUT
---
```
add-1 
 sub-2 
 mult-3 
 div-4 
 enter your choice 
enter the two operands
result=0.666667 

```
> **SRC:** Assignment 2_d_/SHIVAM LAHOTI/SHIVAM LAHOTI_1195626_assignsubmission_file_assignment2d.c
```C++
#include<stdio.h>
int main()
{
  /*name- Shivam Lahoti
roll no.- 19AG10028
machine no.- 5
department- Agriculture and food engineering*/
  float a,b,d;
  int c;
  printf("add-1 \n sub-2 \n mult-3 \n div-4 \n enter your choice \n");
  scanf("%d",&c);
  printf("enter the two operands\n");
  scanf("%f%f",&a,&b);
  switch(c)
    {
    case 1:{
      d=a+b;
      break;}
    case 2:{
      d=a-b;
      break;}
    case 3:{
      d=a*b;
      break;}
    case 4:{
      d=a/b;
      break;}
    default : printf("invalid choice\n");
    }
  printf("result=%f \n",d);
}

```
## ROLL: SHIVANI SOREN

> **Compilation Status**: SUCCESS

OUTPUT
---
```
Add-1
Sub-2
Mult-3
Dic-4
Enter the choice :Enter the teo oprands : Result = 0

```
> **SRC:** Assignment 2_d_/SHIVANI SOREN/SHIVANI SOREN_1195611_assignsubmission_file_calculator.c
```C++
#include<stdio.h>
/*program which can add,sub,mult,div at the same time using switch*/
int main()
{
  int a,b,c,r;
  printf("Add-1\nSub-2\nMult-3\nDic-4\nEnter the choice :");
  scanf("%d",&c);
  printf("Enter the teo oprands : ");
  scanf("%d %d",&a,&b);
  switch(c)
  {
  case 1: r=a+b;break;
  case 2: r=a-b;break;
  case 3: r=a*b;break;
  case 4: r=a/b;break;
  }
  printf("Result = %d\n",r);
}

```
## ROLL: SHREE HARSHA KODI

> **Compilation Status**: SUCCESS

OUTPUT
---
```
Enter the values:1.000000
```
> **SRC:** Assignment 2_d_/SHREE HARSHA KODI/SHREE HARSHA KODI_1195603_assignsubmission_file_assignment2(d).c
```C++
/*Name:Kodi Shree Harsha
Roll No:19AE30009
Machine No:3
Department:Aerospace*/

#include<stdio.h>
int main()
{
  float A,B,C;
  char x;
  printf("Enter the values:");
  scanf("%f %f %c",&A,&B,&x);
  
  switch(x){
  case '+': C=A+B;
  break;
  case '-':C=A-B;
    break;
  case '*': C=A*B;
    break;
  default:C=A/B;}
    
  
  printf("%f",C);
  return(0);
    }

```
## ROLL: SOHAM ZADE

> **Compilation Status**: SUCCESS

OUTPUT
---
```
Enter operation
Enter operands
Result= 0.666667

```
> **SRC:** Assignment 2_d_/SOHAM ZADE/SOHAM ZADE_1195622_assignsubmission_file_program2d.c
```C++
/* Name: Soham Zade
   Roll no: 19CH10053
   Machine no: 10
   Program with operators*/

#include<stdio.h>

int main()
{int i;
 float a,b;

  printf("Enter operation\n");
  scanf("%d", &i);

  printf("Enter operands\n");
  scanf("%f %f", &a, &b);

  switch(i)
    {
    case 1: printf("Result= %f\n", a+b);
    case 2: printf("Result= %f\n", a-b);
    case 3: printf("Result= %f\n", a*b);
    case 4: printf("Result= %f\n", a/b);
    }


}

```
## ROLL: SREEYA CHILUPURI

> **Compilation Status**: SUCCESS

OUTPUT
---
```
Enter the value for ch:
Enter the value of operand_1 and operand_2:
None of the above choices
```
> **SRC:** Assignment 2_d_/SREEYA CHILUPURI/SREEYA CHILUPURI_1195624_assignsubmission_file_a2d.c
```C++
#include <stdio.h>
int main()
{float Result,operand_1,operand_2;
  printf("Enter the value for ch:\n");
  
  char ch;
  scanf("%c",&ch);
  printf("Enter the value of operand_1 and operand_2:\n");
  scanf("%f%f",&operand_1,&operand_2);
  switch(ch)
    { case '+':
	Result=operand_1+operand_2;
	printf("Result=%f",Result);
	break;

    case '-':
      Result=(operand_1)-(operand_2);
      printf("Result=%f",Result);
      break;
    case '*':
      Result=operand_1*operand_2;
      printf("Result=%f",Result);
      break;
      

    case '/':
      Result=operand_1/operand_2;
      printf("Result=%f",Result);
      break;
    default:
     printf("None of the above choices");
    }
  return 0;
} 

```
