/*NAME-SHOURYA SHARMA
  SEC-4
  MACHINE N0-67
  DEPT-INDUSTRIAL AND SYSTEM ENGINEERING*/
#include<stdio.h>
#include<math.h>
int main()
{ float m,c,p,r;
  printf("Enter the slope, intercept and radius of circle\n");
  scanf("%f %f %f",&m,&c,&r);
  if(c<0)
  p=-c/sqrt(pow(m,2)+1);
  else
    p=c/sqrt(pow(m,2)+1);
  if(p>r)
    printf("neither tangent nor secant \n");
  else if(p==r)
    printf("tangent\n");
  else
    printf("Secant\n");
}
