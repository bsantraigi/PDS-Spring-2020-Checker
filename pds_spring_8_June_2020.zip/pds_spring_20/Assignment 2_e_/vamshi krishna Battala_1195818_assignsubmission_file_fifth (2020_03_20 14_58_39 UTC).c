/*
 Name: B.vamshi krishna
 Roll: 19CS10019
 Dept: computer science and engineering
 Machine number: 50
*/
# include<stdio.h>
#include<math.h>
int main()
 { 
   float m,c,r;
   printf("\nenter the slope(m), the y-intercept(c),radius of the   circle(r)\n");
 
   scanf("%f %f %f",&m,&c,&r);
   if (fabsf(c)/(sqrt(1+m*m))>r)
      printf("the line does not intersect the circle");  

   if (fabsf(c)/(sqrt(1+m*m))==r)
     printf("the line is tangent to the circle");
   if (fabsf(c)/sqrt(1+m*m)<r)
     printf("the line does not intersects the circle");
  
}
