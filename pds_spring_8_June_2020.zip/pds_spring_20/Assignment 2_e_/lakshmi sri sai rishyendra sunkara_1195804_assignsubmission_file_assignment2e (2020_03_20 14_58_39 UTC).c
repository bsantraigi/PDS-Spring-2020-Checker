/* Name:S.L.S.Sai Rishyendra;
   Rollno:19EC10062;
   Dept:E&ECE;
   Machine No:55 */
#include<stdio.h>
#include<math.h>
int main()
{
  float m,c,l,d,r;
  scanf("%f%f%f",&m,&c,&r);
      l=sqrt(1+m*m);

      d=c/l;
      
      if(d<r) printf("The line is secant\n");
      else if(d==r) printf("The line is tangent\n");
      else  printf("neither secant nor tangent\n");
}


















































  
