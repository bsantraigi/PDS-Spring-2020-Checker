/*
Name - Sumeet Bohra
Roll - 19CS10059
Department - Computer Science and Engineering
Machine No. - 52
*/

#include <stdio.h>
#include <math.h>

void main()
{
    float m,c,r,dist;
    printf("Enter the slope: \n");
    scanf("%f",&m);
    printf("Enter the intercept of a straight line: \n");
    scanf("%f",&c);
    printf("Enter the radius of the circle centered at origin: \n");
    scanf("%f",&r);
    dist=fabs(c/sqrt(1+m*m));
    if(dist-r < 0.0000001 || dist-r > -.0000001)
	printf("Result = Tangent\n");
    else if(dist-r < 0)
	printf("Result = Secant\n");
    else
	printf("Result = Neither a tangent nor a secant\n");
    
}
