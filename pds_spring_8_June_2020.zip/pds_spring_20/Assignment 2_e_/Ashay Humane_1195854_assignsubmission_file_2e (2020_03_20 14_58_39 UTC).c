/*Name: Humane Ashay Vijay
  Roll No: 19ME10025
  Dept: Mechanical Engineering
  Machine No: 25
*/
#include<stdio.h>
#include<math.h>
int main()
{
  float m,c,r,x,y;
  printf("Enter m:");
  scanf("%f",&m);
  printf("\nEnter c:");
  scanf("%f",&c);
  printf("\nEnter r:");
  scanf("%f",&r);
  x=c*c/(1+m*m);
  y=sqrt(x);
  if(y==r)
    printf("\nResult:tangent");
  else if(y<r)
    printf("\nResult:secant");
  else printf("\nResult:neither secant nor tangent");
  
}
