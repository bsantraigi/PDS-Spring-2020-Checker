/* Name       : Kaizer Rahaman
   Roll No    : 19NA10010
   Department : Ocean Engineering and Naval Architecture
   Machine No : 81
*/

#include <stdio.h>
#include <math.h>

int main()
{
  float m,c,r;
  printf("\nEnter m : ");
  scanf("%f",&m);
  printf("\nEnter c : ");
  scanf("%f",&c);
  printf("\nEnter r : ");
  scanf("%f",&r);
  float d=(pow(r,2)*(1+pow(m,2)))-pow(c,2);
  if(d<0)
    printf("Result : Neither secant nor tangent");
  else if(d>0)
    printf("Result : secant");
  else
    printf("Result : tangent");
}
