/*Name:Manusani Vaishnavi
Roll.no:19MA20026
Dept:Math and Computing
Sys no:22*/
#include <stdio.h>
#include <math.h>
int main()
{float d,m,c,r;
  printf("Enter m:");
  scanf("%f",&m);
  printf("Enter c:");
  scanf("%f",&c);
  printf("Enter r:");
  scanf("%f",&r);
  d=c/sqrt(1+(m*m));
  if(d<r)
    printf("Result:secant");
    else if(d==r)
      printf("Result:tangent");
    else
      printf("Result:neither secant nor tangent");
}
