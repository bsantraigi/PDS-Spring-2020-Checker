/*Paras Choudhary
19GG20022
Sce 4
System 20*/

 #include <stdio.h>
#include <math.h>

int main()
{
  float a, b, c, d, m, r;
  //a = (1 + (m*m));
  //b = sqrt(a);
  
  printf("write m, c and r\n");
  scanf("%f %f %f",&m, &c, &r);
  d = fabs(c)/(sqrt(1+m*m));

printf("%f",d);

  if(d>r){
    printf("neither secant nor tangent");
         }
  else if(d < r){
    printf("secant");
                }

    else {
      printf("Tangent");
         }
  
  

}
