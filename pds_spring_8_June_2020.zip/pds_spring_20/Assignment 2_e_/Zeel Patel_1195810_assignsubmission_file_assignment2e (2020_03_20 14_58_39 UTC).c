/* name: Patel Zeel Yogeshkumar
roll no.: 19ME10044
dept: Machanical eng
machine no.:69 */

//program to determine whether the given line y=mx+c is secant or tangent or none for the circle with radius r & centre (0,0)

#include <stdio.h>
#include <math.h>

int main()
{
  float m, c, r, d, e, a;
  printf("Enter m:\n");
  scanf("%f", &m);
  printf("Enter c:\n");
  scanf("%f", &c);
  printf("Enter r:\n");
  scanf("%f", &r);

  a=1+m*m;
  e=sqrt(a);
  d=c/e;
  
  if (d>r)
    { printf("\nneither secant nor tangent\n");}
  else if (d==r)
    {  printf("\ntangent\n");}
  else if (d<r)
    { printf("\nsecant\n");}

  return 0;
}
 

  
