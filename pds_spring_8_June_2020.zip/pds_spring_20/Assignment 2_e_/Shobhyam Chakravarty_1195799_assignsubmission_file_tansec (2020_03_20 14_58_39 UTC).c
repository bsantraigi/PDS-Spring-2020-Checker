/*Name:Shobhyam Chakravarty
Roll No.:19NA10029
Department:Ocean Engineering And Naval Architecture
Machine No.:82*/

#include<stdio.h>

int main()
{
  float m,c,r,d;
  printf("Enter m,c and r");
  scanf("%f%f%f",&m,&c,&r);
  if(c<0)
    c=c*-1;
  d=(c)/(1+m*m);
  if(d<r)
    printf("Result: secant");
  if(d==r)
    printf("Result: tangent");
  if(d>r)
    printf("Result: neither secant nor tangent");

}
