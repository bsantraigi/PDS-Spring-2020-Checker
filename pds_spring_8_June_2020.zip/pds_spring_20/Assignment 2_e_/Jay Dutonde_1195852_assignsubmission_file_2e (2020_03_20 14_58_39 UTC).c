/*Name-Jay Dutonde
section-4
roll no.-19CH30008
machine no.-48*/
#include<stdio.h>
#include<math.h>
int main()
{
  float m,c,d,r;
  printf("enter values of m,c,radius");
  scanf("%f%f%f",&m,&c,&r);
  d=c/(sqrt((m*m)+1));
  if(d<r)
    {
      printf("result:secant");
    }
  if(d==r)
    {
      printf("result:tangent");
    }
  if(d>r)
    {
      printf("result:none");
    }
  return 0;
}
