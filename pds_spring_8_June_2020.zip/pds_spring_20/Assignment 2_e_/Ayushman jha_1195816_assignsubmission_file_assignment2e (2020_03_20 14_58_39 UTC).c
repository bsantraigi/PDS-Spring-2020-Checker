#include<stdio.h>
#include<math.h>

int main()
{

float m,c,r,d,e;

printf("Enter m \n");
scanf("%f" ,&m);

printf("Enter c \n");
scanf("%f" ,&c);

printf("Enter r \n");
scanf("%f" ,&r);

e=sqrt(1+m*m);
d= fabs(c)/e ; //this should be always positive as it is distance//

if(d<r)
{
printf("SECANT \n");
}

else if(d==r)
{
printf("TANGENT \n");
}

else if(d>r)
{

printf("NO INTERSECTION \n");

}








}
