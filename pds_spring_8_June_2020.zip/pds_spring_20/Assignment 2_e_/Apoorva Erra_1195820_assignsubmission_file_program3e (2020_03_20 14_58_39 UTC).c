/*apoorva erra
19IM10011
SEC 4*/
//FINDING WHETHER THE GIVEN LINE IS SECANT OR TANGENT
#include<stdio.h>
#include<math.h>
int main()
{
  int m,c,r,d;//declaration of variables
  printf("enter m:\n");//taking inputs for line y=m*x+c and circle of radius r
  scanf("%d",&m);
  printf("enter c:\n");
  scanf("%d",&c);
  printf("enter r:\n");
  scanf("%d",&r);
  d=(c)/sqrt(1+m*m);//perpendicular distance of line from centre of cicrcle
  if (d==r)
    printf("result:tangent");//for tangent perpendicular distance=r
  if (d<r)
    printf("result:secant");//for secant perpendicular distance<r since it cuts the circle
}
  
  
