/*
NAME: BHARGAV KHARE
ROLL NO.:19NA30010
DEPT: OCEAN ENGINEERING AND NAVAL ARCHITECTURE
PC NO.:31*/
#include<stdio.h>
#include<math.h>
void main()
{
  float m, c, r;
  float dis=0;
  printf("Enter m :");//Enter slope
  scanf("%f",&m);
  printf("Enter c :");//Enter y-intercept
  scanf("%f",&c);
  printf("Enter r :");//Enter radius 
  scanf("%f",&r);
  dis=c/sqrt((m*m)+1);//Calculating distance from origin
  if(dis>r)
    {
      printf("Result:Neither secant nor tangent");
    }
  else if(dis==r)
    {
      printf("Result:Tangent");
    }
  else
    {
      printf("Result:Secant");
    }
}
	
	
