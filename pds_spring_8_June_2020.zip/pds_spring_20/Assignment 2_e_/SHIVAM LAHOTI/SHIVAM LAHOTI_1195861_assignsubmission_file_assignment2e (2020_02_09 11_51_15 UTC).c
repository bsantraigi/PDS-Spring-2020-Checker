#include<stdio.h>
#include<math.h>
int main()
{
  /*name- Shivam Lahoti
roll no.- 19AG10028
machine no.- 5
department- Agriculture and food engineering*/
  float m,c,r,d,d1,c1,dist;
  printf("enter m, c and r respectively \n");
  scanf("%f%f%f",&m,&c,&r);
  c1=fabs(c);
  d=1+m*m;
  d1=sqrt(d);
  dist=c1/d1;
  if(dist<r)
    printf("result= secant \n");
    else if (dist == r)
      printf("result= tangent\n");
    else
      printf("result= neither tangent nor secant \n");
}
