/*
abhishek kumar
19MI31002
mining engineering
29
*/
#include <stdio.h>
int main()
{
  float m,c,r,d;
  printf("enter m ");
  scanf("%f",&m);
  printf("enter c ");
scanf("%f",&c);
printf("enter r ");
scanf("%f",&r);
d=(4*m*m*c*c)-4*(m*m+1)*(c*c-r*r);
if(d>0)
printf("result= secant");
if(d<0)
printf("result= nither secant nor tangent");
if(d=0)
printf("result= tangent");
}
