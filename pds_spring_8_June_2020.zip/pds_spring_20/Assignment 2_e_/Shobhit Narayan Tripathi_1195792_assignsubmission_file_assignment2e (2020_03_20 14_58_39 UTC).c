/* Information
  Shobhit Narayan Tripathi
  19MI31021
  Mining Department 5years Dual Degree Course
  Machine no. 30
*/
#include<stdio.h>
#include<math.h>
int main()
 { 
   float m,c,r,d;
    printf("For line y=m*x + c and the circle x*x + y*y = r*r. \n");
    printf("Enter the value of m :");
    scanf("%f",&m);
    printf("Enter the value of c :");
    scanf("%f",&c);
    printf("Enter the value of r :");
    scanf("%f",&r);
    
    d=sqrt(c*c)/sqrt(1 + m*m); //sqrt(c*c) is used to make 'd' a positive quantity,since it is a distance
    
    if(d==r)
     printf("Result : tangent \n");
    else 
      if(d<r)
       printf("Result : secant \n");
      else
       printf("Result : neither secant nor tangent \n");
 }

