/* name:l.Pradeep;
     sec:4;
     roll no:19EE10038;
     dept:Electrical ;
     mac no:60   */
#include<stdio.h>
#include<math.h>
int main()
{
  float x,y,r,d;
  
  scanf("%f%f%f",&x,&y,&r);
  //d=(y/sqrt((x*x)+1)));
  d = y/sqrt(x*x+1);
if(d<0)
  {
    d=(-1)*d;
  }
if(d<r)
  {
    printf("the straight line is secant");
  }
 else if(d==r)
   {
     printf("straight line is tangent");
   }
 else
   {
     printf("neither secant or tangent");
   }
}
