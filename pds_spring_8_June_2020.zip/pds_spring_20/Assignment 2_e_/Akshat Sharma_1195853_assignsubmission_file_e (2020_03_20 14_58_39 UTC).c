/*
NAME::Akshat Sharma
ROLL NO.::19EC10002
DEPT::Electronics and Electrical COmmunication Engineering
MACHINE NO.::13			       
*/

/*
User gives as input the values of m and c for a straight line y=mx+c, and the value of r for a circle of radius r and center (0,0). Your program should determine whether the straight line is a secant or a tangent or none.
*/

#include<stdio.h>
#include<math.h>

int main()
{
  float m,c,r,d;
  printf("Enter m: ");
  scanf("%f",&m);
  printf("Enter c: ");
  scanf("%f",&c);
  printf("Enter r: ");
  scanf("%f",&r);
  d = ((c)/(sqrt((1+(m*m)))));
  if(d<0)
    {
      d=-1*d;
    }
  if(d<r)
    {
      printf("Result: secant\n");
    }
  else if(d==r)
    {
      printf("Result: tangent\n");
    }
  else
    {
      printf("Result: neither secant nor tangent\n");
    }
  return 0;
}

  
  
