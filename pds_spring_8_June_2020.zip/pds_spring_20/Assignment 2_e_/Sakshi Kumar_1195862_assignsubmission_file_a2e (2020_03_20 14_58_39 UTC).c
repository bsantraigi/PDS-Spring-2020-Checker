/*
Sakshi Kumar
19IE10027
Electrical Engineering
Machine no. 65
*/

#include<stdio.h>
#include<math.h>
int main()
{
  float m,c,r,x,y,z,w;
  printf("Given line y=mx=c\n");
  printf("Given circle x*x+y*y=r*r\n");
  printf("Enter m:\n");
  scanf("%f",&m);
  printf("Enter c:\n");
  scanf("%f",&c);
  printf("Enter r:\n");
  scanf("%f",&r);
  x=1+m*m;
  y=sqrt(x);
  z=abs(c);
  w=z/y;
  if (w<r)
    {
      printf("Line is secant.\n");
    }
  else if (w==r)
    {
      printf("Line is Tangent.\n");
    }
  else
    {
      printf("Line is neither secant nor tangent.\n");
    }
}
     
