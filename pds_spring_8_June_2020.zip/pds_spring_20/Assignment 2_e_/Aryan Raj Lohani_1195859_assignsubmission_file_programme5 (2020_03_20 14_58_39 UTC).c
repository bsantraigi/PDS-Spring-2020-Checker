/*Name-Aryan Raj lohani
Roll no - 19mt10011
system no-77*/

#include<stdio.h>
#include<math.h>
int main(){
float m,c,r,d;
  printf("enter numbers in order m,c,r\n");
  scanf("%f%f%f",&m,&c,&r);
    d=c/(sqrt((1+m*m)));
	if(d<0){
	 d=-d;}

	if(d<r){
	 printf("the line is a secant\n");
	}
 	 if(d==r){
	 printf("the line is a tangent\n");
	}else
	 printf("the lines are not intersecting\n");
	

	return 0;
}
