/* Name: Soham Zade
   Roll no:19CH10053
   Machine no: 10
   Program for line and circle*/

#include<stdio.h>
#include<math.h>

int main()
{float m, c, r, d;

  printf("Enter m\n");
  scanf("%f", &m);
  printf("Enter c\n");
  scanf("%f", &c);
  printf("Enter r\n");
  scanf("%f", &r);

  d= c/sqrt(1+m*m); //perpendicular distance from center of circle to line//

  if(d<r)
    {printf("Line is secant.\n");}
  else if(d==r)
    {printf("Line is tangent.\n");}
  else if(d>r)
    {printf("Line is neither secant nor tangent.\n ");}
  
  

}
