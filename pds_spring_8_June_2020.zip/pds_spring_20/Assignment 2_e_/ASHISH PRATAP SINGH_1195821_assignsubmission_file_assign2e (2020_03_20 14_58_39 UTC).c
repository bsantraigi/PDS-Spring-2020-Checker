/* ASHISH PRATAP SINGH
  ROLL NO.- 19CE10011
  CIVIL ENGINEERING DEPARTMENT
  MACHINE NO.-45
*/

#include <stdio.h>
#include <math.h>

int main()
{
  double m,c,r,a,b;
  printf("Enter m:");
  scanf("%lf",&m);
  printf("Enter c:");
  scanf("%lf",&c);
  printf("Enter r:");
  scanf("%lf",&r);
  a=sqrt(1+m*m);
  b=fabs(c/a);
  if (r<b)
    printf("Neither secant nor tangent\n");
  else if (r==b)
    printf("Tangent\n");
  else
    printf("Secant\n");
}
  
  
  
