/*Name:Kodi Shree Harsha
Roll No:19AE30009
Machine No:3
Department:Aerospace*/

#include<stdio.h>
#include<math.h>
int main()
{
  float m,c,r,d;
  printf("Enter the values:");
  scanf("%f%f%f",&r,&c,&m);
  d=c/(sqrt(m*m +1));
	 if(r=d)
	   {printf("tangent");}
	 else if(r>d)
	   {printf("secant");}
	 else
	   {printf("none");}
	  
    return(0);
}
