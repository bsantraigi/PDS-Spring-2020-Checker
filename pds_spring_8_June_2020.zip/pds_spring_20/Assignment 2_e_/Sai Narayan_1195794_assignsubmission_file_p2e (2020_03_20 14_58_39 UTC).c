/*
Name : S. Sai Narayan
Roll Number : 19QD30014
Department : Quality Engineering Design Manufacture
Machine Number : 35
*/ 

//header files
#include<stdio.h>
#include<math.h>


int main()
{
  //variable declarations
  double m,c,r,dis;
  //accepting variables
  printf("\nEnter m: ");
  scanf("%lf",&m);  
  printf("\nEnter c: ");
  scanf("%lf",&c);
  printf("\nEnter r: ");
  scanf("%lf",&r);
  printf("\nResult: ");
  if(c>0)  //as distance needs to be positive  i take 2 cases based on c
    {
      dis=c/sqrt(1+m*m); 
    }
  else
    {
      dis=-c/sqrt(1+m*m);
    }
  if(r==dis)
    {
      printf("tangent\n");  //case for tangent
    }
  else if(r<dis)
    {
      printf("neither secant nor tangent\n");  //case for neither
    }
  else if(r>dis)
    {
      printf("secant\n");  //case for secant
    }

} 
    
  
  
