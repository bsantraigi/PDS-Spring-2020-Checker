/* Saurabh Zanwar
19AG30030
Agri
Machine no. 42
*/

#include<stdio.h>
#include<math.h>
int main()
{
  float m,c,d,r,f,e;
  printf("Enter m and c when line is of the form y=mx+c\n");
  printf("Enter your radius r\n");
  scanf("%f%f%f",&m,&c,&r);
  e=1+m*m;
  f=sqrt(e);
  d=c/f;
    if (d>r)
      printf("Line is none\n");
    else if (d<r)
      printf("Line is secant\n");
    if (fabs(d-r)<0.000001)
  printf("Line is tangent\n");
}
  
