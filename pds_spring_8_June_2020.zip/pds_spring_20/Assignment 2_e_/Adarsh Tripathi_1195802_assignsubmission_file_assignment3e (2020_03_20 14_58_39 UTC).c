/*NAME: ADARSH TRIPATHI
  ROLL NO.:19EX20002
  DEPT.:GEOLOGY AND GEOPHYSICS
  MACHINE NO.:17
*/

#include<stdio.h>
#include<math.h>
int main()
{
  float m,c,r,d;
  printf("enter values of m,c,r in given sequence: \n");
  scanf("%f%f%f",&m,&c,&r);
  d=(fabs(c))/sqrt(m*m+1);
  if(d>r)
    printf("Result: NONE\n");
  else if(d<r)
    printf("Result: SECANT\n");
  else
    printf("Result: TANGENT\n");
}
  
