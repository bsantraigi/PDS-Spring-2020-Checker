/*Duhita Wani
19ME10082
Mechanical Engineering
Machine no - 71*/

#include<stdio.h>
#include<math.h>
int main()
  
{ float m,c,r,a;
    printf("Enter m-");
    scanf("%f",&m);
    printf("Enter c-");
    scanf("%f",&c);
    printf("Enter r-");
    scanf("%f",&r);
    a=sqrt(1+m*m);
    x=abs(c/a);
    if (x<0)
      {x=-x};

    if(x<r)
      printf("Secant\n");
    if(x==r)
      printf("Tangent\n");
    else
      printf("neither secant nor tangent");

	return 0;
}
      



















  
