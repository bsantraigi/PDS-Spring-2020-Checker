/*Abhinav Singh
19BT30001
Biotechnology
Machine No 43
*/
#include<stdio.h>
#include<math.h>

int main()
{
  float m,c,r,d;
  printf("Enter m:");
  scanf("%f",&m);
  printf("Enter c:");
  scanf("%f",&c);
  printf("Enter r:");
  scanf("%f",&r);
 
  if(c<0)
    c*=-1;
  d=c/(sqrt(1+m*m));
  if(d==r)
    printf("Result: tangent\n");
  else if(d<r)
    printf("Result: secant\n");
  else
    printf("Result: neither secant nor tangent\n");
}

    
  

  
  
  
  
  
