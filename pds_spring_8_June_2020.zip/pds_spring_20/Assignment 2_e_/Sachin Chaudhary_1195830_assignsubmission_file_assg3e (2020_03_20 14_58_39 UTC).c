/*Name:Sachin Chaudhary
Roll no.=19MA20045
Dept=Mathematics
Machine No.=23

Program to determine whether a line is a tangent,secant or neither of them*/
#include <stdio.h>
#include <math.h>
int main()
{
  float m,c,r,p;
  printf("Enter m:");
  scanf("%f",&m);
  printf("Enter c:");
  scanf("%f",&c);
  printf("Enter r:");
  scanf("%f",&r);
  p=c/(sqrt(1+m*m));
  if(p==r)
    printf("Result:Tangent");
   else if(p>r)
   printf("Result:Neither a tangent nor a secant");
  else 
  printf("Result:Secant");
}
      
  
  
    
