/*
name; shivam hurkat
roll no:19HS20018
machine no:63
dept:hss*/
#include<stdio.h>
#include<math.h>
int main()
{
  float m,c,r,d;
  printf("enter m:\n");
  scanf("%f",&m);
  printf("enter c:\n");
  scanf("%f",&c);
  printf("enter r:\n");
  scanf("%f",&r);
  if(c>0){
    d=((c)/sqrt(1+m*m));
  }
    else
       d=-((c)/sqrt(1+m*m));
    if(d>r)
      printf("neither secant nor tangent\n");
    else if(d==r)
      printf("tangent\n");
    else
      printf("secant\n");
      
}
