/* Name-Vineet Anand
   Roll-19GG20041
   Dept-GG     
   Machine Number-62 */
#include<stdio.h>
#include<math.h>
int main()
{
  float m,c,r,z;
  printf("enter m:");
  scanf("%f",&m);
  printf("enter c:");
  scanf("%f",&c);
  printf("enter r:");
  scanf("%f",&r);
  z=sqrt(1+m*m);
  if(c==r*z)
    { printf("tangent");}
  else if(c<r*z)
    { printf("secant");}
  else{printf("neither secant nor tangent");}
}
  
