/*NAME: Mithil Rajput
Roll No:19EX20021
DEPT: GEOLOGY AND GEOPHYSICS
MACHINE NO.: 18
*/
#include<stdio.h>
#include<math.h>
int main()
{
  float m, r, c, d;
  printf(" \n Enter m: ");
  scanf("%f", &m);
  printf("\n Enter c: ");
  scanf("%f", &c);
  printf("\n Enter r: ");
  scanf("%f", &r);
  d = (fabs(c))/(sqrt( m*m + 1));
  if ( d - 0.00001 < r && d + 0.00001>r )
    printf("\n Result: Tangent \n");
  else if ( d < r)
	 printf("\n Result: Secant \n");
  else 
	 printf("\n Result: neither secant nor tangent \n");
	
}
