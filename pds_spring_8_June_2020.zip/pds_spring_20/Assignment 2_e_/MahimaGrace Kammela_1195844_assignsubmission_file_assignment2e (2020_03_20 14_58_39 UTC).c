/*Name: Kammela Mahima Grace
  Roll No: 19EE30010
  Dept: Electrical Engineering
  Machine No:16
*/ 

#include<stdio.h>
#include<math.h>
int main()
{     
    double m,c,r,x,y;
    printf("Enter m\n");
    scanf("%lf",&m);
    printf("Enter c\n");
    scanf("%lf",&c);
    printf("Enter r\n");
    scanf("%lf",&r);
    
    x=sqrt((m*m)+1);
    y=fabs(c)/x;

    if(r==y)
     printf("Result:tangent\n");
    else if(r>y)
     printf("Result:secant\n");
    else
     printf("Result:neither secant nor tangent\n");
}
    
