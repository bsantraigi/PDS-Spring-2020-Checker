/* Name : Aditya Vallakatla
 Roll No : 19CS30051
 Machine No : 11
 Department : Computer Science and Engineering */
/*User gives as input the values of m and c for a straight line y=mx+c, and the value of r for a circle of radius r and center (0,0). Your program should determine whether the straight line is a secant or a tangent or none.*/
#include<stdio.h>
int main()
{
  float m,c,r,d;
  printf("Enter m:");
  scanf("%f",&m);
  printf("Enter c:");
  scanf("%f",&c);
  printf("Enter r:");
  scanf("%f",&r);
  d=((c)/(1+m*m));
 if(d==r)
printf("Result:Tangent\n");
else if(d<r)
printf("Result:Secant\n");
else if (d>r)
printf("Result:Neither Secant nor Tangent\n");
}
