/*name: ragini laskar
roll no:19MI33016
DEP:mining
machine no.:76*/
#include<stdio.h>
#include<math.h>
int main(){
  float m,c,r,d,e;
  scanf("%f%f%f",&m,&c,&r);
if(c<0)
c=c*-1;
  e=sqrt(m*m+1);
  d=c/e;
  if(d<r)
    printf("its a secant");
  else if(d==r)
    printf("its a tangent");
  else if(d>r)
    printf("its neither a secant nor a tangent");
  }
