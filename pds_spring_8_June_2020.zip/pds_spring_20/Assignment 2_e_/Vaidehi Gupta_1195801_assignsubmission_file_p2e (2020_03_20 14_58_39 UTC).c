/*
Name Vaidehi Gupta
Dep Physics
Roll No 19PH20038
Machine No 34
*/

#include<stdio.h>
#include<math.h>
int main()
{
  float p,m=0.0, c=0.0, r=0.0;
  printf("Enter m");
  scanf("%f",&m);
  printf("Enter c");
  scanf("%f",&c);
  printf("Enter r");
  scanf("%f",&c);
  if (c>0)
    
   p=c/sqrt(1+m*m);
  if (c<0)
   p=-c/sqrt(1+m*m); 
  if(p==r)
      printf("Result is Tangent");
    else if(p>r)
      printf("Result is Secant");
    else
      printf("Neither secant nor tangent");
}
  
