/*Vanshika
  Mechanical Department
  System Number 74
  19ME30056
  
*/


#include<stdio.h>
int main()

{
  float m,c,r;

  printf("enter m,c,r\n");

  scanf("%f%f%f",&m,&c,&r);


  if((r*r)==(c*c)/(1+(m*m)))


    {
      printf("tangent\n");

    }

  else if((r*r)>(c*c)/(1+(m*m)))


	   {

	     printf("secant\n");

	   }


  else

    {

      printf("none\n");

    }


  return 0;

}
