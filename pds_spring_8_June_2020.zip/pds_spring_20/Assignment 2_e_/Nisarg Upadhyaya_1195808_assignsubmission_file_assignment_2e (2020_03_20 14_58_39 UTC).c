/*
Name: Nisarg Upadhyaya
Roll Number: 19CS30031
Department: Computer Science and Engineering
Machine Number: 54
*/

/*Program to find if a line is secant, tangent or none..*/

#include <stdio.h>
#include <math.h>

int main()
{
	float m,c,r;

	printf("Enter m: ");
	scanf("%f",&m);
	printf("Enter c: ");
	scanf("%f",&c);
	printf("Enter r: ");
	scanf("%f",&r);

	float d=fabsf(c/sqrt(1+(m*m)));

	if(d<r)
		printf("Line is secant.\n");
	else if(fabsf(d-r)<0.00001)
		printf("Line is tangent.\n");
	else
		printf("Line is neither tangent nor secant.\n");

}
