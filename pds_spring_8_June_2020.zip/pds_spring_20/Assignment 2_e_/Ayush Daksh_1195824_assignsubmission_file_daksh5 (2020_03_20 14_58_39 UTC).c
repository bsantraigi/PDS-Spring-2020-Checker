/*Name:Ayush Daksh
Roll No:19MA20007
Dept:MAthematics and Computing
System no:21
*/
// c program to check if a line is tangent,secant or none to a circle

#include<stdio.h>
#include<math.h>

int main()
{
  float m,c,r,dist;
  printf("Enter m:");			     //enter slope of line
  scanf("%f",&m);
  printf("Enter c:");			     //enter y intercept
  scanf("%f",&c);
  printf("Enter r:");			     //enter radius of circle
  scanf("%f",&r);
  if(c>=0)
    dist=c/sqrt(1+m*m);			     //distance of lione from the center of circle
  else
    dist=-c/sqrt(1+m*m);
  if(dist<r)				     //checking condition for the lines
    printf("Result: Secant\n");
  else if(dist==r)
    printf("Result: tangent\n");
  else
    printf("neither secant nor tangent\n");
}
