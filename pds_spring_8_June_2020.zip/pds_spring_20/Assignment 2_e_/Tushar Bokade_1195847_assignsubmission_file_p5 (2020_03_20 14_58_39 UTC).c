/*Assignment1*/
/*Name-Tushar Bokade
Roll-19CS30011
Dept-Computer Science And Engineering
Machine No.-53*/
#include <stdio.h>
#include <math.h>
int main()
{
  float m,c,r,dist;
  printf("Enter m:");
  scanf("%f",&m);
  printf("Enter c:");
  scanf("%f",&c);
  printf("Enter r:");
  scanf("%f",&r);
  dist=fabs(c/sqrt(1+m*m));
  if (dist<r)
    printf("Result:Secant");
  else  if (dist==r)
    printf("Result:Tangent");
  else 
    printf("Result:neither secant nor tangent");
}
  
    
  
