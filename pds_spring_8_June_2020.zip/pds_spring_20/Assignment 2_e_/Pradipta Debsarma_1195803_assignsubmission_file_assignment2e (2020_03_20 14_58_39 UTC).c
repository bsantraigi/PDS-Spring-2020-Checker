/* Name- Pradipta Debsarma
   Roll-19MT10030
   Depth-Metallurgical and Materials Science Engineering
   System N.o-78 
*/
#include<stdio.h>
#include<math.h>
int main()
{ 
  float m,c,r,x,d;
  printf("Enter m and c for a straight line y=mx+c,and the value of r for a circle of radius r and center (0,0)\n");
  scanf("%f%f%f",&m,&c,&r);
  d=c/sqrt(1+m*m);
  if(c<0)
  c= -c;
  //printf("%f %f",d,r);
  if(d<r)
  printf("Result:secant");
  else if(d==r)
  printf("Result:tangent");
  else
  printf("Result: neither secant nor tangent");
}
  
  
  
  
