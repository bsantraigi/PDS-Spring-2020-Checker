/*Name - Harsh Sharma 
  Roll No. - 19AG30010
  Department - Agricultural And Food Engineering
  Machine No. - 41 */
#include<stdio.h>
#include<math.h>
int main()
{
  double m,c,r,d;
  printf("Enter m :");
  scanf("%lf",&m);
  printf("Enter c :");
  scanf("%lf",&c);
  printf("Enter r :");
  scanf("%lf",&r);
  d = fabsf(c)/sqrtl(1+(m*m));
  if(d>r)
    printf("Result : neither secant nor tangent\n");
  else if(d<r)
    printf("Result : secant\n");
  else
    printf("Result : tangent\n");
  return 0;
}
  
  
