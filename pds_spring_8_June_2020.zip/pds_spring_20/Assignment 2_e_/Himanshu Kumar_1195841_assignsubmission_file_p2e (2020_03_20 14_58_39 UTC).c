/*Himanshu Kumar
Mechanical Engineering
19ME30018
mach no=72*/
#include<stdio.h>
#include<math.h>
int main()
{float m,c,r,x,p;
  printf("Enter m:");
  scanf("%f",&m);
  printf("Enter c:");
  scanf("%f",&c);
  printf("Enter r:");
  scanf("%f",&r);
  p=sqrt(1+m*m);
  x=(c/p);
  if(x<0)
    x=-x;
  if(x==r)
    {printf("Tangent");}
  else if(x<r)
    {printf("Secant");}
  else
    printf("neither secant nor tangemt");
 }
