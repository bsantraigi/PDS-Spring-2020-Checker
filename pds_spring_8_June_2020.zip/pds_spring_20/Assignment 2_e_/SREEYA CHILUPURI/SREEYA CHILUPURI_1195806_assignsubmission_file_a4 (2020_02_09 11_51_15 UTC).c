#include <stdio.h>
#include <math.h>
int main()
{float m,c,r;
  int k,d,p;
  printf("ENTRE THE VALUES OF m,c,r:\n");
  scanf("%f%f%f",&m,&c,&r);
  k=(m*m)+1;
  d=sqrt(k);
  p=c/d;
  if(r==p)
    printf("THE LINE IS TANGENT FOR THE CIRCLE");
  else
    if(r<p)
      printf("THE LINE WILL BECOME A SECANT\n");
  
    else
      printf("THE LINE IS  NEITHER A SECANT NOR A TANGENT");
  return 0;
}
    
    
  
