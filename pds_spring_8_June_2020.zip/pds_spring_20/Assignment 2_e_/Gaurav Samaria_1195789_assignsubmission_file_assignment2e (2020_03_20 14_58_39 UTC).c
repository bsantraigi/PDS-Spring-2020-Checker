/* Name = Gaurav Samaria
   Roll Number = 19MF10014
   Department = Mechanical Engineering
   System Number = 75 */

#include<stdio.h>
#include<math.h>
int main()
{
   
   float m, c, d, r, distance;
   printf("Enter the value of m:");
   scanf("%f",&m);
   printf("Enter the value of r:");
   scanf("%f",&r);
   printf("Enter the value of c:");
   scanf("%f",&c);
 
if(c<0)
{
  d = 0-c;
}
else
{
   d=c;
}

   distance = d/sqrt(1+m*m);

if(distance == r)
{
 printf("The following line is a tangent.\n");
}
else if(distance<r)
{
 printf("The following line is a secant.\n");
}
else
{
 printf("The following line lies outside the circle.\n");
}
}



