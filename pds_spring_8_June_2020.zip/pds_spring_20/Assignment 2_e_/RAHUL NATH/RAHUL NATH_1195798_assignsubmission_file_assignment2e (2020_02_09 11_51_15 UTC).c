/*Name:Rahul Nath
roll no.:19CH10033
Dept:chemical
assignment:assignment2(e)*/
#include<stdio.h>
#include<math.h>
int main()
{
  float r,c,m,c1,dist;
  printf("enter value of slope and intercept:\n");
  scanf("%f%f",&m,&c);
  printf("enter radius:\n");
  scanf("%f",&r);
  if(c<0)
    {
      c1=-c;
      dist=c1/sqrt(m*m+1);
      if(r>=dist)
	{
	  if(r==dist)
	    {
	      printf("tangent\n");
	    }
	  else
	    {
	      printf("secant\n");
	    }
	}
      else
	{
	  printf("none\n");
	}
    }
  else
    {
      dist=c/sqrt(m*m+1);
      if(r>=dist)
	{
	  if(r==dist)
	    {
	      printf("tangent\n");
	    }
	  else
	    {
	      printf("secant\n");
	    }
	}
      else
	{
	  printf("none\n");
	}
    }
  return (0);
}
      
