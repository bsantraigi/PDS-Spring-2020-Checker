/*
NAME- P JOTHI PRAKASH
ROLL NO-19EC30028
DEPARTMENT-ECE
MACHINE NUMBER - 57 
 */

#include<stdio.h>
#include<math.h>

int main()
{
  float m,c,r,res;
  printf("Enter m:\n");
  scanf("%f",&m);
   printf("Enter c:\n");
   scanf("%f",&c);
    printf("Enter r:\n");
    scanf("%f",&r);

    // Checking Condition for tangent, secant and not touching

    res=(c/sqrt(1+m*m));
    if(res<0)
      {
	res=(-1)*res;
      }
    if(res<r)
      {
	printf("Result: secant\n");
      }
    else if(res>r)
      {
	printf("Result: neither secant nor tangent\n");
      }
      else
      {
	printf("Result: tangent\n");
      }
    
  return 0;
}
