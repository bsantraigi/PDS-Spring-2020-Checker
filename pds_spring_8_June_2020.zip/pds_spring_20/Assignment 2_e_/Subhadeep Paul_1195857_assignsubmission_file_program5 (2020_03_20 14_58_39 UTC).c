#include<stdio.h>
#include<math.h>
int main()
{
  /*
   Subhadeep Paul
   19EE10057
   Electrical Engineering
   61
   */
  float m,c,r;
  printf("Enter m:-");
  scanf("%f",&m);
  printf("Enter c:-");
  scanf("%f",&c);
  printf("Enter r:-");
  scanf("%f",&r);
  if(c<(r*sqrt(1+m*m)))
  {
	printf("Secant");
  }
  else if(c==(r*sqrt(1+m*m)))
  {
	printf("Tangent");
  }
  else
  {
	printf("Neither Tangent nor Secant");
  }
  return 0;
}
