/*
NAME: Kaushal Banthia
ROLL: 19CS10039
DEPT: Computer Science and Engineering
Machine Number: 51
*/
#include <stdio.h>
#include <math.h>
void main()
{
  float m,c,r;
  printf("Enter m: ");
  scanf("%f", &m);
  printf("Enter c: ");
  scanf("%f", &c);
  printf("Enter r: ");
  scanf("%f", &r);
  float d = (c/sqrt(1+m*m));
  if(d<0)
    d*=-1;
  if(fabsf(d-r)<0.0000001)
    printf("Result: tangent\n");
  else if(d<r)
    printf("Result: secant\n");
  else
    printf("Result: neither secant nor tangent\n");
}
