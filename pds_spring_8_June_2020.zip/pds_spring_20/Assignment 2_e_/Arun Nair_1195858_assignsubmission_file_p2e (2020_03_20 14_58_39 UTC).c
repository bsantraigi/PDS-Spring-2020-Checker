/*
Name: Arun Nair
Roll: 19IE10008
Dep: EE
System no: 64
Section 4
*/

#include <stdio.h>
#include <math.h>

int main()
{
  float m,c,r,d;
  printf("Enter m:");
  scanf("%f",&m);
  printf("Enter c:");
  scanf("%f",&c);
  printf("Enter r:");
  scanf("%f",&r);
  if (c<0)
    c=0-c;
  else
    c=c;
  d=c/(sqrt(1+(m*m)));
  
  if (d>r){
    if ((d-r)<0.000001)
    printf("Result: Tangent\n");
    else
      printf("Result: Neither secant or tangent\n");}
  if (d<r){
    if ((r-d)<0.000001)
      printf("Result: Tangent\n");
    else
      printf("Result: Secant\n");}
}
