#include<stdio.h>
/*program to find secant or tangent*/
int main()
{
  float m,c,r,a;
  printf("Enter m :");
  scanf("%f",&m);
  printf("Enter c :");
  scanf("%f",&c);
  printf("Enter r :");
  scanf("%f",&r);
  a=c/(1+m*m);
  if(a==r)
    printf("Result: Tangent\n");
  else
    printf("Result: Secant\n");
}
