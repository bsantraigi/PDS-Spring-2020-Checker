#include<stdio.h>
#include<math.h>
/* Name- Rahul Choudhary
   Roll No.: 19AE10024
   Department: Aerospace
   Machine No.: 02 */
int main()
{
/* Here we are going to compare distance of center of circle i.e. (0,0,0) from line with radius of circle. The main concept is:
If radius <distance then line is secant.
If radius =distance then line is  tangent.
If radius > distance then line is neither secant nor tangent. */
float m,c,r,distance,e;
scanf("%f %f %f",&m,&c,&r);
e=c/(sqrt(1+m*m));
distance=fabs(e);
if(distance==r)
{
printf("Tangent\n");
}
if(distance>r)
{
printf("Neither a Tangent nor a Secant\n");
}
if(distance<r)
{
printf("Secant\n");
}
return 0;
}
