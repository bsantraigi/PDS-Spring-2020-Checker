#include<stdio.h>
#include<math.h>

/*Name-Ronit Hindoddikar
  Roll no-19MT30016
  Section-4 
  Department- Metallurgical and Materials Engineering*/

int main()
{
 float m,c,r;
 scanf("enter values m,c,r %f%f%f",&m,&c,&r);
 if(r>c/sqrt(1+m*m))
{
printf("secant");
}   
else if(r=c/sqrt(1+m*m))
{
printf("tangent");
} 
else if(r<c/sqrt(1+m*m))
{
printf("tangent");
} 

}
