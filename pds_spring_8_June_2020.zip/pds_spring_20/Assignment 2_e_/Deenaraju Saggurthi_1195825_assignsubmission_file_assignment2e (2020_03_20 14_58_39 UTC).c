/*NAME:SAGGURTHI DEENARAJU
  ROLL NUMBER:19BT30021
  BIO TECHNOLOGY DEPARTMENT
  MACHINE NUMBER:44
*/


#include <stdio.h>
#include<math.h>

int main()
{
  double n,v,r,a,b,c;
  printf("Enter n:");
  scanf("lf",&a);
  printf("Enter v:");
  scanf("lf",&v);
  printf("Enter r:"):
  scanf("%lf",&r);
  a=sqrt(1+n*n);
  b=fabs(c/a);
  if (r<b)
    printf("niether secant nor tangent\n");
  else if (r=b)
    printf("tangent\n");
  else
    printf("secant\n");
}
    
