/*Name; Muskan Bhura
Roll No.: 19PH20019
Dept: Physics
Machine No.: 33*/
#include<stdio.h>
#include<math.h>
void main()
{
  double m, c, r, d=0.0;
  printf("Enter m:");  //slope of the line
  scanf("%lf",&m);
  printf("Enter c:");  //intercept of line on y axis
  scanf("%lf",&c);
  printf("Enter r:");  //radius of the circle with center (0,0)
  scanf("%lf",&r);
  d=c/(sqrt(1+m*m)); //calculating the distance of (0,0) which is the center of the circle from the line
  if(d==r)
    printf("Result: tangent\n");
  if(d>r)
    printf("Result: neither secant nor tangent\n");
  if(d<r)
    printf("Result: secant\n");
}
  
