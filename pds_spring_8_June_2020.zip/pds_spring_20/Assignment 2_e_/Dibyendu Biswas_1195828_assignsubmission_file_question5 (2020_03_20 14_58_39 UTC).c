/*
Name-Dibyendu Biswas
Roll no-19E10022
Problem no-5
machine no-14
sec-4
*/
#include<stdio.h>
#include<math.h>

int main()
{
  float m,c,d,r;
  printf("Enter m,c,r:");
  scanf("%f%f%f",&m,&c,&r);
  d=c/(sqrt(1+m*m));
  if(d<0){
    d=d*-1;
  }
  if(d==r)
    printf("Result:tangent\n");
  else if(d<r)
    printf("Result:secant\n");
   else
     printf("Result:neither\n");
    return 0;
}
