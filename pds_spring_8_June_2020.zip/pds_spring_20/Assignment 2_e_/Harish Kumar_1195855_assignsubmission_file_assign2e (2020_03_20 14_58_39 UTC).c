/*
Harish Kumar
19CE10031
Machine 46
*/

#include <stdio.h>
#include <math.h>

int main()
{
  double m,c,r,d;
  printf("Enter m:");
  scanf("%lf",&m);
  printf("Enter c:");
  scanf("%lf",&c);
  printf("Enter r:");
  scanf("%lf",&r);
  d=c/sqrt((1+m*m));
  if(d<0)
    d=-d;
  d=d-r;

  if((d>=0&&d<=0.0000000001)||(d<=0&&d>-0.0000000001))
    printf("Tangent\n");
  else if(d<0)
    printf("Secant\n");
  else
    printf("Neither secant nor tangent\n");
}
