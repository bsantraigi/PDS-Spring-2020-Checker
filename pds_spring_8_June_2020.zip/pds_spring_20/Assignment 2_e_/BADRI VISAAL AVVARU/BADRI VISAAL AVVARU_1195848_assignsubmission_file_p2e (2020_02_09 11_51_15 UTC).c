//NAME:Avvaru Badri Visaal
//Roll number:19CH10013
//Dept:Chemical Engineering
//Machine number 8
#include<stdio.h>
#include<math.h>
int main()
{
  float m,c,r,d;
  printf("Enter m:");
  scanf("%f",&m);
  printf("Enter c:");
  scanf("%f",&c);
  printf("Enter r:");
  scanf("%f",&r);
  d=c/(sqrt((1+(m*m))));
  if(c>=0){
    d=d;
  }
  else{
    d=-1*d;
  }
  if(d==r){
    printf("Tangent\n");
  }
  else if(d<r){
    printf("secant\n");
  }
  else{
    printf("none\n");
  }
}
