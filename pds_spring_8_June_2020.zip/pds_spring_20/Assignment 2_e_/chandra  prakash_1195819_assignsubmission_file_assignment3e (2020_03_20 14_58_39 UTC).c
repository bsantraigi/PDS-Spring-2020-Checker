/*Name-Chandra Prakash
 Roll No.-19EE10018
 Dept-Electrical Engineering
 System No.-59*/
#include<stdio.h>
#include<math.h>
int main()
{
  float m,c,y,x,r,d;
  printf("Enter the value of m and c");
  scanf("%f %f %f",&m,&c,&r);
  d=c/(sqrt(1+m*m));
  if(d<r)
    {
      printf("secant");
    }
  else
    if(d=r)
      printf("tangent");
    else
      printf("none");
  
  

  
}
