/*PRAUJJAWAL PRABHAKAR*/
/*19CE10051     Section 4*/
/*Assignment 2e*/

#include<stdio.h>
#include<math.h>
int main()
{
  float m, c, r,Distance;
  printf("Enter the slope of the straight line(m)\n");
  scanf("%f", &m);
  printf("Enter the intercept value(c)\n");
  scanf("%f", &c);
  printf("Enter the radius of the circle(r)\n");
  scanf("%f", &r);
  if (c>0)
    {
      Distance = (c/sqrt(1+m*m));
   if (Distance<r)
      printf("Secant\n");
    else if (Distance==r)
      printf("Tangent\n");
    else printf("None\n");
  }
  else if (c<0)
    {
      Distance = ((-c)/sqrt(1+m*m));
    if (Distance<r)
      printf("Secant\n");
    else if (Distance==r)
      printf("Tangent\n");
    else printf("None\n");
  }
}
