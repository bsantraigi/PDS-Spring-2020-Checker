/* name=a.shivani
roll no=19ME10006
depatment=mechanical
system n0=24*/
#include<stdio.h>
int main()
 {int r;
 float x1,y1,x2,y2,m,n,x,y;
 printf("enter the values of x1,y1,x2,y2,m,n:\n");
 scanf("%f %f %f %f %f %f",&x1,&y1,&x2,&y2,&m,&n);
 r=m+n;
 x=(m*x2+n*x1)/r;
 y=(m*y2+n*y1)/r;
 printf("p=(%f,%f)",x,y);
}
