/*
NAME-VATSAL VENKATKRISHNA
ROLLNO-19NA30029
DEPARTMENT-OCEAN ENGINEERING AND NAVAL ARCHITECTURE
MACHINE NO-32
*/
#include <stdio.h>
#include <math.h>
void main()
{
  double m=0.0,c=0.0,r=0.0;
  printf("Enter m:");//slope of line
    scanf("%lf",&m);
    printf("Enter c:");//y intercept of line
    scanf("%lf",&c);
    printf("Enter r:");//radius of circle
    scanf("%lf",&r);
    double x= r*sqrt(1+m*m);
    double pre=0.00001;
    if(x -c-pre<0 && x-c+pre>0)
      printf("Result: tangent\n");
    else if(x-c>0)
      printf("Result: secant\n");
    else
      printf("Result: neither tangent nor secant\n");
    
}
