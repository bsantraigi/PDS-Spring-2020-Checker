/*Name:A.N.V.S.Bhargavi
Rollno:19AE10004
Dept:Aerospace
Machine no:01*/
#include<stdio.h>
#include<math.h>
int main()
{
  float m,c,r,d;
  printf("Enter m:");
  scanf("%f",&m);
  printf("Enter c:");
  scanf("%f",&c);
  printf("Enter r:");
  scanf("%f",&r);
  d=(fabs(c))/(sqrt(m*m+1));
  if(d==r)
    printf("Result:tangent");
  else if(d<r)
    printf("Result:secant");
  else
    printf("Result:neither secant nor tangent");
}
  
