/*
name: m kavyasri
roll no:19ec10042
machine no:15
question no:2e
*/
#include<stdio.h>
#include<math.h>
int main  ()
{
  float m,c,r,a,b;
  printf("enter the radius of circle");
  scanf("%f",&r);
  printf("enter values of m and c");
  scanf("%f %f",&m,&c);
  a=sqrt(m*m+1);
  b=fabs(c)/a;
  if (b>r)
    printf("the given line is neither secant nor tangent to the circle");
  else if (b<r)
    printf("the given line is secant to the circle");
  else
    printf("the given line is  tangent to the circle");
  return 0;
}
  
