/*Name - Bbiswabasu Roy
  Roll - 19EC30008
  Dept - ECE
  Machine # - 56
*/
#include <stdio.h>
int main()
{
  double m,c,r;
  printf("Enter m: ");
  scanf("%lf",&m);
  printf("Enter c: ");
  scanf("%lf",&c);
  printf("Enter r: ");
  scanf("%lf",&r);
  
  double perpDistSq=c*c/(1+m*m);
  printf("Result: ");
  //pependicular distance of line from centre of circle = c/sqrt(1+m^2)
  if(perpDistSq<r*r)
    printf("secant\n"); //square of _L distance < radius^2=> line is secant
  else if(perpDistSq==r*r)
    printf("tangent\n"); //square of _L distance == radius^2=> line is tangent
  else
    printf("neither secant nor tangent\n"); //square of _L distance > radius^2=> line is secant nor tangent
}
