/*Pranit Mendhe
Mechanical Department
19ME30037
Machine no.:73*/


#include<stdio.h>
#include<math.h>
float main()
{
  float m,c,r,d,a;
  printf("Enter the values of m,c,r: ");
  scanf("%f%f%f",&m,&c,&r);
  a=sqrt(1+m*m);
  d=c/a;
  if(d==r)
    printf("Given line is a tangent\n");
  if(d>r)
    printf("Given line is neither a tangent nor a secant\n");
  if(d<r)
    printf("Given line is a secant\n");
}
