/*
  Name       :  K.T.Shalik
  Roll No    :  19CY20020
  Dept       :  Chemistry
  Machine No ;  12

  User gives as input the values of m and c for a straight line y=mx+c, and the value of r for a circle of radius r and center (0,0). Your program should determine whether the straight line is a secant or a tangent or none.*/

#include<stdio.h>
int main()
{
  float m,c,r;
  float d;
  printf("enter the slope,intercept and radius\n");
  scanf("%f",&m);
  scanf("%f",&c);
  scanf("%f",&r);

  d=((c)/(1+m*m));
  {
    if(d==r)
      {
	printf(" tangent");
      }
   else if(d>r)
    {
	printf("neither secant nor tangent");
      }
   else if(d<r)
    {
	printf("secant");
      }
  }
}
