/*A program to check whether straight line y=m*x+c is a secant or tangent to the circle of radius r and centre (0,0) */
#include<stdio.h>
#include<math.h>
int main()
{
  float m,c,r;
  printf("\nEnter m:");
  scanf("%f",&m);
  printf("\nEnter c:");
  scanf("%f",&c);
  printf("\nEnter r:");
  scanf("%f",&r);
  if(r>(c/sqrt(1+(m*m))))
    printf("Result:Secant");
  else if(r==(c/sqrt(1+(m*m))))
    printf("\nResult:Tangent");
  else
    printf("\nResult:neither secant nor tangent");
}
  
  
