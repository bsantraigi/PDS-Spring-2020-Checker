/*NAME : SHREYAS RANJAN PANDA 
ROLL NO : 19ME10063
DEPT : MECHANICAL ENGINEERING 
MACHINE NO: 70 */
#include <stdio.h>
#include <math.h>
int main()
{
  double m,c,r,d,k;
  scanf("%lf%lf%lf",&m,&c,&r);
  k=sqrt(1+m*m);
  d=c/k;
  if(d<0){d=-d;}
  if(r==d){printf("this is tangent");}
  if(r>d){printf("this is secant");}
  if(r<d){printf("this is neither tangent nor secant");}
  
    
  
}
