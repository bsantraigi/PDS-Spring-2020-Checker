/* Name:- Venkat Siddish Gudla
   Roll No:- 19EC30048
   Dept:- ECE
   System No:- 58*/
#include<stdio.h>
#include<math.h>
int main()
{
  float m,c,r,distance;
  scanf(" %f,%f,%f\n",&m,&c,&r);
  distance=((c)/(sqrt((m*m)+1)));
  if(distance<0)
    {
      distance=(-1)*distance;
    }
  if(distance<r)
    {
      printf("Straight line is a Secant");
    }
  else if(distance==r)
    {
      printf("Straight line is a Tangent");
    }
  else
    {
      printf("Straight line is neither Secant nor Tangent");
    }
}
	    
