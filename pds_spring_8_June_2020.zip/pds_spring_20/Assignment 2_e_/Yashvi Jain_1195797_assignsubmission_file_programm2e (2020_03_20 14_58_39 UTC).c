/*Yashvi Jain
19CH30028
Dept:Chemical
Machine no : 49*/

#include <stdio.h>
#include <math.h>

int main(){
  printf("enter the value of m,c for the straight line y=mx+c\n");
  float m,c;
  scanf("%f%f",&m,&c);
  printf("enter value of radius of a circle centered ot origin\n");
  float r;
  scanf("%f",&r);
  float d,e;
  e = sqrt(m*m+1);
  d = c/e;
  if (fabsf(d-r)<0.000000000001)
    printf("the line is a tangent\n");
  else if (d<r)
    printf("the line is a secant\n");
  else
    printf("not a tangent or secant\n");
}
  
