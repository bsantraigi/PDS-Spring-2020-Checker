## INPUT 
`-1 1 0.70710678118
`
## ROLL: BADRI VISAAL AVVARU

> **Compilation Status**: SUCCESS

OUTPUT
---
```
Enter m:Enter c:Enter r:Tangent

```
> **SRC:** Assignment 2_e_/BADRI VISAAL AVVARU/BADRI VISAAL AVVARU_1195848_assignsubmission_file_p2e.c
```C++
//NAME:Avvaru Badri Visaal
//Roll number:19CH10013
//Dept:Chemical Engineering
//Machine number 8
#include<stdio.h>
#include<math.h>
int main()
{
  float m,c,r,d;
  printf("Enter m:");
  scanf("%f",&m);
  printf("Enter c:");
  scanf("%f",&c);
  printf("Enter r:");
  scanf("%f",&r);
  d=c/(sqrt((1+(m*m))));
  if(c>=0){
    d=d;
  }
  else{
    d=-1*d;
  }
  if(d==r){
    printf("Tangent\n");
  }
  else if(d<r){
    printf("secant\n");
  }
  else{
    printf("none\n");
  }
}

```
## ROLL: BHARGAVI ADUSUMILLI

> **Compilation Status**: SUCCESS

OUTPUT
---
```
Enter m:Enter c:Enter r:Result:tangent
```
> **SRC:** Assignment 2_e_/BHARGAVI ADUSUMILLI/BHARGAVI ADUSUMILLI_1195793_assignsubmission_file_assign2e.c
```C++
/*Name:A.N.V.S.Bhargavi
Rollno:19AE10004
Dept:Aerospace
Machine no:01*/
#include<stdio.h>
#include<math.h>
int main()
{
  float m,c,r,d;
  printf("Enter m:");
  scanf("%f",&m);
  printf("Enter c:");
  scanf("%f",&c);
  printf("Enter r:");
  scanf("%f",&r);
  d=(fabs(c))/(sqrt(m*m+1));
  if(d==r)
    printf("Result:tangent");
  else if(d<r)
    printf("Result:secant");
  else
    printf("Result:neither secant nor tangent");
}
  

```
## ROLL: DEDIPYA YALAM

> **Compilation Status**: SUCCESS

OUTPUT
---
```

Enter m:
Enter c:
Enter r:
Result:neither secant nor tangent
```
> **SRC:** Assignment 2_e_/DEDIPYA YALAM/DEDIPYA YALAM_1195822_assignsubmission_file_circle.c
```C++
/*A program to check whether straight line y=m*x+c is a secant or tangent to the circle of radius r and centre (0,0) */
#include<stdio.h>
#include<math.h>
int main()
{
  float m,c,r;
  printf("\nEnter m:");
  scanf("%f",&m);
  printf("\nEnter c:");
  scanf("%f",&c);
  printf("\nEnter r:");
  scanf("%f",&r);
  if(r>(c/sqrt(1+(m*m))))
    printf("Result:Secant");
  else if(r==(c/sqrt(1+(m*m))))
    printf("\nResult:Tangent");
  else
    printf("\nResult:neither secant nor tangent");
}
  
  

```
## ROLL: RAHUL CHOUDHARY

> **Compilation Status**: SUCCESS

OUTPUT
---
```
Tangent

```
> **SRC:** Assignment 2_e_/RAHUL CHOUDHARY/RAHUL CHOUDHARY_1195815_assignsubmission_file_Assignment2(e).c
```C++
#include<stdio.h>
#include<math.h>
/* Name- Rahul Choudhary
   Roll No.: 19AE10024
   Department: Aerospace
   Machine No.: 02 */
int main()
{
/* Here we are going to compare distance of center of circle i.e. (0,0,0) from line with radius of circle. The main concept is:
If radius <distance then line is secant.
If radius =distance then line is  tangent.
If radius > distance then line is neither secant nor tangent. */
float m,c,r,distance,e;
scanf("%f %f %f",&m,&c,&r);
e=c/(sqrt(1+m*m));
distance=fabs(e);
if(distance==r)
{
printf("Tangent\n");
}
if(distance>r)
{
printf("Neither a Tangent nor a Secant\n");
}
if(distance<r)
{
printf("Secant\n");
}
return 0;
}

```
## ROLL: RAHUL NATH

> **Compilation Status**: SUCCESS

OUTPUT
---
```
enter value of slope and intercept:
enter radius:
tangent

```
> **SRC:** Assignment 2_e_/RAHUL NATH/RAHUL NATH_1195798_assignsubmission_file_assignment2e.c
```C++
/*Name:Rahul Nath
roll no.:19CH10033
Dept:chemical
assignment:assignment2(e)*/
#include<stdio.h>
#include<math.h>
int main()
{
  float r,c,m,c1,dist;
  printf("enter value of slope and intercept:\n");
  scanf("%f%f",&m,&c);
  printf("enter radius:\n");
  scanf("%f",&r);
  if(c<0)
    {
      c1=-c;
      dist=c1/sqrt(m*m+1);
      if(r>=dist)
	{
	  if(r==dist)
	    {
	      printf("tangent\n");
	    }
	  else
	    {
	      printf("secant\n");
	    }
	}
      else
	{
	  printf("none\n");
	}
    }
  else
    {
      dist=c/sqrt(m*m+1);
      if(r>=dist)
	{
	  if(r==dist)
	    {
	      printf("tangent\n");
	    }
	  else
	    {
	      printf("secant\n");
	    }
	}
      else
	{
	  printf("none\n");
	}
    }
  return (0);
}
      

```
## ROLL: SHIVAM LAHOTI

> **Compilation Status**: SUCCESS

OUTPUT
---
```
enter m, c and r respectively 
result= tangent

```
> **SRC:** Assignment 2_e_/SHIVAM LAHOTI/SHIVAM LAHOTI_1195861_assignsubmission_file_assignment2e.c
```C++
#include<stdio.h>
#include<math.h>
int main()
{
  /*name- Shivam Lahoti
roll no.- 19AG10028
machine no.- 5
department- Agriculture and food engineering*/
  float m,c,r,d,d1,c1,dist;
  printf("enter m, c and r respectively \n");
  scanf("%f%f%f",&m,&c,&r);
  c1=fabs(c);
  d=1+m*m;
  d1=sqrt(d);
  dist=c1/d1;
  if(dist<r)
    printf("result= secant \n");
    else if (dist == r)
      printf("result= tangent\n");
    else
      printf("result= neither tangent nor secant \n");
}

```
## ROLL: SHIVANI SOREN

> **Compilation Status**: SUCCESS

OUTPUT
---
```
Enter m :Enter c :Enter r :Result: Secant

```
> **SRC:** Assignment 2_e_/SHIVANI SOREN/SHIVANI SOREN_1195829_assignsubmission_file_tangent.c
```C++
#include<stdio.h>
/*program to find secant or tangent*/
int main()
{
  float m,c,r,a;
  printf("Enter m :");
  scanf("%f",&m);
  printf("Enter c :");
  scanf("%f",&c);
  printf("Enter r :");
  scanf("%f",&r);
  a=c/(1+m*m);
  if(a==r)
    printf("Result: Tangent\n");
  else
    printf("Result: Secant\n");
}

```
## ROLL: SHREE HARSHA KODI

> **Compilation Status**: SUCCESS

OUTPUT
---
```
Enter the values:tangent
```
> **SRC:** Assignment 2_e_/SHREE HARSHA KODI/SHREE HARSHA KODI_1195817_assignsubmission_file_assignment2(e).c
```C++
/*Name:Kodi Shree Harsha
Roll No:19AE30009
Machine No:3
Department:Aerospace*/

#include<stdio.h>
#include<math.h>
int main()
{
  float m,c,r,d;
  printf("Enter the values:");
  scanf("%f%f%f",&r,&c,&m);
  d=c/(sqrt(m*m +1));
	 if(r=d)
	   {printf("tangent");}
	 else if(r>d)
	   {printf("secant");}
	 else
	   {printf("none");}
	  
    return(0);
}

```
## ROLL: SOHAM ZADE

> **Compilation Status**: SUCCESS

OUTPUT
---
```
Enter m
Enter c
Enter r
Line is tangent.

```
> **SRC:** Assignment 2_e_/SOHAM ZADE/SOHAM ZADE_1195788_assignsubmission_file_program2e.c
```C++
/* Name: Soham Zade
   Roll no:19CH10053
   Machine no: 10
   Program for line and circle*/

#include<stdio.h>
#include<math.h>

int main()
{float m, c, r, d;

  printf("Enter m\n");
  scanf("%f", &m);
  printf("Enter c\n");
  scanf("%f", &c);
  printf("Enter r\n");
  scanf("%f", &r);

  d= c/sqrt(1+m*m); //perpendicular distance from center of circle to line//

  if(d<r)
    {printf("Line is secant.\n");}
  else if(d==r)
    {printf("Line is tangent.\n");}
  else if(d>r)
    {printf("Line is neither secant nor tangent.\n ");}
  
  

}

```
## ROLL: SREEYA CHILUPURI

> **Compilation Status**: SUCCESS

OUTPUT
---
```
ENTRE THE VALUES OF m,c,r:
THE LINE WILL BECOME A SECANT

```
> **SRC:** Assignment 2_e_/SREEYA CHILUPURI/SREEYA CHILUPURI_1195806_assignsubmission_file_a4.c
```C++
#include <stdio.h>
#include <math.h>
int main()
{float m,c,r;
  int k,d,p;
  printf("ENTRE THE VALUES OF m,c,r:\n");
  scanf("%f%f%f",&m,&c,&r);
  k=(m*m)+1;
  d=sqrt(k);
  p=c/d;
  if(r==p)
    printf("THE LINE IS TANGENT FOR THE CIRCLE");
  else
    if(r<p)
      printf("THE LINE WILL BECOME A SECANT\n");
  
    else
      printf("THE LINE IS  NEITHER A SECANT NOR A TANGENT");
  return 0;
}
    
    
  

```
