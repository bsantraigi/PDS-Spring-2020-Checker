## INPUT 
`2 -2 0
`
## ROLL: BADRI VISAAL AVVARU

> **Compilation Status**: SUCCESS

OUTPUT
---
```
enter the three numbers:A.P

```
> **SRC:** Assignment 2_b_/BADRI VISAAL AVVARU/BADRI VISAAL AVVARU_1195680_assignsubmission_file_p2b.c
```C++
//NAME:Avvaru Badri Visaal
//Roll number:19CH10013
//Dept:Chemical Engineering
//Machine number 8
#include<stdio.h>
int main()
{
  float a,b,c,max1,max2,max3,max,min,x,y;
  printf("enter the three numbers:");
  scanf("%f%f%f",&a,&b,&c);
  if(a>b)
    {
      max=a;
      min=b;
    }
  else
    {
      max=b;
      min=a;
    }
  if(max>c)
    {
      max1=max;
      if(min>c)
	{
	  max2=min;
	  max3=c;
	}
      else
	{
	  max2=c;
	  max3=min;
	}
    }
  else
    {
      max1=c;
      max2=max;
      max3=min;
    }
  x=max2-max3;
  y=max1-max2;
  if(x==y)
    printf("A.P\n");
  else
    printf("Not A.P\n");
}

```
## ROLL: BHARGAVI ADUSUMILLI

> **Compilation Status**: SUCCESS

OUTPUT
---
```
Enter three numbers:Result:A.P.
```
> **SRC:** Assignment 2_b_/BHARGAVI ADUSUMILLI/BHARGAVI ADUSUMILLI_1195653_assignsubmission_file_assign2b.c
```C++
/*Name:A.N.V.S.Bhargavi
Rollno:19AE10004
Dept:Aerospace
Machine no:01*/
#include<stdio.h>
int main()
{
  float a,b,c;
  printf("Enter three numbers:");
  scanf("%f %f %f",&a,&b,&c);
  if(b==(a+c)*0.5)
    printf("Result:A.P.");
  else if(a==(b+c)*0.5)
    printf("Result:A.P.");
  else if(c==(b+a)*0.5)
    printf("Result:A.P.");
  else printf("Result:Not A.P.");
}

  

```
## ROLL: DEDIPYA YALAM

> **Compilation Status**: SUCCESS

OUTPUT
---
```

Enter three numbers:
A.P.
```
> **SRC:** Assignment 2_b_/DEDIPYA YALAM/DEDIPYA YALAM_1195657_assignsubmission_file_ap.c
```C++
/*A program to read an print three no.s and check whether they form A.P. if arranged in order*/
#include<stdio.h>
int main()
{
  float a,b,c;
  printf("\nEnter three numbers:");
  scanf("%f%f%f",&a,&b,&c);
  if(a>b)
    if(b>c)
      if(2*b==a+c)
	printf("\nA.P.");
      else
        printf("\nNot A.P.");
    else
       if(a>c)
	if(2*c==a+b)
	  printf("\nA.P.");
        else
	  printf("\nNot A.P.");
       else	
           if(2*a==c+b)
    	     printf("\nA.P.");
           else
             printf("\nNot A.P.");
  else
    if(a>c)
      if(2*a==b+c)
	printf("\nA.P.");
      else
        printf("\nNot A.P.");
    else
       if(b>c)
	if(2*c==a+b)
	  printf("\nA.P.");
        else
	  printf("\nNot A.P.");
       else	
          if(2*b==c+a)
 	    printf("\nA.P.");
          else
   	    printf("\nNot A.P.");
}
    
  

```
## ROLL: RAHUL CHOUDHARY

> **Compilation Status**: SUCCESS

OUTPUT
---
```
AP

```
> **SRC:** Assignment 2_b_/RAHUL CHOUDHARY/RAHUL CHOUDHARY_1195659_assignsubmission_file_Assignment2(b).c
```C++
#include<stdio.h>
#include<math.h>
/* Name- Rahul Choudhary
   Roll No.: 19AE10024
   Department: Aerospace
   Machine No.: 02 */
int main()
{
 float a,b,c,d,e,f;
scanf("%f %f %f",&a,&b,&c);
d=(a+c)/(2.0);
e=(b+c)/(2.0);
f=(a+b)/(2.0);
if(fabs(b-d)<1e-6) /* Here rather than using b==d we are using fabs(b-d)<1e-6 because after calculation we might not get accurate value of d and our program will     give false output */ 
{
printf("AP\n");
}
else if(fabs(a-e)<1e-6) /* Here rather than using a==e we are using fabs(a-e)<1e-6 because after calculation we might not get accurate value of e and our program will  give false output */  
{
printf("AP\n");
}
else if(fabs(c-f)<1e-6) /* Here rather than using c==f we are using fabs(c-f)<1e-6 because after calculation we might not get accurate value of f and our program will  give false output */  
{
printf("AP\n");
}
else 
{
printf("Not AP\n");
}
return 0;
}

```
## ROLL: RAHUL NATH

> **Compilation Status**: SUCCESS

OUTPUT
---
```
enter 3 distinct numbers:
numbers are in AP

```
> **SRC:** Assignment 2_b_/RAHUL NATH/RAHUL NATH_1195708_assignsubmission_file_assignment2b.c
```C++
/*Name:Rahul Nath
roll no.:19CH10033
Dept:chemical
assignment:assignment2(b)*/
#include<stdio.h>
int main()
{
  float i,j,k,swap1,swap2,swap3;
  printf("enter 3 distinct numbers:\n");
  scanf("%f%f%f",&i,&j,&k);
  swap1=(i+k)/2;
  swap2=(k+j)/2;
  swap3=(i+j)/2;
  
  if(swap1==j)
    {
      printf("numbers are in AP\n");
    }
  
  else if(swap2==i)
    {
      printf("numbers are in AP\n");
    }
 
  else if(swap3==k)
    {
      printf("numbers are in AP\n");
    }

  else
    {
      printf("numbers are not in AP\n");
    }
  return (0);
}
	  
      
      
  

```
## ROLL: SHIVAM LAHOTI

> **Compilation Status**: SUCCESS

OUTPUT
---
```
enter three numbers
AP 

```
> **SRC:** Assignment 2_b_/SHIVAM LAHOTI/SHIVAM LAHOTI_1195693_assignsubmission_file_assignment2b.c
```C++
#include<stdio.h>
int main()
{
  /*name- Shivam Lahoti
roll no.- 19AG10028
machine no.- 5
department- Agriculture and food engineering*/
  float a,b,c,d;
  printf("enter three numbers\n");
  scanf("%f%f%f",&a,&b,&c);
  if((a>b)&&(a>c))
    {
      if(b>c)
	{
	  d=a+c-(2*b);
	}
      else{
	d=a+b-(2*c);
      }}
  else if((b>a)&&(b>c))
    {
      if(a>c)
	{
	  d=b+c-(2*a);
	}
      else{
	d=a+b-(2*c);
	  }}
  else{
    if(a>b)
      {
	d=b+c-(2*a);
      }
    else{
      d=c+a-(2*b);
    }}
  if(d<0.000000000022)
    {
      printf("AP \n");
    }
  else{
    printf("not AP \n");
  }}
      

```
## ROLL: SHIVANI SOREN
Compilation Status: FAILED
> **SRC:** Assignment 2_b_/SHIVANI SOREN/SHIVANI SOREN_1195673_assignsubmission_file_ap.c
```C++
#include<stdio.h>
/*Program to find whether three numbers are in AP or not*/
int main()
{
  float a,b,c,d1,d2,d3;
  printf("Enter three numbers : ");
  scanf("%f %f %f",&a,&b,&c);
  if(a>b)
    {if(a>c)
	{d3=a;
	  if(b>c)
	    {d1=c;d2=b;}
	  else
	    {d1=b;d2=c;}
	}
    }
      else
	{if(b>c)
	    { d3=b;
	  if(a>c)
	    {d1=c;d2=a;}
	  else
	    {d1=a;d2=c;}}
	}
  else
    {if(b>c)
	{d3=b;
	  if(a>c)
	    {d1=c;d2=a;}
	  else
	    {d1=a;d2=c;}
	}
    }
      else
	{d3=c;
	  if(b>c)
	    {d1=c;d2=b;}
	  else
	    {d1=b;d2=c;}
	}
}
  if(d2==(d1+d3)/2)
     printf("Result : AP");
  else
     printf("Result : Not AP");

}

```
## ROLL: SHREE HARSHA KODI

> **Compilation Status**: SUCCESS

OUTPUT
---
```
Enter the values of A,B,C:A.P.
```
> **SRC:** Assignment 2_b_/SHREE HARSHA KODI/SHREE HARSHA KODI_1195677_assignsubmission_file_assignment2(b).c
```C++
/*Name:Kodi Shree Harsha
Roll No:19AE30009
Machine No:3
Department:Aerospace*/

#include<stdio.h>
int main()
{
  float  A,B,C;
  printf("Enter the values of A,B,C:");
  scanf("%f %f %f",&A,&B,&C);
  if(A<B)
    {if(C<B) 
	{C=(A+B)/2;
      printf(" A.P.");}
      //else(B<C)
      //    {B=(A+C)/2;
      //      printf("A.P.");}
    }
    else if(B<C)
      {if(A<C)
	  {C=(A+B)/2;
	    printf("A.P");}
	else(C>A)
	      ; {A=(C+B)/2;
		printf("A.P.");}}
	else if(C<A)
	  {if(A<B)
	      {B=(A+C)/2;
		printf("A.P.");}
	    else(A>B)
		  ; {A=(B+C)/2;
		    printf("A.P.");}}
	    else
	    
    {printf("not A.P.");}
    
    return(0);
}

```
## ROLL: SOHAM ZADE

> **Compilation Status**: SUCCESS

OUTPUT
---
```
Enter three numbers
AP
```
> **SRC:** Assignment 2_b_/SOHAM ZADE/SOHAM ZADE_1195674_assignsubmission_file_program2b.c
```C++
/* Name: Soham Zade
   Roll no: 19CH10053
   Machine no: 10
   Program for AP*/

#include<stdio.h>
#include<math.h>

int main ()

{float a, b, c;

  printf("Enter three numbers\n");
  scanf("%f %f %f", &a, &b, &c);
  
  if(fabs((b-a)-(c-b))<1e-6 || fabs((a-c)==(b-a))<1e-6 ||fabs ((c-b)==(a-c))<1e-6)
    {printf("AP");}
  else
    {printf("Not AP");}


}

```
## ROLL: SREEYA CHILUPURI

> **Compilation Status**: SUCCESS

OUTPUT
---
```
Enter the values of a,b,c:
RESULT:FORMS AN A.P
```
> **SRC:** Assignment 2_b_/SREEYA CHILUPURI/SREEYA CHILUPURI_1195664_assignsubmission_file_a2.c
```C++
#include <stdio.h>
int main()
{float  a,b,c;
  printf("Enter the values of a,b,c:\n");
  scanf("%f%f%f",&a,&b,&c);
  b=(a+c)/2;
  if( b==(a+c)/2 )
    printf("RESULT:FORMS AN A.P");
  else
    printf("RESULT:DOES'NT FORMS AN A.P");
  return 0;
}
  

```
