## INPUT 
`1 0 1
`
## ROLL: BADRI VISAAL AVVARU

> **Compilation Status**: SUCCESS

OUTPUT
---
```
enter the three values from equation:the roots are complex
```
> **SRC:** Assignment 2_c_/BADRI VISAAL AVVARU/BADRI VISAAL AVVARU_1195751_assignsubmission_file_p2c.c
```C++
//NAME:Avvaru Badri Visaal
//Roll number:19CH10013
//Dept:Chemical Engineering
//Machine number 8
#include<stdio.h>
#include<math.h>
int main()
{
  float a,b,c,d,r1,r2;
  printf("enter the three values from equation:");
  scanf("%f%f%f",&a,&b,&c);
  d=(b*b)-(a*c*4);
  if(d>=0)
    {
      r1=((-1*b)+sqrt(d))/(2*a);
      r2=((-1*b)-sqrt(d))/(2*a);
      printf("the roots are %f %f\n",r1,r2);
    }
  else
    printf("the roots are complex");
}

```
## ROLL: BHARGAVI ADUSUMILLI

> **Compilation Status**: SUCCESS

OUTPUT
---
```
Enter a,b,c:roots are complex
```
> **SRC:** Assignment 2_c_/BHARGAVI ADUSUMILLI/BHARGAVI ADUSUMILLI_1195753_assignsubmission_file_assign2c.c
```C++
/*Name:A.N.V.S.Bhargavi
Rollno:19AE10004
Dept:Aerospace
Machine no:01*/
#include<stdio.h>
#include<math.h>
main()
{
  float a,b,c,d,x,y;
  printf("Enter a,b,c:");
  scanf("%f %f %f",&a,&b,&c);
  d=b*b-4*a*c;
  if(d<0)
    printf("roots are complex");
    else
      {
	x=(-b+sqrt(d))/(2*a);
	y=(-b-sqrt(d))/(2*a);
	printf("Roots=%f,%f",x,y);
      }
}
  

```
## ROLL: DEDIPYA YALAM

> **Compilation Status**: SUCCESS

OUTPUT
---
```

Enter a,b,c:
Roots are complex
```
> **SRC:** Assignment 2_c_/DEDIPYA YALAM/DEDIPYA YALAM_1195734_assignsubmission_file_roots.c
```C++
/*A program to print roots of a quadratic equation a*x*x+b*x+c=0 if they are real*/
#include<stdio.h>
#include<math.h>
int main()
{
  float a,b,c,d,r1,r2;
  printf("\nEnter a,b,c:");
  scanf("%f%f%f",&a,&b,&c);
  d=b*b-4*a*c;
  if(d<0)
    printf("\nRoots are complex");
  else
    {
      r1=(-b+sqrt(d))/2*a;
      r2=(-b-sqrt(d))/2*a;
      printf("\nRoots= %f,%f",r1,r2);
    }
}
  
    
  

```
## ROLL: RAHUL CHOUDHARY

> **Compilation Status**: SUCCESS

OUTPUT
---
```
Root are Complex

```
> **SRC:** Assignment 2_c_/RAHUL CHOUDHARY/RAHUL CHOUDHARY_1195759_assignsubmission_file_Assignment2(c).c
```C++
#include<stdio.h>
#include<math.h>
/* Name- Rahul Choudhary
   Roll No.: 19AE10024
   Department: Aerospace
   Machine No.: 02 */
int main()
{
  float a,b,c,d;
  scanf("%f %f %f",&a,&b,&c);/* User enters the coefficients of quadratic equation */
  d=(b*b)-(4*a*c);   /* This is the calculatuion of discriminant which will be used in calculation
                        of roots */
if(d<0)
{
printf("Root are Complex\n");
}
else
{
float root1,root2;
root1 =(-b+sqrt(d))/((2.0)*a);
root2 =(-b-sqrt(d))/((2.0)*a);
 printf("Roots = %f %f\n",root1,root2);
}
return 0;
}

```
## ROLL: RAHUL NATH

> **Compilation Status**: SUCCESS

OUTPUT
---
```
enter coeffs of quadratic eqn:
roots are complex
```
> **SRC:** Assignment 2_c_/RAHUL NATH/RAHUL NATH_1195766_assignsubmission_file_assignment2c.c
```C++
/*Name:Rahul Nath
roll no.:19CH10033
Dept:chemical
assignment:assignment2(c)*/
#include<stdio.h>
#include<math.h>
int main()
{
  float a,b,c,D,x1,x2;
  printf("enter coeffs of quadratic eqn:\n");
  scanf("%f%f%f",&a,&b,&c);
  D=sqrt(b*b-4*a*c);
  if(D>=0)
    {
      x1=(-b+D)/(2*a);
      x2=(-b-D)/(2*a);
      printf("real roots are:%f and %f \n",x1,x2);
    }
  else
    printf("roots are complex");
  return (0);
}
  

```
## ROLL: SHIVAM LAHOTI

> **Compilation Status**: SUCCESS

OUTPUT
---
```
enter the coefficients of the quadratic equation 
the roots are complex 

```
> **SRC:** Assignment 2_c_/SHIVAM LAHOTI/SHIVAM LAHOTI_1195719_assignsubmission_file_assignment2c.c
```C++
#include<stdio.h>
#include<math.h>
int main()
{
  /*name- Shivam Lahoti
roll no.- 19AG10028
machine no.- 5
department- Agriculture and food engineering*/
  float a,b,c,d,d1,r1,r2;
  printf("enter the coefficients of the quadratic equation \n");
  scanf("%f%f%f",&a,&b,&c);
  d=b*b-4*a*c;
  if(d<0.00)
    {printf("the roots are complex \n");}
  else{
    r1= (-b+d)/(2*a);
    r2=(-b-d)/(2*a);
    printf("roots= %f ,%f \n",r1,r2);
  }}

```
## ROLL: SHIVANI SOREN

> **Compilation Status**: SUCCESS

OUTPUT
---
```
Enter a,b,c : Roots are complex

```
> **SRC:** Assignment 2_c_/SHIVANI SOREN/SHIVANI SOREN_1195749_assignsubmission_file_roots.c
```C++
#include<stdio.h>
#include<math.h>
/*program to find roots of quadratic equation*/
int main()
{
  float a,b,c,d;
  int x1,x2;
  printf("Enter a,b,c : ");
  scanf("%f %f %f",&a,&b,&c);
  d=b*b-4*a*c;
  if(d<0)
    printf("Roots are complex\n");
  else
    {
      x1=(-b+sqrt(d))/2*a;
      x2=(-b-sqrt(d))/2*a;
    
        printf("Roots = %d %d\n",x1,x2);
    }
}
  

```
## ROLL: SHREE HARSHA KODI
Compilation Status: FAILED
> **SRC:** Assignment 2_c_/SHREE HARSHA KODI/SHREE HARSHA KODI_1195713_assignsubmission_file_Assignment 2(c).c
```C++
/*Name:Kodi Shree Harsha
Roll No:19AE30009
Machine No:3
Department:Aerospace*/

#include<stdio.h>
#include<math.h>
int main()
{
  float a,b,c,d,x,y;
  printf("Enter the values:");
  scanf("%f %f %f ",&a,&b,&c);
  d=(b*b-4*a*c);
  if(d<0)
    {printf("roots are complex")}
  else(d>=0)
	{x=(-b+sqrt(d))/2*a;
	  y=(-b-sqrt(d))/2*a;
	  
 
	  printf("The roots are %f ,%f",x,y); }
    return(0);
}

```
## ROLL: SOHAM ZADE

> **Compilation Status**: SUCCESS

OUTPUT
---
```
Enter a, b, c
Roots are complex.

```
> **SRC:** Assignment 2_c_/SOHAM ZADE/SOHAM ZADE_1195721_assignsubmission_file_program2c.c
```C++
/* Name: Soham Zade
   Roll no: 19CH10053
   Machine no: 10
   Roots of quadratic equation*/

#include<stdio.h>
#include<math.h>

int main()
{float a, b, c, d, x1, x2;

  printf("Enter a, b, c\n");
  scanf("%f %f %f", &a, &b, &c);

  d= b*b-4*a*c; //formula for discriminant//

    if(d>=0)
      {x1= (-b + sqrt(b*b-4*a*c))/2*a; //Formula for roots//
       x2= (-b - sqrt(b*b-4*a*c))/2*a;

       printf("Roots are %f, %f\n", x1, x2);
      }
    else
      {printf("Roots are complex.\n");}

       



}

```
## ROLL: SREEYA CHILUPURI

> **Compilation Status**: SUCCESS

OUTPUT
---
```
ENTER THE VALUES OF a,b,c:
Roots are complex
```
> **SRC:** Assignment 2_c_/SREEYA CHILUPURI/SREEYA CHILUPURI_1195736_assignsubmission_file_a3.c
```C++
#include <stdio.h>
#include <math.h>
int main()
{int a,b,c,y;
  float d,r1,r2;
  printf("ENTER THE VALUES OF a,b,c:\n");
  scanf("%d%d%d",&a,&b,&c);
  y=sqrt(d);
  d=(b*b)-(4*a*c);
  r1=((-2*b)+(y))/2*a;
  r2=((-2*b)-(y))/2*a;
  if (d>0){
    printf("VALUES OF r1 and r2:\n");
  printf("%f%f",r1,r2);
  }
  else
    printf("Roots are complex");
  return 0;
}
     
  
  

```
