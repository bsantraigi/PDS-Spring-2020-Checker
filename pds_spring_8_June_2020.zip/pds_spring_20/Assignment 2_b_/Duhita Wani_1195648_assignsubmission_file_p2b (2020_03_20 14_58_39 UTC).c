/*Duhita Wani
19ME10082
Mechanical Engineering
Machine no - 71*/

#include<stdio.h>
int main()

{float a,b,c,x,n1;
  printf("Enter three numbers=");
  scanf("%f %f %f",&a,&b,&c);

  if (b>=a&&b>=c)
    {n1=a;
      a=c;
      c=n1;
    }
  else if (c>=a&&c>=b)
    {n1=a;
      a=b;
      b=n1;
    }
  if (c>=b)
    {n1=b;
      b=c;
      c=n1;
    }
  x=(b-a)-(b-c);
  if (x<0)
    x=-x;
  if(x<0.0001)  
    printf("AP");
  else
    printf("Not AP");
  
  return 0;
}
