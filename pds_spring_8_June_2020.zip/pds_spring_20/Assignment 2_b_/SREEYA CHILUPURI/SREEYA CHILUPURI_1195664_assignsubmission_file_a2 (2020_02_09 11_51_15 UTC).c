#include <stdio.h>
int main()
{float  a,b,c;
  printf("Enter the values of a,b,c:\n");
  scanf("%f%f%f",&a,&b,&c);
  b=(a+c)/2;
  if( b==(a+c)/2 )
    printf("RESULT:FORMS AN A.P");
  else
    printf("RESULT:DOES'NT FORMS AN A.P");
  return 0;
}
  
