/*Name:A.N.V.S.Bhargavi
Rollno:19AE10004
Dept:Aerospace
Machine no:01*/
#include<stdio.h>
int main()
{
  float a,b,c;
  printf("Enter three numbers:");
  scanf("%f %f %f",&a,&b,&c);
  if(b==(a+c)*0.5)
    printf("Result:A.P.");
  else if(a==(b+c)*0.5)
    printf("Result:A.P.");
  else if(c==(b+a)*0.5)
    printf("Result:A.P.");
  else printf("Result:Not A.P.");
}

  
