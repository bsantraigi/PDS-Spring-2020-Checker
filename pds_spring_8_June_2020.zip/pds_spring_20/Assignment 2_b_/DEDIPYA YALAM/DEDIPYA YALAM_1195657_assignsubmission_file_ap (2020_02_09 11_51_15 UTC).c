/*A program to read an print three no.s and check whether they form A.P. if arranged in order*/
#include<stdio.h>
int main()
{
  float a,b,c;
  printf("\nEnter three numbers:");
  scanf("%f%f%f",&a,&b,&c);
  if(a>b)
    if(b>c)
      if(2*b==a+c)
	printf("\nA.P.");
      else
        printf("\nNot A.P.");
    else
       if(a>c)
	if(2*c==a+b)
	  printf("\nA.P.");
        else
	  printf("\nNot A.P.");
       else	
           if(2*a==c+b)
    	     printf("\nA.P.");
           else
             printf("\nNot A.P.");
  else
    if(a>c)
      if(2*a==b+c)
	printf("\nA.P.");
      else
        printf("\nNot A.P.");
    else
       if(b>c)
	if(2*c==a+b)
	  printf("\nA.P.");
        else
	  printf("\nNot A.P.");
       else	
          if(2*b==c+a)
 	    printf("\nA.P.");
          else
   	    printf("\nNot A.P.");
}
    
  
