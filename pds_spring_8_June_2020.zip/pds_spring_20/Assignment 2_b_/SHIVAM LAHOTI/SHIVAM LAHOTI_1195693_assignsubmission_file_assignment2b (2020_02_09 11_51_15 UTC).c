#include<stdio.h>
int main()
{
  /*name- Shivam Lahoti
roll no.- 19AG10028
machine no.- 5
department- Agriculture and food engineering*/
  float a,b,c,d;
  printf("enter three numbers\n");
  scanf("%f%f%f",&a,&b,&c);
  if((a>b)&&(a>c))
    {
      if(b>c)
	{
	  d=a+c-(2*b);
	}
      else{
	d=a+b-(2*c);
      }}
  else if((b>a)&&(b>c))
    {
      if(a>c)
	{
	  d=b+c-(2*a);
	}
      else{
	d=a+b-(2*c);
	  }}
  else{
    if(a>b)
      {
	d=b+c-(2*a);
      }
    else{
      d=c+a-(2*b);
    }}
  if(d<0.000000000022)
    {
      printf("AP \n");
    }
  else{
    printf("not AP \n");
  }}
      
