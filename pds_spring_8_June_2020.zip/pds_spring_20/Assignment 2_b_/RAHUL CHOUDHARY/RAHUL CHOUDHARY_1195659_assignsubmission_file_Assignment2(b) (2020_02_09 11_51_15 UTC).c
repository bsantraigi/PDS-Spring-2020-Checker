#include<stdio.h>
#include<math.h>
/* Name- Rahul Choudhary
   Roll No.: 19AE10024
   Department: Aerospace
   Machine No.: 02 */
int main()
{
 float a,b,c,d,e,f;
scanf("%f %f %f",&a,&b,&c);
d=(a+c)/(2.0);
e=(b+c)/(2.0);
f=(a+b)/(2.0);
if(fabs(b-d)<1e-6) /* Here rather than using b==d we are using fabs(b-d)<1e-6 because after calculation we might not get accurate value of d and our program will     give false output */ 
{
printf("AP\n");
}
else if(fabs(a-e)<1e-6) /* Here rather than using a==e we are using fabs(a-e)<1e-6 because after calculation we might not get accurate value of e and our program will  give false output */  
{
printf("AP\n");
}
else if(fabs(c-f)<1e-6) /* Here rather than using c==f we are using fabs(c-f)<1e-6 because after calculation we might not get accurate value of f and our program will  give false output */  
{
printf("AP\n");
}
else 
{
printf("Not AP\n");
}
return 0;
}
