#include<stdio.h>
/*Program to find whether three numbers are in AP or not*/
int main()
{
  float a,b,c,d1,d2,d3;
  printf("Enter three numbers : ");
  scanf("%f %f %f",&a,&b,&c);
  if(a>b)
    {if(a>c)
	{d3=a;
	  if(b>c)
	    {d1=c;d2=b;}
	  else
	    {d1=b;d2=c;}
	}
    }
      else
	{if(b>c)
	    { d3=b;
	  if(a>c)
	    {d1=c;d2=a;}
	  else
	    {d1=a;d2=c;}}
	}
  else
    {if(b>c)
	{d3=b;
	  if(a>c)
	    {d1=c;d2=a;}
	  else
	    {d1=a;d2=c;}
	}
    }
      else
	{d3=c;
	  if(b>c)
	    {d1=c;d2=b;}
	  else
	    {d1=b;d2=c;}
	}
}
  if(d2==(d1+d3)/2)
     printf("Result : AP");
  else
     printf("Result : Not AP");

}
