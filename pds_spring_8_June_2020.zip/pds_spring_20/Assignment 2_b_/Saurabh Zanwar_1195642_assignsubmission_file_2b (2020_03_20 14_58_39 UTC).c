/* Saurabh Zanwar
19AG30030
Agri
Machine no. 42
*/

#include<stdio.h>
int main()
{
  float a,b,c,d;
  printf(" Enter 3 nos.");
  scanf("%f%f%f",&a,&b,&c);
  if (2*b==a+c || 2*a==b+c || 2*c==a+b)
    printf("A.P");
  else printf("Not A.P\n");
}
