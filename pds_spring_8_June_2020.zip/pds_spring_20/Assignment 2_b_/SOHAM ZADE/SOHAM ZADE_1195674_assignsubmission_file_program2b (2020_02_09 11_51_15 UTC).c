/* Name: Soham Zade
   Roll no: 19CH10053
   Machine no: 10
   Program for AP*/

#include<stdio.h>
#include<math.h>

int main ()

{float a, b, c;

  printf("Enter three numbers\n");
  scanf("%f %f %f", &a, &b, &c);
  
  if(fabs((b-a)-(c-b))<1e-6 || fabs((a-c)==(b-a))<1e-6 ||fabs ((c-b)==(a-c))<1e-6)
    {printf("AP");}
  else
    {printf("Not AP");}


}
