//NAME:Avvaru Badri Visaal
//Roll number:19CH10013
//Dept:Chemical Engineering
//Machine number 8
#include<stdio.h>
int main()
{
  float a,b,c,max1,max2,max3,max,min,x,y;
  printf("enter the three numbers:");
  scanf("%f%f%f",&a,&b,&c);
  if(a>b)
    {
      max=a;
      min=b;
    }
  else
    {
      max=b;
      min=a;
    }
  if(max>c)
    {
      max1=max;
      if(min>c)
	{
	  max2=min;
	  max3=c;
	}
      else
	{
	  max2=c;
	  max3=min;
	}
    }
  else
    {
      max1=c;
      max2=max;
      max3=min;
    }
  x=max2-max3;
  y=max1-max2;
  if(x==y)
    printf("A.P\n");
  else
    printf("Not A.P\n");
}
