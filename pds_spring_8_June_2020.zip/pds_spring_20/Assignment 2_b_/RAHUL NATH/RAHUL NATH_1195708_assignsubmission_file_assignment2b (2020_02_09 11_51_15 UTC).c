/*Name:Rahul Nath
roll no.:19CH10033
Dept:chemical
assignment:assignment2(b)*/
#include<stdio.h>
int main()
{
  float i,j,k,swap1,swap2,swap3;
  printf("enter 3 distinct numbers:\n");
  scanf("%f%f%f",&i,&j,&k);
  swap1=(i+k)/2;
  swap2=(k+j)/2;
  swap3=(i+j)/2;
  
  if(swap1==j)
    {
      printf("numbers are in AP\n");
    }
  
  else if(swap2==i)
    {
      printf("numbers are in AP\n");
    }
 
  else if(swap3==k)
    {
      printf("numbers are in AP\n");
    }

  else
    {
      printf("numbers are not in AP\n");
    }
  return (0);
}
	  
      
      
  
