/*Name:Kodi Shree Harsha
Roll No:19AE30009
Machine No:3
Department:Aerospace*/

#include<stdio.h>
int main()
{
  float  A,B,C;
  printf("Enter the values of A,B,C:");
  scanf("%f %f %f",&A,&B,&C);
  if(A<B)
    {if(C<B) 
	{C=(A+B)/2;
      printf(" A.P.");}
      //else(B<C)
      //    {B=(A+C)/2;
      //      printf("A.P.");}
    }
    else if(B<C)
      {if(A<C)
	  {C=(A+B)/2;
	    printf("A.P");}
	else(C>A)
	      ; {A=(C+B)/2;
		printf("A.P.");}}
	else if(C<A)
	  {if(A<B)
	      {B=(A+C)/2;
		printf("A.P.");}
	    else(A>B)
		  ; {A=(B+C)/2;
		    printf("A.P.");}}
	    else
	    
    {printf("not A.P.");}
    
    return(0);
}
