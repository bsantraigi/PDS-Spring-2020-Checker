/*
NAME-VATSAL VENKATKRISHNA
ROLLNO-19NA30029
DEPARTMENT-OCEAN ENGINEERING AND NAVAL ARCHITECTURE
MACHINE NO-32
*/
#include<stdio.h>
void main()
{
  double a=0,b=0,c=0;
  printf("Enter 3 numbers: ");
  scanf("%lf%lf%lf",&a,&b,&c);
  double max=a;
  if(max<b)
    max=b;
  if(max<c)
    max=c;
  double min=a;
  if(min>b)
    min=b;
  if(min>c)
    min=c;
  double middle=max;
  if(middle>a && a>min)
    middle=a;
  if(middle>b && b>min)
    middle=b;
  if(middle>c && c>min)
    middle=c;
  double pre=0.000001;
    if((max+min-pre)<(2.0 * middle)&&(max+min+pre)>(2.0*middle))
    printf("\nAP\n");
  else
    printf("\nNot an AP\n");
}
