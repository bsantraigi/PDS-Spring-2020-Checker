/* Name : Aditya Vallakatla
 Roll No : 19CS30051
 Machine No : 11
 Department : Computer Science and Engineering */
/*Write a C program that takes three numbers as input and determines whether they form an arithmetic progression when arranged in order. Your program should print "A.P." if it is so, and "Not A.P." otherwise.*/
 #include<stdio.h>
#include<math.h>
main()
{
  float a,b,c;
  printf("Enter three numbers:");
  scanf("%f%f%f",&a,&b,&c);
  float d1,d2;
  if((a>b && b>c)|| (a<b && b<c))
    { d1=fabs(a-b);
      d2=fabs(b-c);
  if(d1=d2)
    printf("A.P.\n");
    else
      printf("Not an A.P.\n");
    }
  else if((b>a && a>c) || (b>c && c>a))
    { d1=fabs(b-a);
      d2=fabs(a-c);
   if(d1=d2)
    printf("A.P.\n");
    else
      printf("Not an A.P.\n");
    }
  else  { d1=fabs(a-b);
      d2=fabs(c-b);
       if(d1=d2)
    printf("A.P.\n");
    else
      printf("Not an A.P.\n");
    }
  return 0;
}
